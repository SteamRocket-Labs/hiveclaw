--
-- PostgreSQL database dump
--


-- Dumped from database version 17.7 (Homebrew)
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: activity_action_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.activity_action_enum AS ENUM (
    'chat_reply',
    'tool_call',
    'feishu_msg_sent',
    'agent_msg_sent',
    'web_msg_sent',
    'task_created',
    'task_updated',
    'file_written',
    'error',
    'llm_error',
    'schedule_run',
    'heartbeat',
    'plaza_post',
    'delegation_started',
    'delegation_completed',
    'delegation_failed',
    'delegation_killed',
    'delegation_error',
    'tool_call_direct',
    'tool_call_approved',
    'channel_delivery_success',
    'channel_delivery_failed',
    'channel_delivery_unavailable',
    'channel_capability_denied'
);


--
-- Name: agent_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.agent_status_enum AS ENUM (
    'draft',
    'creating',
    'running',
    'idle',
    'stopped',
    'error'
);


--
-- Name: approval_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.approval_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: channel_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.channel_type_enum AS ENUM (
    'feishu',
    'wecom',
    'dingtalk',
    'slack',
    'discord',
    'microsoft_teams',
    'telegram',
    'wechat_personal'
);


--
-- Name: chat_role_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.chat_role_enum AS ENUM (
    'user',
    'assistant',
    'system',
    'tool_call'
);


--
-- Name: im_provider_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.im_provider_enum AS ENUM (
    'feishu',
    'dingtalk',
    'wecom',
    'microsoft_teams',
    'web_only'
);


--
-- Name: permission_scope_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.permission_scope_enum AS ENUM (
    'company',
    'department',
    'user'
);


--
-- Name: task_priority_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.task_priority_enum AS ENUM (
    'low',
    'medium',
    'high',
    'urgent'
);


--
-- Name: task_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.task_type_enum AS ENUM (
    'todo'
);


--
-- Name: user_role_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role_enum AS ENUM (
    'platform_admin',
    'org_admin',
    'member'
);


--
-- Name: enforce_config_revision_immutability(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_config_revision_immutability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                IF TG_OP = 'DELETE' THEN
                    RAISE EXCEPTION 'config revision snapshots are immutable';
                END IF;
                IF ROW(
                    OLD.id, OLD.entity_type, OLD.entity_id, OLD.tenant_id, OLD.version,
                    OLD.content_hash, OLD.content, OLD.diff_from_prev, OLD.change_source,
                    OLD.changed_by_user_id, OLD.changed_by_agent_id, OLD.change_message,
                    OLD.parent_revision_id, OLD.rollback_of_revision_id, OLD.created_at
                ) IS DISTINCT FROM ROW(
                    NEW.id, NEW.entity_type, NEW.entity_id, NEW.tenant_id, NEW.version,
                    NEW.content_hash, NEW.content, NEW.diff_from_prev, NEW.change_source,
                    NEW.changed_by_user_id, NEW.changed_by_agent_id, NEW.change_message,
                    NEW.parent_revision_id, NEW.rollback_of_revision_id, NEW.created_at
                ) OR (OLD.is_active = false AND NEW.is_active = true) THEN
                    RAISE EXCEPTION 'config revision snapshots are immutable';
                END IF;
                RETURN NEW;
            END;
            $$;


--
-- Name: enforce_hr_creation_blueprint_immutability(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_hr_creation_blueprint_immutability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                IF (OLD.status = 'superseded' AND OLD.status IS DISTINCT FROM NEW.status)
                   OR (
                        OLD.status IN ('confirmed', 'creating', 'provisioning', 'failed', 'completed', 'superseded')
                        AND (
                        OLD.blueprint_version IS DISTINCT FROM NEW.blueprint_version
                        OR OLD.blueprint_hash IS DISTINCT FROM NEW.blueprint_hash
                        OR OLD.blueprint_json IS DISTINCT FROM NEW.blueprint_json
                        )
                   )
                THEN
                    RAISE EXCEPTION 'confirmed HR blueprint is immutable'
                        USING ERRCODE = '23514';
                END IF;
                RETURN NEW;
            END;
            $$;


--
-- Name: enforce_session_event_v2_contract(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_session_event_v2_contract() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
        DECLARE
          event_matrix jsonb := '{"a2a_delegation":{"lifecycles":["cancelled","completed","denied","failed","progress","queued","snapshot","started","unavailable","waiting"],"scopes":["round","run"]},"a2a_receipt":{"lifecycles":["cancelled","completed","denied","failed","progress","queued","snapshot","started","unavailable","waiting"],"scopes":["round","run"]},"approval":{"lifecycles":["cancelled","completed","created","denied","expired","waiting"],"scopes":["round","run"]},"artifact":{"lifecycles":["created","delivered","failed","updated"],"scopes":["round","run"]},"assistant_commentary":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"assistant_final":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"assistant_plan":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"assistant_reasoning_private":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"assistant_reasoning_summary":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"assistant_text":{"lifecycles":["cancelled","completed","delta","failed","snapshot","started"],"scopes":["round"]},"carry_forward":{"lifecycles":["bound","claimed","consumed","needs_reconciliation","reconciled"],"scopes":["round"]},"code_execution":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"context_compaction":{"lifecycles":["completed","failed","needs_reconciliation","progress","reconciled","started"],"scopes":["round","run"]},"context_source":{"lifecycles":["completed","denied","failed","started","unavailable"],"scopes":["round"]},"control_input":{"lifecycles":["accepted","applied","failed","needs_reconciliation","reconciled","rejected","started"],"scopes":["run","session"]},"evaluation_feedback_mutation":{"lifecycles":["recorded","updated","withdrawn"],"scopes":["session"]},"file_change":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"file_preview":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"file_read":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"hook":{"lifecycles":["blocked","cancelled","completed","denied","failed","prevented","started","waiting"],"scopes":["round","run","session"]},"human_input":{"lifecycles":["accepted","applied","bound","cancelled","needs_reconciliation","queued","reconciled","rejected","revised","rolled_over"],"scopes":["session"]},"image_view":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"input_admission":{"lifecycles":["admitted","cancelled","needs_reconciliation","prepared","reconciled","rejected","sealed","started"],"scopes":["session"]},"mcp_call":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"memory_commit":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"memory_load":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"memory_search":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"memory_write_proposal":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"recovery_action":{"lifecycles":["completed","failed","reconciled","requested","started"],"scopes":["run","session","turn"]},"result_commit":{"lifecycles":["failed","needs_reconciliation","prepared","reconciled","round_committed","sealed","streaming"],"scopes":["round"]},"run":{"lifecycles":["cancelled","cancelling","completed","failed","needs_reconciliation","queued","reconciled","running","starting","waiting"],"scopes":["run"]},"run_outcome":{"lifecycles":["failed","needs_reconciliation","prepared","reconciled","sealed","terminal_committed"],"scopes":["run"]},"runtime_failure":{"lifecycles":["recorded"],"scopes":["round","run","session","turn"]},"session":{"lifecycles":["created","forked","resumed"],"scopes":["session"]},"skill_load":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"skill_search":{"lifecycles":["cancelled","completed","denied","failed","progress","started","unavailable"],"scopes":["round"]},"subagent":{"lifecycles":["cancelled","completed","denied","failed","progress","queued","snapshot","started","unavailable","waiting"],"scopes":["round","run"]},"tool_call":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"tool_permission":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"tool_result":{"lifecycles":["completed"],"scopes":["round"]},"tool_search":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"turn":{"lifecycles":["accepted","cancelled","completed","failed","needs_reconciliation","queued","reconciled","started","waiting"],"scopes":["turn"]},"turn_replacement":{"lifecycles":["admitted","cancelling","completed","failed","fenced","needs_reconciliation","queued","reconciled","requested"],"scopes":["session"]},"user_question":{"lifecycles":["cancelled","completed","created","denied","expired","waiting"],"scopes":["round","run"]},"web_search":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","unavailable","waiting"],"scopes":["round"]},"workflow_gate":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","waiting"],"scopes":["round","run"]},"workflow_run":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","waiting"],"scopes":["round","run"]},"workflow_step":{"lifecycles":["cancelled","completed","denied","failed","needs_reconciliation","progress","queued","reconciled","started","waiting"],"scopes":["round","run"]}}'::jsonb;
          hook_matrix jsonb := '{"PostCompact":{"lifecycles":["cancelled","completed","failed","started"],"scopes":["run"],"sources":["auto","manual","reactive"]},"PreCompact":{"lifecycles":["cancelled","completed","failed","started"],"scopes":["run"],"sources":["auto","manual","reactive"]},"PreToolUse":{"lifecycles":["blocked","cancelled","completed","denied","failed","prevented","started","waiting"],"scopes":["round"],"sources":[]},"SessionStart":{"lifecycles":["completed","failed","started"],"scopes":["session"],"sources":["clear","compact","resume","startup"]},"Stop":{"lifecycles":["blocked","cancelled","completed","failed","prevented","started"],"scopes":["run"],"sources":[]},"SubagentStop":{"lifecycles":["blocked","cancelled","completed","failed","prevented","started"],"scopes":["run"],"sources":[]},"UserPromptSubmit":{"lifecycles":["blocked","cancelled","completed","failed","prevented","started"],"scopes":["session"],"sources":[]}}'::jsonb;
          rule jsonb;
          hook_rule jsonb;
          level text;
          boundary text;
          source_value text;
          allowed_scope_keys text[];
          bound_tenant_id uuid;
          bound_agent_id uuid;
          epoch public.session_writer_epochs%ROWTYPE;
          run_generation integer;
        BEGIN
          SELECT tenant_id,agent_id INTO bound_tenant_id,bound_agent_id
          FROM public.chat_sessions WHERE id=NEW.session_id;
          IF NOT FOUND OR NEW.tenant_id IS DISTINCT FROM bound_tenant_id
             OR NEW.agent_id IS DISTINCT FROM bound_agent_id THEN
            RAISE EXCEPTION 'session_event_authority_binding_mismatch' USING ERRCODE='23514';
          END IF;
          IF TG_OP='UPDATE'
             AND (to_jsonb(NEW) - ARRAY[
                    'metadata_json','projection_status','projection_attempts',
                    'projection_error','projected_at'
                 ]::text[])
                 = (to_jsonb(OLD) - ARRAY[
                    'metadata_json','projection_status','projection_attempts',
                    'projection_error','projected_at'
                 ]::text[])
             AND (COALESCE(NEW.metadata_json,'{}'::jsonb) - ARRAY[
                    't0_bridge_pending','t0_bridge_last_error','t0_bridge_attempts',
                    't0_bridge_relayed_at','t0_bridge_relay_source',
                    't0_bridge_segment_id','t0_bridge_event_id','t0_bridge_sequence'
                 ]::text[])
                 = (COALESCE(OLD.metadata_json,'{}'::jsonb) - ARRAY[
                    't0_bridge_pending','t0_bridge_last_error','t0_bridge_attempts',
                    't0_bridge_relayed_at','t0_bridge_relay_source',
                    't0_bridge_segment_id','t0_bridge_event_id','t0_bridge_sequence'
                 ]::text[])
             AND NEW.projection_status IN ('pending','projecting','projected','failed','not_requested')
             AND NEW.projection_attempts >= OLD.projection_attempts
             AND (OLD.projection_status <> 'projected' OR NEW.projection_status='projected') THEN
            -- Projection is a current derived-evidence transition, not a late
            -- semantic writer. Canonical event bytes stay immutable while a
            -- drained legacy generation can still finish its T0 sidecar.
            RETURN NEW;
          END IF;
          SELECT * INTO epoch FROM public.session_writer_epochs WHERE id='global';
          IF epoch.id IS NOT NULL AND epoch.enforcement_mode='enforce' THEN
            IF NEW.schema_version <> 2 THEN
              IF epoch.state <> 'v1_draining' OR NEW.run_id IS NULL THEN
                RAISE EXCEPTION 'writer_epoch_rejected legacy transcript mutation' USING ERRCODE='23514';
              END IF;
              SELECT writer_generation INTO run_generation FROM public.runtime_tasks WHERE id=NEW.run_id;
              IF NOT FOUND OR run_generation <> 1
                 OR NOT epoch.allowed_existing_generations_json @> to_jsonb(ARRAY[run_generation]) THEN
                RAISE EXCEPTION 'writer_epoch_rejected legacy run generation' USING ERRCODE='23514';
              END IF;
            ELSIF NEW.run_id IS NOT NULL THEN
              SELECT writer_generation INTO run_generation FROM public.runtime_tasks WHERE id=NEW.run_id;
              IF NOT FOUND OR run_generation <> 2
                 OR NOT epoch.allowed_existing_generations_json @> to_jsonb(ARRAY[run_generation]) THEN
                RAISE EXCEPTION 'writer_epoch_rejected V2 run generation' USING ERRCODE='23514';
              END IF;
            END IF;
          END IF;
          IF NEW.schema_version <> 2 AND NEW.run_id IS NOT NULL AND (
            epoch.id IS NULL OR NOT EXISTS (
              SELECT 1 FROM public.runtime_tasks AS legacy_run
              WHERE legacy_run.id=NEW.run_id
                AND legacy_run.tenant_id=NEW.tenant_id
                AND (
                  (
                    replace(lower(legacy_run.parent_session_id),'-','')
                      = replace(lower(NEW.session_id::text),'-','')
                    AND legacy_run.parent_agent_id=NEW.agent_id
                  )
                  OR (
                    replace(lower(legacy_run.child_session_id),'-','')
                      = replace(lower(NEW.session_id::text),'-','')
                    AND COALESCE(legacy_run.child_agent_id, legacy_run.parent_agent_id)=NEW.agent_id
                  )
                )
                AND epoch.allowed_existing_generations_json
                    @> to_jsonb(ARRAY[legacy_run.writer_generation])
            )
          ) THEN
            RAISE EXCEPTION 'writer_epoch_rejected legacy run authority'
              USING ERRCODE='23514';
          END IF;
          IF NEW.schema_version <> 2 THEN RETURN NEW; END IF;
          IF NEW.item_id IS NULL OR NEW.item_kind IS NULL OR NEW.lifecycle IS NULL
             OR NEW.payload_schema IS NULL OR NEW.scope_json IS NULL
             OR jsonb_typeof(NEW.scope_json) <> 'object' THEN
            RAISE EXCEPTION 'incomplete SessionEventV2 envelope' USING ERRCODE='23514';
          END IF;
          IF NEW.event_type <> NEW.item_kind || '.' || NEW.lifecycle
             OR NEW.payload_schema <> 'hive.session.payload.' || NEW.item_kind || '.' || NEW.lifecycle || '.v2' THEN
            RAISE EXCEPTION 'SessionEventV2 kind/schema mismatch' USING ERRCODE='23514';
          END IF;
          rule := event_matrix->NEW.item_kind;
          level := NEW.scope_json->>'level';
          IF rule IS NULL OR NOT (rule->'lifecycles' ? NEW.lifecycle)
             OR NOT (rule->'scopes' ? level) THEN
            RAISE EXCEPTION 'illegal SessionEventV2 kind/lifecycle/scope tuple' USING ERRCODE='23514';
          END IF;
          allowed_scope_keys := CASE level
            WHEN 'session' THEN ARRAY['level','session_id','thread_id']
            WHEN 'turn' THEN ARRAY['level','session_id','thread_id','turn_id']
            WHEN 'run' THEN ARRAY['level','session_id','thread_id','turn_id','run_id']
            WHEN 'round' THEN ARRAY['level','session_id','thread_id','turn_id','run_id','round_id']
            ELSE ARRAY[]::text[] END;
          IF EXISTS (
            SELECT 1 FROM jsonb_object_keys(NEW.scope_json) AS scope_key
            WHERE NOT (scope_key = ANY(allowed_scope_keys))
          ) THEN
            RAISE EXCEPTION 'SessionEventV2 scope contains forbidden fields' USING ERRCODE='23514';
          END IF;
          IF NULLIF(NEW.scope_json->>'session_id','') IS NULL
             OR NULLIF(NEW.scope_json->>'thread_id','') IS NULL
             OR NEW.scope_json->>'session_id' <> NEW.scope_json->>'thread_id'
             OR (NEW.scope_json->>'session_id')::uuid <> NEW.session_id THEN
            RAISE EXCEPTION 'invalid SessionEventV2 session scope' USING ERRCODE='23514';
          END IF;
          IF level IN ('turn','run','round') AND NULLIF(NEW.scope_json->>'turn_id','') IS NULL THEN
            RAISE EXCEPTION 'turn_id required by SessionEventV2 scope' USING ERRCODE='23514';
          END IF;
          IF level IN ('run','round') AND NULLIF(NEW.scope_json->>'run_id','') IS NULL THEN
            RAISE EXCEPTION 'run_id required by SessionEventV2 scope' USING ERRCODE='23514';
          END IF;
          IF level='round' AND NULLIF(NEW.scope_json->>'round_id','') IS NULL THEN
            RAISE EXCEPTION 'round_id required by SessionEventV2 scope' USING ERRCODE='23514';
          END IF;
          IF (level IN ('session','turn') AND NEW.run_id IS NOT NULL)
             OR (level IN ('run','round') AND (
                  NEW.run_id IS NULL
                  OR NEW.run_id::text <> NEW.scope_json->>'run_id'
             )) THEN
            RAISE EXCEPTION 'session_event_run_scope_mismatch' USING ERRCODE='23514';
          END IF;
          IF NEW.run_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM public.runtime_tasks AS run
            WHERE run.id=NEW.run_id
              AND run.tenant_id=NEW.tenant_id
              AND (
                (
                  replace(lower(run.parent_session_id),'-','')
                    = replace(lower(NEW.session_id::text),'-','')
                  AND run.parent_agent_id=NEW.agent_id
                )
                OR (
                  replace(lower(run.child_session_id),'-','')
                    = replace(lower(NEW.session_id::text),'-','')
                  AND COALESCE(run.child_agent_id, run.parent_agent_id)=NEW.agent_id
                )
              )
          ) THEN
            RAISE EXCEPTION 'session_event_run_authority_mismatch' USING ERRCODE='23514';
          END IF;
          IF NEW.command_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM public.session_commands AS command
            WHERE command.id=NEW.command_id
              AND command.tenant_id=NEW.tenant_id
              AND command.session_id=NEW.session_id
          ) THEN
            RAISE EXCEPTION 'session_event_command_authority_mismatch' USING ERRCODE='23514';
          END IF;
          IF NEW.input_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM public.session_turn_inputs AS input
            WHERE input.id=NEW.input_id
              AND input.tenant_id=NEW.tenant_id
              AND input.session_id=NEW.session_id
              AND (
                NEW.command_id IS NULL
                OR input.command_id=NEW.command_id
                OR EXISTS (
                  SELECT 1 FROM public.session_commands AS linked_command
                  WHERE linked_command.id=NEW.command_id
                    AND linked_command.namespace='turn_replacement'
                    AND linked_command.causation_command_id=input.command_id
                    AND linked_command.tenant_id=input.tenant_id
                    AND linked_command.session_id=input.session_id
                )
              )
              AND (input.target_run_id IS NULL OR NEW.run_id IS NULL OR input.target_run_id=NEW.run_id)
          ) THEN
            RAISE EXCEPTION 'session_event_input_authority_mismatch' USING ERRCODE='23514';
          END IF;
          IF NEW.result_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM public.session_model_results AS result
            WHERE result.id=NEW.result_id
              AND result.tenant_id=NEW.tenant_id
              AND result.session_id=NEW.session_id
              AND result.run_id=NEW.run_id
              AND result.turn_id=NEW.scope_json->>'turn_id'
              AND result.round_id=NEW.scope_json->>'round_id'
          ) THEN
            RAISE EXCEPTION 'session_event_result_authority_mismatch' USING ERRCODE='23514';
          END IF;
          IF NEW.invocation_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM public.session_tool_invocations AS invocation
            WHERE invocation.id=NEW.invocation_id
              AND invocation.tenant_id=NEW.tenant_id
              AND invocation.session_id=NEW.session_id
              AND invocation.run_id=NEW.run_id
              AND invocation.round_id=NEW.scope_json->>'round_id'
          ) THEN
            RAISE EXCEPTION 'session_event_invocation_authority_mismatch' USING ERRCODE='23514';
          END IF;
          IF jsonb_typeof(COALESCE(NEW.metadata_json,'{}'::jsonb)->'v2_payload') IS DISTINCT FROM 'object'
             OR jsonb_typeof(COALESCE(NEW.metadata_json,'{}'::jsonb)->'actor') IS DISTINCT FROM 'object'
             OR jsonb_typeof(COALESCE(NEW.metadata_json,'{}'::jsonb)->'visibility') IS DISTINCT FROM 'object' THEN
            RAISE EXCEPTION 'incomplete SessionEventV2 payload authority' USING ERRCODE='23514';
          END IF;
          IF NEW.item_kind='assistant_text'
             AND COALESCE(NEW.metadata_json->'v2_payload'->>'phase','unknown') <> 'unknown' THEN
            RAISE EXCEPTION 'assistant_text phase must be unknown' USING ERRCODE='23514';
          ELSIF NEW.item_kind='assistant_commentary'
             AND COALESCE(NEW.metadata_json->'v2_payload'->>'phase','commentary') <> 'commentary' THEN
            RAISE EXCEPTION 'assistant_commentary phase must be commentary' USING ERRCODE='23514';
          ELSIF NEW.item_kind='assistant_reasoning_summary'
             AND COALESCE(NEW.metadata_json->'v2_payload'->>'phase','reasoning_summary') <> 'reasoning_summary' THEN
            RAISE EXCEPTION 'assistant_reasoning_summary phase must be reasoning_summary' USING ERRCODE='23514';
          ELSIF NEW.item_kind='assistant_reasoning_private'
             AND COALESCE(NEW.metadata_json->'v2_payload'->>'phase','reasoning_private') <> 'reasoning_private' THEN
            RAISE EXCEPTION 'assistant_reasoning_private phase must be reasoning_private' USING ERRCODE='23514';
          ELSIF NEW.item_kind='assistant_final'
             AND COALESCE(NEW.metadata_json->'v2_payload'->>'phase','final') <> 'final' THEN
            RAISE EXCEPTION 'assistant_final phase must be final' USING ERRCODE='23514';
          ELSIF NEW.item_kind NOT IN (
            'assistant_text','assistant_commentary','assistant_reasoning_summary',
            'assistant_reasoning_private','assistant_final'
          )
             AND NEW.metadata_json->'v2_payload' ? 'phase' THEN
            RAISE EXCEPTION 'assistant phase is illegal for this item kind' USING ERRCODE='23514';
          END IF;
          IF NEW.item_kind='hook' THEN
            boundary := NEW.metadata_json->'v2_payload'->>'boundary';
            source_value := COALESCE(NEW.metadata_json->'v2_payload'->>'source','');
            hook_rule := hook_matrix->boundary;
            IF hook_rule IS NULL OR NOT (hook_rule->'lifecycles' ? NEW.lifecycle)
               OR NOT (hook_rule->'scopes' ? level)
               OR (jsonb_array_length(hook_rule->'sources') > 0
                   AND NOT (hook_rule->'sources' ? source_value))
               OR (jsonb_array_length(hook_rule->'sources') = 0
                   AND NEW.metadata_json->'v2_payload' ? 'source') THEN
              RAISE EXCEPTION 'illegal SessionEventV2 hook boundary tuple' USING ERRCODE='23514';
            END IF;
          END IF;
          RETURN NEW;
        END;
        $$;


--
-- Name: enforce_session_v2_tenant_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_session_v2_tenant_binding() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $_$
        DECLARE
          bound_tenant_id uuid;
          bound_agent_id uuid;
          authority_ok boolean := FALSE;
        BEGIN
          IF TG_OP='UPDATE' AND (
            OLD.tenant_id IS DISTINCT FROM NEW.tenant_id
            OR OLD.session_id IS DISTINCT FROM NEW.session_id
          ) THEN
            RAISE EXCEPTION 'session_v2_authority_frame_immutable' USING ERRCODE='23514';
          END IF;
          SELECT tenant_id,agent_id INTO bound_tenant_id,bound_agent_id
          FROM public.chat_sessions WHERE id=NEW.session_id;
          IF NOT FOUND OR NEW.tenant_id IS DISTINCT FROM bound_tenant_id THEN
            RAISE EXCEPTION 'session_v2_tenant_binding_mismatch' USING ERRCODE='23514';
          END IF;
          IF TG_TABLE_NAME='session_event_cursors' THEN
            SELECT (TRUE) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_event_outbox' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS event
          WHERE event.id=NEW.event_id
            AND event.tenant_id=NEW.tenant_id
            AND event.session_id=NEW.session_id
            AND event.sequence=NEW.sequence
        )) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_commands' THEN
            SELECT (NEW.causation_command_id IS NULL OR EXISTS (
          SELECT 1 FROM public.session_commands AS cause
          WHERE cause.id=NEW.causation_command_id
            AND cause.tenant_id=NEW.tenant_id
            AND cause.session_id=NEW.session_id
        )) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_turn_inputs' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.session_commands AS command
          WHERE command.id=NEW.command_id
            AND command.tenant_id=NEW.tenant_id
            AND command.session_id=NEW.session_id
        )
        AND (NEW.target_run_id IS NULL OR EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.target_run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        ))
        AND (NEW.request_item_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS request_event
          WHERE request_event.item_id=NEW.request_item_id
            AND request_event.tenant_id=NEW.tenant_id
            AND request_event.session_id=NEW.session_id
        ))
        AND (NEW.fork_after_sequence IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS fork_event
          WHERE fork_event.sequence=NEW.fork_after_sequence
            AND fork_event.tenant_id=NEW.tenant_id
            AND fork_event.session_id=NEW.session_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_input_admissions' THEN
            SELECT (EXISTS (
          SELECT 1
          FROM public.session_commands AS command
          JOIN public.session_turn_inputs AS turn_input
            ON turn_input.id=NEW.input_id
           AND turn_input.command_id=command.id
           AND turn_input.tenant_id=command.tenant_id
           AND turn_input.session_id=command.session_id
          WHERE command.id=NEW.command_id
            AND command.tenant_id=NEW.tenant_id
            AND command.session_id=NEW.session_id
            AND NEW.input_revision > 0
            AND NEW.input_revision <= turn_input.revision
        )
        AND (NEW.hook_item_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS hook_event
          WHERE hook_event.item_id=NEW.hook_item_id
            AND hook_event.tenant_id=NEW.tenant_id
            AND hook_event.session_id=NEW.session_id
            AND hook_event.item_kind='hook'
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_carry_forwards' THEN
            SELECT (EXISTS (
          SELECT 1
          FROM public.session_input_admissions AS admission
          JOIN public.session_turn_inputs AS turn_input
            ON turn_input.id=admission.input_id
           AND turn_input.tenant_id=admission.tenant_id
           AND turn_input.session_id=admission.session_id
          WHERE admission.id=NEW.source_admission_id
            AND admission.input_id=NEW.source_input_id
            AND admission.hook_run_id=NEW.source_hook_run_id
            AND admission.tenant_id=NEW.tenant_id
            AND admission.session_id=NEW.session_id
        )
        AND (NEW.target_turn_id IS NULL OR EXISTS (
          SELECT 1 FROM public.session_model_results AS target_result
          WHERE target_result.tenant_id=NEW.tenant_id
            AND target_result.session_id=NEW.session_id
            AND target_result.turn_id=NEW.target_turn_id
        ) OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS target_event
          WHERE target_event.tenant_id=NEW.tenant_id
            AND target_event.session_id=NEW.session_id
            AND target_event.scope_json->>'turn_id'=NEW.target_turn_id
        ))
        AND (NEW.target_round_id IS NULL OR EXISTS (
          SELECT 1 FROM public.session_model_results AS target_result
          WHERE target_result.tenant_id=NEW.tenant_id
            AND target_result.session_id=NEW.session_id
            AND target_result.turn_id=NEW.target_turn_id
            AND target_result.round_id=NEW.target_round_id
        ))
        AND (NEW.consumed_event_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS consumed_event
          WHERE consumed_event.id=NEW.consumed_event_id
            AND consumed_event.item_id=NEW.context_source_item_id
            AND consumed_event.tenant_id=NEW.tenant_id
            AND consumed_event.session_id=NEW.session_id
            AND consumed_event.scope_json->>'turn_id'=NEW.target_turn_id
            AND consumed_event.scope_json->>'round_id'=NEW.target_round_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_control_inputs' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.session_commands AS command
          WHERE command.id=NEW.command_id
            AND command.tenant_id=NEW.tenant_id
            AND command.session_id=NEW.session_id
        )
        AND EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.expected_run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        )
        AND (NEW.request_item_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS request_event
          WHERE request_event.item_id=NEW.request_item_id
            AND request_event.tenant_id=NEW.tenant_id
            AND request_event.session_id=NEW.session_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_turn_replacements' THEN
            SELECT (EXISTS (
          SELECT 1
          FROM public.session_commands AS saga_command
          JOIN public.session_commands AS parent_command
            ON parent_command.id=saga_command.causation_command_id
           AND parent_command.tenant_id=saga_command.tenant_id
           AND parent_command.session_id=saga_command.session_id
          JOIN public.session_turn_inputs AS replacement_input
            ON replacement_input.id=NEW.replacement_input_id
           AND replacement_input.command_id=parent_command.id
           AND replacement_input.tenant_id=saga_command.tenant_id
           AND replacement_input.session_id=saga_command.session_id
          JOIN public.session_input_admissions AS admission
            ON admission.input_id=replacement_input.id
           AND admission.command_id=parent_command.id
           AND admission.tenant_id=saga_command.tenant_id
           AND admission.session_id=saga_command.session_id
           AND admission.input_revision=replacement_input.revision
          WHERE saga_command.id=NEW.command_id
            AND saga_command.namespace='turn_replacement'
            AND parent_command.namespace='human_input'
            AND parent_command.command_kind='interrupt_and_replace'
            AND replacement_input.intent='interrupt_and_replace'
            AND (
              (NEW.state IN ('requested','cancel_accepted','old_run_fenced')
               AND replacement_input.target_turn_id=NEW.old_turn_id
               AND replacement_input.target_run_id=NEW.old_run_id)
              OR
              (NEW.state IN ('replacement_queued','replacement_admitted','completed','failed','needs_reconciliation')
               AND replacement_input.target_turn_id IN (NEW.old_turn_id,NEW.replacement_turn_id))
            )
            AND admission.state='admitted'
            AND saga_command.tenant_id=NEW.tenant_id
            AND saga_command.session_id=NEW.session_id
        )
        AND (
          (NEW.state IN ('requested','needs_reconciliation')
           AND NEW.cancel_control_id IS NULL
           AND NEW.cancel_command_id IS NULL)
          OR
          (NEW.state<>'requested'
           AND NEW.cancel_control_id IS NOT NULL
           AND NEW.cancel_command_id IS NOT NULL
           AND EXISTS (
             SELECT 1
             FROM public.session_commands AS saga_command
             JOIN public.session_commands AS cancel_command
               ON cancel_command.id=NEW.cancel_command_id
              AND cancel_command.causation_command_id=saga_command.id
              AND cancel_command.tenant_id=saga_command.tenant_id
              AND cancel_command.session_id=saga_command.session_id
              AND cancel_command.namespace='control_input'
             JOIN public.session_control_inputs AS cancel_control
               ON cancel_control.id=NEW.cancel_control_id
              AND cancel_control.command_id=cancel_command.id
              AND cancel_control.expected_run_id=NEW.old_run_id
              AND cancel_control.tenant_id=saga_command.tenant_id
              AND cancel_control.session_id=saga_command.session_id
             WHERE saga_command.id=NEW.command_id
               AND saga_command.tenant_id=NEW.tenant_id
               AND saga_command.session_id=NEW.session_id
           ))
        )
        AND EXISTS (
          SELECT 1 FROM public.runtime_tasks AS old_run
          WHERE old_run.id=NEW.old_run_id
            AND old_run.tenant_id=NEW.tenant_id
            AND old_run.parent_session_id=NEW.session_id::text
            AND old_run.parent_agent_id=bound_agent_id
            AND COALESCE(
                  NULLIF(old_run.metadata_json->>'turn_id',''),
                  'turn-' || replace(old_run.id::text,'-','')
                )=NEW.old_turn_id
        )
        AND (NEW.last_event_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS last_event
          WHERE last_event.id=NEW.last_event_id
            AND last_event.tenant_id=NEW.tenant_id
            AND last_event.session_id=NEW.session_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_tool_invocations' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        )
        AND EXISTS (
          SELECT 1 FROM public.session_model_results AS result
          WHERE result.tenant_id=NEW.tenant_id
            AND result.session_id=NEW.session_id
            AND result.run_id=NEW.run_id
            AND result.round_id=NEW.round_id
        )
        AND (NEW.result_event_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS result_event
          WHERE result_event.id=NEW.result_event_id
            AND result_event.item_kind='tool_result'
            AND result_event.lifecycle='completed'
            AND result_event.invocation_id=NEW.id
            AND result_event.provider_tool_use_id=NEW.provider_tool_use_id
            AND result_event.tenant_id=NEW.tenant_id
            AND result_event.session_id=NEW.session_id
            AND result_event.run_id=NEW.run_id
            AND result_event.scope_json->>'round_id'=NEW.round_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_model_results' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
            AND COALESCE(
                  NULLIF(run.metadata_json->>'turn_id',''),
                  'turn-' || replace(run.id::text,'-','')
                )=NEW.turn_id
        )
        AND jsonb_typeof(NEW.bound_input_ids_json)='array'
        AND NOT EXISTS (
          SELECT 1
          FROM jsonb_array_elements_text(NEW.bound_input_ids_json) AS input_ref(value)
          LEFT JOIN public.session_turn_inputs AS bound_input
            ON bound_input.id=CASE
                 WHEN input_ref.value ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
                 THEN input_ref.value::uuid
               END
           AND bound_input.tenant_id=NEW.tenant_id
           AND bound_input.session_id=NEW.session_id
          WHERE bound_input.id IS NULL
        )
        AND (NEW.round_committed_event_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS commit_event
          WHERE commit_event.id=NEW.round_committed_event_id
            AND commit_event.result_id=NEW.id
            AND commit_event.tenant_id=NEW.tenant_id
            AND commit_event.session_id=NEW.session_id
            AND commit_event.run_id=NEW.run_id
            AND commit_event.scope_json->>'turn_id'=NEW.turn_id
            AND commit_event.scope_json->>'round_id'=NEW.round_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_round_obligations' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        )
        AND EXISTS (
          SELECT 1 FROM public.session_model_results AS source_result
          WHERE source_result.id=NEW.source_result_id
            AND source_result.tenant_id=NEW.tenant_id
            AND source_result.session_id=NEW.session_id
            AND source_result.run_id=NEW.run_id
            AND source_result.turn_id=NEW.turn_id
        )) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_next_round_plans' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        )
        AND EXISTS (
          SELECT 1 FROM public.session_model_results AS source_result
          WHERE source_result.id=NEW.source_result_id
            AND source_result.tenant_id=NEW.tenant_id
            AND source_result.session_id=NEW.session_id
            AND source_result.run_id=NEW.run_id
        )
        AND jsonb_typeof(NEW.obligation_ids_json)='array'
        AND NOT EXISTS (
          SELECT 1
          FROM jsonb_array_elements_text(NEW.obligation_ids_json) AS obligation_ref(value)
          LEFT JOIN public.session_round_obligations AS obligation
            ON obligation.id=CASE
                 WHEN obligation_ref.value ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
                 THEN obligation_ref.value::uuid
               END
           AND obligation.tenant_id=NEW.tenant_id
           AND obligation.session_id=NEW.session_id
           AND obligation.run_id=NEW.run_id
           AND obligation.source_result_id=NEW.source_result_id
          WHERE obligation.id IS NULL
        )) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_run_outcomes' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.runtime_tasks AS run
          WHERE run.id=NEW.run_id
            AND run.tenant_id=NEW.tenant_id
            AND run.parent_session_id=NEW.session_id::text
            AND run.parent_agent_id=bound_agent_id
        )
        AND EXISTS (
          SELECT 1 FROM public.session_model_results AS terminal_result
          WHERE terminal_result.id=NEW.terminal_result_id
            AND terminal_result.tenant_id=NEW.tenant_id
            AND terminal_result.session_id=NEW.session_id
            AND terminal_result.run_id=NEW.run_id
            AND terminal_result.turn_id=NEW.turn_id
        )
        AND (NEW.terminal_event_id IS NULL OR EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS terminal_event
          WHERE terminal_event.id=NEW.terminal_event_id
            AND terminal_event.result_id=NEW.terminal_result_id
            AND terminal_event.tenant_id=NEW.tenant_id
            AND terminal_event.session_id=NEW.session_id
            AND terminal_event.run_id=NEW.run_id
            AND terminal_event.scope_json->>'turn_id'=NEW.turn_id
        ))) INTO authority_ok;
          ELSIF TG_TABLE_NAME='session_feedback_aggregates' THEN
            SELECT (EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS target_event
          WHERE target_event.item_id=NEW.target_item_id
            AND target_event.tenant_id=NEW.tenant_id
            AND target_event.session_id=NEW.session_id
            AND (NEW.target_result_id IS NULL OR target_event.result_id=NEW.target_result_id)
        )
        AND (NEW.target_result_id IS NULL OR EXISTS (
          SELECT 1 FROM public.session_model_results AS target_result
          WHERE target_result.id=NEW.target_result_id
            AND target_result.tenant_id=NEW.tenant_id
            AND target_result.session_id=NEW.session_id
        ))
        AND EXISTS (
          SELECT 1 FROM public.chat_transcript_events AS mutation_event
          WHERE mutation_event.item_id=NEW.last_mutation_item_id
            AND mutation_event.item_kind='evaluation_feedback_mutation'
            AND mutation_event.tenant_id=NEW.tenant_id
            AND mutation_event.session_id=NEW.session_id
        )) INTO authority_ok;
          ELSE
            authority_ok := FALSE;
          END IF;
          IF NOT COALESCE(authority_ok,FALSE) THEN
            RAISE EXCEPTION 'session_v2_authority_binding_mismatch' USING ERRCODE='23514';
          END IF;
          RETURN NEW;
        END;
        $_$;


--
-- Name: enforce_session_writer_epoch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_session_writer_epoch() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
        DECLARE epoch public.session_writer_epochs%ROWTYPE;
        BEGIN
          SELECT * INTO epoch FROM public.session_writer_epochs WHERE id='global';
          IF NOT FOUND OR epoch.enforcement_mode='observe' THEN RETURN NEW; END IF;
          IF TG_OP='INSERT' THEN
            IF NEW.writer_generation <> epoch.new_run_generation
               OR NOT epoch.allowed_existing_generations_json @> to_jsonb(ARRAY[NEW.writer_generation]) THEN
              RAISE EXCEPTION 'writer_epoch_rejected new run generation' USING ERRCODE='23514';
            END IF;
            RETURN NEW;
          END IF;
          IF NEW.writer_generation <> OLD.writer_generation THEN
            RAISE EXCEPTION 'writer_generation is immutable' USING ERRCODE='23514';
          END IF;
          IF NOT epoch.allowed_existing_generations_json @> to_jsonb(ARRAY[OLD.writer_generation]) THEN
            RAISE EXCEPTION 'writer_epoch_rejected late runtime mutation' USING ERRCODE='23514';
          END IF;
          RETURN NEW;
        END;
        $$;


--
-- Name: reject_audit_evidence_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_audit_evidence_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                RAISE EXCEPTION 'audit evidence is append-only: %', TG_TABLE_NAME
                    USING ERRCODE = '55000';
                RETURN NULL;
            END;
            $$;


--
-- Name: set_runtime_task_terminal_boundary_generation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_runtime_task_terminal_boundary_generation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
              IF NEW.task_type IN ('web_chat_turn', 'goal_continuation', 'team_member', 'advanced_plan', 'a2a_continuation', 'business_task', 'trigger', 'delegation') THEN
                IF NEW.terminal_boundary_generation IS NULL THEN
                  NEW.terminal_boundary_generation := 1;
                END IF;
              ELSE
                NEW.terminal_boundary_generation := NULL;
              END IF;
              RETURN NEW;
            END;
            $$;


--
-- Name: workflow_promotion_snapshot_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workflow_promotion_snapshot_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                IF TG_OP = 'DELETE' THEN
                    RAISE EXCEPTION 'workflow promotion proposal snapshots are immutable';
                END IF;
                IF OLD.status IS DISTINCT FROM NEW.status
                   AND NOT (
                       (OLD.status = 'pending' AND NEW.status IN ('approved','rejected','stale','withdrawn'))
                       OR (OLD.status = 'withdrawn' AND NEW.status = 'pending')
                   ) THEN
                    RAISE EXCEPTION 'invalid workflow promotion proposal transition';
                END IF;
                IF OLD.status IN ('approved','rejected','stale')
                   AND (
                       OLD.reviewer_user_id IS DISTINCT FROM NEW.reviewer_user_id
                       OR OLD.review_reason IS DISTINCT FROM NEW.review_reason
                       OR OLD.reviewed_at IS DISTINCT FROM NEW.reviewed_at
                   ) THEN
                    RAISE EXCEPTION 'terminal workflow promotion review is immutable';
                END IF;
                IF OLD.tenant_id IS DISTINCT FROM NEW.tenant_id
                   OR OLD.agent_id IS DISTINCT FROM NEW.agent_id
                   OR OLD.run_id IS DISTINCT FROM NEW.run_id
                   OR OLD.root_session_id IS DISTINCT FROM NEW.root_session_id
                   OR OLD.requester_user_id IS DISTINCT FROM NEW.requester_user_id
                   OR OLD.proposal_hash IS DISTINCT FROM NEW.proposal_hash
                   OR OLD.run_evidence_hash IS DISTINCT FROM NEW.run_evidence_hash
                   OR OLD.definition_hash IS DISTINCT FROM NEW.definition_hash
                   OR OLD.definition_json IS DISTINCT FROM NEW.definition_json
                   OR OLD.run_evidence_json IS DISTINCT FROM NEW.run_evidence_json
                   OR OLD.created_at IS DISTINCT FROM NEW.created_at THEN
                    RAISE EXCEPTION 'workflow promotion proposal snapshots are immutable';
                END IF;
                RETURN NEW;
            END;
            $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_activity_logs (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid,
    root_session_id uuid,
    authority_state character varying(24) NOT NULL,
    action_type public.activity_action_enum NOT NULL,
    summary character varying(500) NOT NULL,
    detail_json json,
    related_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_activity_logs FORCE ROW LEVEL SECURITY;


--
-- Name: agent_capability_installs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_capability_installs (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    kind character varying(30) NOT NULL,
    source_key character varying(255) NOT NULL,
    normalized_key character varying(255) NOT NULL,
    display_name character varying(255),
    status character varying(20) NOT NULL,
    installed_via character varying(30) NOT NULL,
    error_code character varying(80),
    error_message text,
    metadata_json json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_capability_installs FORCE ROW LEVEL SECURITY;


--
-- Name: agent_collaboration_group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_collaboration_group_members (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    group_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    agent_owner_user_id uuid NOT NULL,
    role character varying(32) DEFAULT 'member'::character varying NOT NULL,
    status character varying(40) DEFAULT 'pending_owner_confirmation'::character varying NOT NULL,
    invited_by_user_id uuid,
    invited_by_agent_id uuid,
    approved_by_user_id uuid,
    approved_at timestamp with time zone,
    rejected_at timestamp with time zone,
    revoked_at timestamp with time zone,
    capability_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    invitation_reason text DEFAULT ''::text NOT NULL,
    metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_collaboration_group_members FORCE ROW LEVEL SECURITY;


--
-- Name: agent_collaboration_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_collaboration_groups (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    purpose text DEFAULT ''::text NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_by_agent_id uuid,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    visibility character varying(32) DEFAULT 'group_members'::character varying NOT NULL,
    metadata_json jsonb,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_collaboration_groups FORCE ROW LEVEL SECURITY;


--
-- Name: agent_mcp_server_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_mcp_server_assignments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    mcp_server_id uuid NOT NULL,
    enabled boolean NOT NULL,
    default_tool_mode character varying(20) NOT NULL,
    always_load boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_mcp_server_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: agent_mcp_tool_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_mcp_tool_overrides (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    mcp_server_id uuid NOT NULL,
    tool_name character varying(200) NOT NULL,
    mode character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_mcp_tool_overrides FORCE ROW LEVEL SECURITY;


--
-- Name: agent_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_permissions (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type public.permission_scope_enum NOT NULL,
    scope_id uuid,
    access_level character varying(20) NOT NULL
);

ALTER TABLE ONLY public.agent_permissions FORCE ROW LEVEL SECURITY;


--
-- Name: agent_plan_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_plan_recommendations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id character varying(100) NOT NULL,
    runtime_task_id uuid,
    recommended_to_user_id uuid NOT NULL,
    source character varying(30) NOT NULL,
    intent_type character varying(30) NOT NULL,
    action_kind character varying(50) NOT NULL,
    tool_name character varying(80) NOT NULL,
    title text NOT NULL,
    original_request text NOT NULL,
    status character varying(30) NOT NULL,
    declined_by_user_id uuid,
    declined_at timestamp with time zone,
    accepted_by_user_id uuid,
    accepted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata_json jsonb
);

ALTER TABLE ONLY public.agent_plan_recommendations FORCE ROW LEVEL SECURITY;


--
-- Name: agent_plan_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_plan_requests (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id character varying(100),
    runtime_task_id uuid,
    requested_by_user_id uuid,
    source character varying(30) NOT NULL,
    intent_type character varying(30) NOT NULL,
    original_request text NOT NULL,
    status character varying(30) NOT NULL,
    plan_version integer NOT NULL,
    plan_hash character varying(80),
    plan_markdown_path text,
    plan_json jsonb NOT NULL,
    handoff_payload jsonb,
    handoff_status character varying(20),
    confirmed_by_user_id uuid,
    confirmed_at timestamp with time zone,
    rejected_by_user_id uuid,
    rejected_at timestamp with time zone,
    superseded_by_plan_id uuid,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata_json jsonb
);

ALTER TABLE ONLY public.agent_plan_requests FORCE ROW LEVEL SECURITY;


--
-- Name: agent_plugin_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_plugin_assignments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    installed_plugin_id uuid NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_plugin_assignments FORCE ROW LEVEL SECURITY;


--
-- Name: agent_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_relationships (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    member_id uuid NOT NULL,
    relation character varying(50) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_relationships FORCE ROW LEVEL SECURITY;


--
-- Name: agent_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_schedules (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    instruction text NOT NULL,
    cron_expr character varying(100) NOT NULL,
    is_enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    run_count integer NOT NULL,
    created_by uuid NOT NULL,
    delivery_target_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_schedules FORCE ROW LEVEL SECURITY;


--
-- Name: agent_session_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_session_goals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    chat_session_id uuid NOT NULL,
    created_by_user_id uuid,
    objective text NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    token_budget integer,
    tokens_used integer DEFAULT 0 NOT NULL,
    time_budget_seconds integer,
    continuation_count integer DEFAULT 0 NOT NULL,
    max_continuation_turns integer,
    blocked_count integer DEFAULT 0 NOT NULL,
    completion_summary text,
    metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);

ALTER TABLE ONLY public.agent_session_goals FORCE ROW LEVEL SECURITY;


--
-- Name: agent_team_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_team_events (
    id uuid NOT NULL,
    team_id uuid NOT NULL,
    sender_member_id uuid,
    receiver_member_id uuid,
    event_type character varying(64) NOT NULL,
    payload_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_team_events FORCE ROW LEVEL SECURITY;


--
-- Name: agent_team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_team_members (
    id uuid NOT NULL,
    team_id uuid NOT NULL,
    member_name character varying(160) NOT NULL,
    member_role text,
    model_id uuid,
    chat_session_id uuid NOT NULL,
    runtime_task_id uuid,
    runtime_task_type character varying(64) DEFAULT 'team_member'::character varying NOT NULL,
    status character varying(32) DEFAULT 'idle'::character varying NOT NULL,
    tool_policy_json jsonb,
    budget_json jsonb,
    metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone
);

ALTER TABLE ONLY public.agent_team_members FORCE ROW LEVEL SECURITY;


--
-- Name: agent_teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_teams (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    lead_agent_id uuid NOT NULL,
    parent_session_id uuid NOT NULL,
    name character varying(160) NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    transcript_truth character varying(64) DEFAULT 'chat_session_t0'::character varying NOT NULL,
    created_by_user_id uuid,
    metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone
);

ALTER TABLE ONLY public.agent_teams FORCE ROW LEVEL SECURITY;


--
-- Name: agent_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_templates (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    icon character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    soul_template text NOT NULL,
    default_skills json NOT NULL,
    is_builtin boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    department_id uuid,
    model_id uuid,
    config_version integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.agent_templates FORCE ROW LEVEL SECURITY;


--
-- Name: agent_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_tools (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    tool_id uuid NOT NULL,
    enabled boolean NOT NULL,
    mcp_trust_requested_enabled boolean,
    config json NOT NULL,
    source character varying(20) NOT NULL,
    installed_by_agent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.agent_tools FORCE ROW LEVEL SECURITY;


--
-- Name: agent_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_triggers (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    config jsonb NOT NULL,
    reason text NOT NULL,
    is_enabled boolean NOT NULL,
    last_fired_at timestamp with time zone,
    fire_count integer NOT NULL,
    max_fires integer,
    cooldown_seconds integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    reply_context jsonb
);

ALTER TABLE ONLY public.agent_triggers FORCE ROW LEVEL SECURITY;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    avatar_url character varying(500),
    role_description text NOT NULL,
    bio text,
    welcome_message text,
    creator_id uuid NOT NULL,
    sponsor_user_id uuid NOT NULL,
    participant_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_type character varying(20) NOT NULL,
    agent_class character varying(30) NOT NULL,
    security_zone character varying(30) NOT NULL,
    status public.agent_status_enum NOT NULL,
    container_id character varying(100),
    container_port integer,
    primary_model_id uuid,
    fallback_model_id uuid,
    quota_tokens_per_day integer,
    quota_tokens_per_month integer,
    tokens_used_today integer NOT NULL,
    tokens_used_month integer NOT NULL,
    last_daily_reset timestamp with time zone,
    last_monthly_reset timestamp with time zone,
    tokens_used_total integer NOT NULL,
    context_window_size integer NOT NULL,
    max_tool_rounds integer DEFAULT 200 NOT NULL,
    execution_mode character varying(30) DEFAULT 'standard'::character varying NOT NULL,
    default_session_permission_mode character varying(32) DEFAULT 'default'::character varying NOT NULL,
    smart_model_routing json,
    max_triggers integer NOT NULL,
    min_poll_interval_min integer NOT NULL,
    webhook_rate_limit integer NOT NULL,
    template_id uuid,
    heartbeat_enabled boolean NOT NULL,
    heartbeat_interval_minutes integer NOT NULL,
    heartbeat_active_hours character varying(20) NOT NULL,
    last_heartbeat_at timestamp with time zone,
    timezone character varying(50),
    parent_agent_id uuid,
    owner_user_id uuid,
    channel_perms boolean DEFAULT false NOT NULL,
    config_version integer DEFAULT 1 NOT NULL,
    subagent_evolution_auto_approve boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_active_at timestamp with time zone,
    deleted_at timestamp with time zone,
    deactivated_at timestamp with time zone,
    deactivation_reason text,
    CONSTRAINT ck_agents_default_session_permission_mode CHECK (((default_session_permission_mode)::text = ANY ((ARRAY['default'::character varying, 'auto'::character varying, 'bypassPermissions'::character varying])::text[])))
);

ALTER TABLE ONLY public.agents FORCE ROW LEVEL SECURITY;


--
-- Name: ai_asset_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_asset_records (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    asset_type character varying(40) NOT NULL,
    native_entity_id uuid,
    native_key character varying(500) NOT NULL,
    native_locator_json jsonb NOT NULL,
    display_name character varying(300) NOT NULL,
    owner_type character varying(30) NOT NULL,
    owner_id uuid,
    visibility_scope character varying(30) NOT NULL,
    lifecycle_status character varying(30) NOT NULL,
    active_revision_id uuid,
    content_hash character varying(64) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_ref text,
    trust_state character varying(30) NOT NULL,
    dependencies_json jsonb NOT NULL,
    compatibility_json jsonb NOT NULL,
    admission_state character varying(30) NOT NULL,
    quarantine_reason text,
    usage_count integer DEFAULT 0 NOT NULL,
    last_used_at timestamp with time zone,
    usage_evidence_json jsonb NOT NULL,
    projection_status character varying(30) NOT NULL,
    projection_error text,
    created_by_user_id uuid,
    created_by_agent_id uuid,
    published_by_user_id uuid,
    revoked_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_ai_asset_lifecycle_status CHECK (((lifecycle_status)::text = ANY ((ARRAY['draft'::character varying, 'active'::character varying, 'deprecated'::character varying, 'revoked'::character varying, 'deleted'::character varying, 'quarantined'::character varying])::text[]))),
    CONSTRAINT ck_ai_asset_projection_status CHECK (((projection_status)::text = ANY ((ARRAY['pending'::character varying, 'applied'::character varying, 'failed'::character varying, 'drifted'::character varying])::text[]))),
    CONSTRAINT ck_ai_asset_type CHECK (((asset_type)::text = ANY ((ARRAY['agent'::character varying, 'skill'::character varying, 'workflow'::character varying, 'subagent'::character varying, 'external_capability'::character varying])::text[])))
);

ALTER TABLE ONLY public.ai_asset_records FORCE ROW LEVEL SECURITY;


--
-- Name: ai_asset_usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_asset_usage_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    asset_revision_id uuid NOT NULL,
    revision_version integer NOT NULL,
    content_hash character varying(64) NOT NULL,
    native_key character varying(500) NOT NULL,
    source_ref text,
    usage_kind character varying(80) NOT NULL,
    usage_units integer DEFAULT 1 NOT NULL,
    idempotency_key character varying(500) NOT NULL,
    runtime_task_id character varying(100),
    session_id character varying(100),
    trace_id character varying(128),
    span_id character varying(128),
    tool_call_id character varying(200),
    evidence_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.ai_asset_usage_events FORCE ROW LEVEL SECURITY;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(255) NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    action_type character varying(100) NOT NULL,
    details json NOT NULL,
    status public.approval_status_enum NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    requested_by uuid,
    requested_by_external_principal_id uuid,
    decision_id character varying(128),
    tool_name character varying(100),
    normalized_arguments json,
    input_hash character varying(64),
    policy_snapshot json,
    policy_snapshot_hash character varying(64),
    execution_envelope json,
    execution_envelope_hash character varying(64),
    expires_at timestamp with time zone,
    consumed_at timestamp with time zone,
    execution_status character varying(32) NOT NULL,
    execution_task_id uuid,
    execution_idempotency_key character varying(200),
    execution_result text,
    execution_receipt json,
    CONSTRAINT ck_approval_requests_execution_status CHECK (((execution_status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'queued'::character varying, 'executing'::character varying, 'succeeded'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying, 'needs_reapproval'::character varying])::text[])))
);

ALTER TABLE ONLY public.approval_requests FORCE ROW LEVEL SECURITY;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    external_principal_id uuid,
    agent_id uuid,
    tenant_id uuid,
    action character varying(100) NOT NULL,
    details json NOT NULL,
    ip_address character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.audit_logs FORCE ROW LEVEL SECURITY;


--
-- Name: budget_transition_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_transition_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    budget_run_id uuid NOT NULL,
    budget_event_id uuid NOT NULL,
    transition character varying(40) NOT NULL,
    session_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    user_id uuid,
    external_principal_id uuid,
    runtime_task_id uuid,
    channel_config_id uuid,
    channel character varying(40) DEFAULT 'web'::character varying NOT NULL,
    content text NOT NULL,
    delivery_target_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    delivery_receipts_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    locked_by character varying(200),
    locked_at timestamp with time zone,
    last_error text,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_budget_transition_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'delivered'::character varying, 'dead_letter'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.budget_transition_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: capability_factor_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_factor_reviews (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    factor_id uuid NOT NULL,
    automated_report_json jsonb NOT NULL,
    admission_report_json jsonb NOT NULL,
    findings_json jsonb NOT NULL,
    dedupe_report_json jsonb NOT NULL,
    eval_report_json jsonb NOT NULL,
    decision character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.capability_factor_reviews FORCE ROW LEVEL SECURITY;


--
-- Name: capability_factors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_factors (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    originating_agent_id uuid,
    originating_user_id uuid,
    factor_kind character varying(60) NOT NULL,
    source_refs_json jsonb NOT NULL,
    trace_refs_json jsonb NOT NULL,
    artifact_ref text,
    artifact_sha256 character varying(128),
    upstream_source_ref text,
    upstream_content_sha256 character varying(128),
    license_report_json jsonb NOT NULL,
    display_name character varying(260) NOT NULL,
    summary text,
    authoring_contract_json jsonb NOT NULL,
    declared_components_json jsonb NOT NULL,
    declared_permissions_json jsonb NOT NULL,
    sensitivity_report_json jsonb NOT NULL,
    reuse_score_json jsonb NOT NULL,
    suggested_scope character varying(40),
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.capability_factors FORCE ROW LEVEL SECURITY;


--
-- Name: capability_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_policies (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    capability character varying(100) NOT NULL,
    allowed boolean NOT NULL,
    conditions jsonb NOT NULL,
    requires_approval boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.capability_policies FORCE ROW LEVEL SECURITY;


--
-- Name: capability_promotion_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_promotion_proposals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    factor_id uuid NOT NULL,
    review_id uuid,
    proposed_snapshot_kind character varying(40) NOT NULL,
    proposed_catalog_scope character varying(40) NOT NULL,
    proposed_activation_policy character varying(60) NOT NULL,
    proposed_selector_json jsonb NOT NULL,
    approver_id uuid,
    decision character varying(30) NOT NULL,
    decision_reason text,
    resulting_snapshot_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.capability_promotion_proposals FORCE ROW LEVEL SECURITY;


--
-- Name: channel_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_configs (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    channel_type public.channel_type_enum NOT NULL,
    app_id character varying(255),
    app_secret character varying(1024),
    encrypt_key character varying(1024),
    verification_token character varying(1024),
    is_configured boolean NOT NULL,
    is_connected boolean NOT NULL,
    last_tested_at timestamp with time zone,
    self_identity_user_id uuid,
    self_identity_verified_at timestamp with time zone,
    extra_config json NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_channel_configs_self_identity_channel CHECK (((self_identity_user_id IS NULL) OR ((channel_type = ANY (ARRAY['wechat_personal'::public.channel_type_enum, 'feishu'::public.channel_type_enum])) AND (self_identity_verified_at IS NOT NULL))))
);

ALTER TABLE ONLY public.channel_configs FORCE ROW LEVEL SECURITY;


--
-- Name: channel_delivery_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_delivery_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    runtime_task_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    user_id uuid,
    external_principal_id uuid,
    channel_config_id uuid,
    channel character varying(40) NOT NULL,
    target_hash character varying(64) NOT NULL,
    delivery_kind character varying(32) DEFAULT 'terminal_result'::character varying NOT NULL,
    terminal_status character varying(40) NOT NULL,
    delivery_target_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    text_content text NOT NULL,
    artifact_ids_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    delivery_receipts_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    locked_by character varying(200),
    locked_at timestamp with time zone,
    last_error text,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_channel_delivery_outbox_kind CHECK (((delivery_kind)::text = ANY ((ARRAY['terminal_result'::character varying, 'interactive_prompt'::character varying])::text[]))),
    CONSTRAINT ck_channel_delivery_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'delivered'::character varying, 'dead_letter'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.channel_delivery_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: channel_ingress_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_ingress_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    provider character varying(40) NOT NULL,
    installation_ref character varying(200) NOT NULL,
    provider_event_id character varying(512) NOT NULL,
    handler_key character varying(100) NOT NULL,
    payload_digest character varying(64) NOT NULL,
    payload_json jsonb NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) DEFAULT 'received'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    locked_by character varying(200),
    locked_at timestamp with time zone,
    last_error text,
    result_runtime_task_id uuid,
    result_session_id uuid,
    external_principal_id uuid,
    processing_receipt_json jsonb,
    processed_at timestamp with time zone,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_channel_ingress_status CHECK (((status)::text = ANY ((ARRAY['received'::character varying, 'processing'::character varying, 'failed'::character varying, 'processed'::character varying, 'dead_letter'::character varying])::text[])))
);

ALTER TABLE ONLY public.channel_ingress_events FORCE ROW LEVEL SECURITY;


--
-- Name: charter_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.charter_proposals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id character varying(64) NOT NULL,
    decision_id character varying(128) NOT NULL,
    action character varying(255) NOT NULL,
    proposal_kind character varying(64) NOT NULL,
    reason text NOT NULL,
    status character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_at timestamp with time zone,
    decided_by character varying(64),
    decision_reason text
);

ALTER TABLE ONLY public.charter_proposals FORCE ROW LEVEL SECURITY;


--
-- Name: chat_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_artifacts (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    message_id uuid NOT NULL,
    runtime_task_id uuid,
    owner_user_id uuid,
    root_session_id uuid,
    authority_state character varying(24) NOT NULL,
    path character varying(1024) NOT NULL,
    name character varying(255) NOT NULL,
    mime_type character varying(255),
    size integer,
    modified_at character varying(64),
    preview_kind character varying(32) NOT NULL,
    source character varying(64) NOT NULL,
    snapshot_hash character varying(128) NOT NULL,
    snapshot_json json,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.chat_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    external_principal_id uuid,
    role public.chat_role_enum NOT NULL,
    content text NOT NULL,
    conversation_id character varying(200) NOT NULL,
    participant_id uuid,
    thinking text,
    thinking_signature text,
    decision_trace_id character varying(128),
    source_ingress_event_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.chat_messages FORCE ROW LEVEL SECURITY;


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    external_principal_id uuid,
    title character varying(200) NOT NULL,
    source_channel character varying(20) NOT NULL,
    external_conv_id character varying(200),
    participant_id uuid,
    peer_agent_id uuid,
    delivery_target_json jsonb,
    session_kind character varying(64) NOT NULL,
    actor_type character varying(32) NOT NULL,
    runtime_source character varying(64) NOT NULL,
    visibility_scope character varying(64) NOT NULL,
    listed_surface character varying(64) NOT NULL,
    parent_session_id uuid,
    root_session_id uuid,
    runtime_task_id uuid,
    transcript_metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_message_at timestamp with time zone,
    summary text,
    summary_through_sequence bigint
);

ALTER TABLE ONLY public.chat_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: chat_transcript_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_transcript_events (
    id uuid NOT NULL,
    sequence bigint NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    run_id uuid,
    parent_event_id uuid,
    root_session_id uuid,
    parent_session_id uuid,
    message_id uuid,
    schema_version integer DEFAULT 1 NOT NULL,
    item_id uuid,
    item_kind character varying(64),
    lifecycle character varying(40),
    payload_schema character varying(200),
    scope_json jsonb,
    ordinal integer,
    command_id uuid,
    input_id uuid,
    result_id uuid,
    invocation_id uuid,
    provider_tool_use_id character varying(300),
    content_hash character varying(64),
    parent_item_id uuid,
    item_type character varying(64) DEFAULT 'event'::character varying NOT NULL,
    item_status character varying(32) DEFAULT 'succeeded'::character varying NOT NULL,
    turn_id character varying(200),
    causation_id uuid,
    correlation_id uuid,
    actor_type character varying(32) NOT NULL,
    event_type character varying(64) NOT NULL,
    visibility_scope character varying(64) NOT NULL,
    listed_surface character varying(64) NOT NULL,
    content text,
    parts_json jsonb,
    metadata_json jsonb,
    projection_status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    projection_attempts integer DEFAULT 0 NOT NULL,
    projection_error text,
    projected_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_chat_transcript_events_v2_envelope CHECK (((schema_version <> 2) OR ((item_id IS NOT NULL) AND (item_kind IS NOT NULL) AND (lifecycle IS NOT NULL) AND (payload_schema IS NOT NULL) AND (scope_json IS NOT NULL) AND ((event_type)::text = (((item_kind)::text || '.'::text) || (lifecycle)::text)) AND ((payload_schema)::text = (((('hive.session.payload.'::text || (item_kind)::text) || '.'::text) || (lifecycle)::text) || '.v2'::text)))))
);

ALTER TABLE ONLY public.chat_transcript_events FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type character varying(120) NOT NULL,
    actor_type character varying(30) NOT NULL,
    actor_id uuid NOT NULL,
    accountable_user_id uuid NOT NULL,
    resource_type character varying(80) NOT NULL,
    resource_id uuid,
    resource_version integer,
    source_refs_json jsonb NOT NULL,
    source_hash character varying(64),
    policy_snapshot_json jsonb NOT NULL,
    trace_id character varying(300) NOT NULL,
    request_id character varying(300),
    idempotency_key character varying(300) NOT NULL,
    outcome character varying(40) NOT NULL,
    payload_json jsonb NOT NULL,
    stream_sequence bigint NOT NULL,
    prev_hash character varying(64) NOT NULL,
    event_hash character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.company_knowledge_events FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_evidence (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_id uuid NOT NULL,
    source_contract_id uuid NOT NULL,
    source_contract_version integer NOT NULL,
    evidence_kind character varying(40) NOT NULL,
    source_item_id character varying(500) NOT NULL,
    source_revision character varying(300) NOT NULL,
    artifact_ref character varying(1000),
    schema_ref character varying(1000),
    typed_payload_ref character varying(1000),
    canonical_envelope_json jsonb NOT NULL,
    content_hash character varying(64) NOT NULL,
    source_acl_snapshot_hash character varying(64) NOT NULL,
    source_acl_snapshot_json jsonb NOT NULL,
    occurred_at timestamp with time zone,
    effective_from timestamp with time zone,
    effective_until timestamp with time zone,
    observed_at timestamp with time zone NOT NULL,
    cursor_json jsonb NOT NULL,
    sequence character varying(300),
    idempotency_key character varying(300) NOT NULL,
    coverage_ledger_ref character varying(1000) NOT NULL,
    coverage_ledger_json jsonb NOT NULL,
    ingestion_receipt_ref character varying(1000) NOT NULL,
    status character varying(40) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_evidence_kind CHECK (((evidence_kind)::text = ANY ((ARRAY['document'::character varying, 'structured_record'::character varying, 'event'::character varying, 'living_object_revision'::character varying, 'external_immutable_ref'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_evidence_status CHECK (((status)::text = ANY ((ARRAY['accepted'::character varying, 'blocked_source_authority'::character varying, 'quarantined'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_evidence FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_import_jobs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_contract_id uuid NOT NULL,
    source_contract_version integer NOT NULL,
    idempotency_key character varying(300) NOT NULL,
    request_hash character varying(64) NOT NULL,
    request_json jsonb NOT NULL,
    artifact_ref character varying(1000),
    artifact_hash character varying(64) NOT NULL,
    status character varying(30) NOT NULL,
    available_at timestamp with time zone NOT NULL,
    claim_token uuid,
    claim_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    last_error_code character varying(120),
    last_error text,
    source_id uuid,
    evidence_id uuid,
    document_id uuid,
    proposal_id uuid,
    created_by_type character varying(30) NOT NULL,
    created_by_id uuid NOT NULL,
    accountable_user_id uuid NOT NULL,
    trace_id character varying(300) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_company_knowledge_import_job_attempts CHECK (((attempt_count >= 0) AND (max_attempts > 0))),
    CONSTRAINT ck_company_knowledge_import_job_status CHECK (((status)::text = ANY ((ARRAY['queued'::character varying, 'running'::character varying, 'completed'::character varying, 'held'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_import_jobs FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    aggregate_type character varying(80) NOT NULL,
    aggregate_id uuid NOT NULL,
    event_id uuid NOT NULL,
    event_type character varying(120) NOT NULL,
    idempotency_key character varying(300) NOT NULL,
    payload_json jsonb NOT NULL,
    payload_hash character varying(64) NOT NULL,
    status character varying(30) NOT NULL,
    available_at timestamp with time zone NOT NULL,
    claim_token uuid,
    claim_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 8 NOT NULL,
    last_error text,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_proposals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    idempotency_key character varying(300) NOT NULL,
    proposal_kind character varying(40) NOT NULL,
    source_id uuid,
    source_document_id uuid,
    source_revision_ref character varying(1000),
    baseline_publication_id uuid,
    baseline_version integer,
    materialized_document_id uuid,
    materialization_content_hash character varying(64),
    materialization_receipt_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    materialization_idempotency_key character varying(300),
    materialized_by_user_id uuid,
    materialized_at timestamp with time zone,
    proposed_patch_json jsonb NOT NULL,
    proposed_content_hash character varying(64) NOT NULL,
    proposed_namespace character varying(300) NOT NULL,
    proposed_sensitivity character varying(30) NOT NULL,
    source_refs_json jsonb NOT NULL,
    source_coverage_json jsonb NOT NULL,
    conflict_candidates_json jsonb NOT NULL,
    ontology_mapping_json jsonb NOT NULL,
    status character varying(40) NOT NULL,
    risk_level character varying(20) NOT NULL,
    required_review_policy_json jsonb NOT NULL,
    created_by_type character varying(30) NOT NULL,
    created_by_id uuid NOT NULL,
    accountable_user_id uuid NOT NULL,
    submitted_at timestamp with time zone,
    state_version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_proposal_kind CHECK (((proposal_kind)::text = ANY ((ARRAY['knowledge'::character varying, 'ontology'::character varying, 'combined'::character varying, 'personal_promotion'::character varying, 'living_object'::character varying, 'legacy_import'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_proposal_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'submitted'::character varying, 'in_review'::character varying, 'changes_requested'::character varying, 'approved'::character varying, 'rejected'::character varying, 'withdrawn'::character varying, 'publishing'::character varying, 'published'::character varying, 'publish_failed'::character varying, 'superseded'::character varying, 'retired'::character varying, 'restored'::character varying])::text[]))),
    CONSTRAINT ck_company_kp_sensitivity CHECK (((proposed_sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_proposals FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_publications (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    logical_resource_key character varying(500) NOT NULL,
    document_id uuid NOT NULL,
    version integer NOT NULL,
    content_hash character varying(64) NOT NULL,
    artifact_ref character varying(1000) NOT NULL,
    proposal_id uuid NOT NULL,
    review_set_hash character varying(64) NOT NULL,
    namespace character varying(300) NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    source_refs_json jsonb NOT NULL,
    evidence_bundle_refs_json jsonb NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    status character varying(30) NOT NULL,
    supersedes_publication_id uuid,
    rollback_ref character varying(1000) NOT NULL,
    companion_release_ref character varying(500),
    published_by_user_id uuid NOT NULL,
    published_at timestamp with time zone NOT NULL,
    retired_at timestamp with time zone,
    restored_from_publication_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_publication_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_publication_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_publications FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_reviews (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    proposal_id uuid NOT NULL,
    reviewer_user_id uuid NOT NULL,
    reviewer_role character varying(80) NOT NULL,
    review_round integer NOT NULL,
    subject_content_hash character varying(64) NOT NULL,
    decision character varying(30) NOT NULL,
    reason text NOT NULL,
    evidence_refs_json jsonb NOT NULL,
    policy_snapshot_json jsonb NOT NULL,
    decision_hash character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_review_decision CHECK (((decision)::text = ANY ((ARRAY['approve'::character varying, 'reject'::character varying, 'request_changes'::character varying, 'abstain'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_reviews FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_source_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_source_contracts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    version integer NOT NULL,
    status character varying(30) NOT NULL,
    source_kind character varying(50) NOT NULL,
    provider_kind character varying(80) NOT NULL,
    stable_source_id character varying(300) NOT NULL,
    owner_principal_ref character varying(300) NOT NULL,
    accountable_steward_ref character varying(300) NOT NULL,
    connection_ref character varying(512),
    schema_ref character varying(512),
    schema_version character varying(120),
    identity_keys_json jsonb NOT NULL,
    relation_keys_json jsonb NOT NULL,
    ingest_mode character varying(30) NOT NULL,
    cursor_kind character varying(80),
    cursor_policy_json jsonb NOT NULL,
    watermark_field character varying(300),
    temporal_mapping_json jsonb NOT NULL,
    source_acl_mapping_policy_json jsonb NOT NULL,
    default_sensitivity character varying(30) DEFAULT 'PL1_public'::character varying NOT NULL,
    export_policy_json jsonb NOT NULL,
    retention_policy_json jsonb NOT NULL,
    legal_hold_policy_json jsonb NOT NULL,
    allowed_namespaces_json jsonb NOT NULL,
    precedence_policy_ref character varying(512),
    acceptance_suite_ref character varying(512),
    idempotency_policy_json jsonb NOT NULL,
    contract_hash character varying(64) NOT NULL,
    created_by_user_id uuid NOT NULL,
    reviewed_by_json jsonb NOT NULL,
    effective_from timestamp with time zone,
    retired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_source_contract_ingest_mode CHECK (((ingest_mode)::text = ANY ((ARRAY['manual'::character varying, 'snapshot'::character varying, 'incremental'::character varying, 'cdc'::character varying, 'webhook'::character varying, 'reference'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_source_contract_sensitivity CHECK (((default_sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_source_contract_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'active'::character varying, 'retired'::character varying, 'blocked_drift'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_source_contracts FORCE ROW LEVEL SECURITY;


--
-- Name: company_knowledge_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_knowledge_sources (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_contract_id uuid NOT NULL,
    source_contract_version integer NOT NULL,
    source_item_id character varying(500) NOT NULL,
    source_revision character varying(300) NOT NULL,
    namespace character varying(300) NOT NULL,
    sensitivity character varying(30) NOT NULL,
    canonical_artifact_ref character varying(1000),
    content_hash character varying(64) NOT NULL,
    source_acl_snapshot_hash character varying(64) NOT NULL,
    source_acl_snapshot_json jsonb NOT NULL,
    retention_state_json jsonb NOT NULL,
    legal_hold boolean DEFAULT false NOT NULL,
    cursor_json jsonb NOT NULL,
    lineage_json jsonb NOT NULL,
    status character varying(40) NOT NULL,
    status_reason text,
    created_by_type character varying(30) NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_knowledge_source_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_knowledge_source_status CHECK (((status)::text = ANY ((ARRAY['registered'::character varying, 'ingested'::character varying, 'blocked_source_authority'::character varying, 'drifted'::character varying, 'retired'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_knowledge_sources FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_action_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_action_types (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    action_type_ref character varying(500) NOT NULL,
    input_schema_json jsonb NOT NULL,
    output_schema_json jsonb NOT NULL,
    required_capability character varying(300) NOT NULL,
    tool_workflow_mapping_json jsonb NOT NULL,
    approval_policy_json jsonb NOT NULL,
    side_effect_classification character varying(80) NOT NULL,
    simulation_contract_json jsonb NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_action_type_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_action_types FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_activations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_activations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    installation_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    activation_version integer NOT NULL,
    idempotency_key character varying(300) NOT NULL,
    configuration_json jsonb NOT NULL,
    dry_run_receipt_json jsonb NOT NULL,
    status character varying(30) NOT NULL,
    supersedes_activation_id uuid,
    activated_by_user_id uuid,
    activated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_activation_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'dry_run_passed'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'blocked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_activations FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_assertions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_assertions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    stable_assertion_key character varying(500) NOT NULL,
    subject_object_id uuid NOT NULL,
    predicate_ref character varying(500) NOT NULL,
    object_id uuid,
    typed_value_json jsonb,
    assertion_kind character varying(30) NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    observed_at timestamp with time zone NOT NULL,
    evidence_bundle_refs_json jsonb NOT NULL,
    derived_by_rule_ref character varying(500),
    curation_run_id uuid NOT NULL,
    release_id uuid NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    supersedes_assertion_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_assertion_kind CHECK (((assertion_kind)::text = ANY ((ARRAY['sourced'::character varying, 'derived'::character varying, 'tenant_authored'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_assertion_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_assertion_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'held'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_assertions FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_curation_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_curation_runs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    runtime_task_id uuid,
    activation_id uuid NOT NULL,
    baseline_release_id uuid,
    idempotency_key character varying(300) NOT NULL,
    source_contract_versions_json jsonb NOT NULL,
    evidence_scope_json jsonb NOT NULL,
    authority_snapshot_json jsonb NOT NULL,
    requested_operations_json jsonb NOT NULL,
    model_prompt_receipts_json jsonb NOT NULL,
    candidate_patch_ref character varying(1000),
    candidate_patch_hash character varying(64),
    candidate_patch_json jsonb NOT NULL,
    coverage_ledger_json jsonb NOT NULL,
    conflict_ledger_json jsonb NOT NULL,
    unresolved_questions_json jsonb NOT NULL,
    acceptance_result_json jsonb NOT NULL,
    status character varying(30) NOT NULL,
    retry_state_json jsonb NOT NULL,
    checkpoint_ref character varying(1000),
    error_code character varying(120),
    created_by_type character varying(30) NOT NULL,
    created_by_id uuid NOT NULL,
    accountable_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_curation_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'checkpointed'::character varying, 'held'::character varying, 'quarantined'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_curation_runs FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_event_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_event_types (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    event_type_ref character varying(500) NOT NULL,
    schema_json jsonb NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_event_type_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_event_types FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    stable_event_key character varying(500) NOT NULL,
    event_type_ref character varying(500) NOT NULL,
    subject_object_id uuid,
    payload_json jsonb NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    effective_from timestamp with time zone,
    effective_until timestamp with time zone,
    observed_at timestamp with time zone NOT NULL,
    sequence character varying(300),
    evidence_bundle_refs_json jsonb NOT NULL,
    curation_run_id uuid NOT NULL,
    release_id uuid NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_event_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_event_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'held'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_events FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_evidence_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_evidence_bindings (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subject_kind character varying(40) NOT NULL,
    subject_id uuid NOT NULL,
    bundle_key character varying(500) NOT NULL,
    support_mode character varying(40) NOT NULL,
    evidence_id uuid NOT NULL,
    source_acl_snapshot_hash character varying(64) NOT NULL,
    status character varying(40) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_evidence_binding_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'held_for_authority_review'::character varying, 'revoked'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_evidence_support_mode CHECK (((support_mode)::text = ANY ((ARRAY['joint'::character varying, 'independent_sufficient'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_evidence_bindings FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_link_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_link_types (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    link_type_ref character varying(500) NOT NULL,
    from_type_refs_json jsonb NOT NULL,
    to_type_refs_json jsonb NOT NULL,
    schema_json jsonb NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_link_type_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_link_types FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_links (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    stable_link_key character varying(500) NOT NULL,
    link_type_ref character varying(500) NOT NULL,
    from_object_id uuid NOT NULL,
    to_object_id uuid NOT NULL,
    properties_json jsonb NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    observed_at timestamp with time zone NOT NULL,
    evidence_bundle_refs_json jsonb NOT NULL,
    curation_run_id uuid NOT NULL,
    release_id uuid NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    supersedes_link_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_link_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_link_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'held'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_links FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_object_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_object_identities (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    object_id uuid NOT NULL,
    source_contract_id uuid NOT NULL,
    source_identity_key character varying(700) NOT NULL,
    aliases_json jsonb NOT NULL,
    lineage_json jsonb NOT NULL,
    curation_run_id uuid NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_object_identity_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'merged'::character varying, 'split'::character varying, 'held'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_object_identities FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_object_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_object_types (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    type_ref character varying(500) NOT NULL,
    schema_json jsonb NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_object_type_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_object_types FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_objects (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    stable_object_key character varying(500) NOT NULL,
    namespace character varying(300) NOT NULL,
    object_type_ref character varying(500) NOT NULL,
    display_name character varying(500) NOT NULL,
    properties_json jsonb NOT NULL,
    release_id uuid NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    observed_at timestamp with time zone NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    supersedes_object_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_object_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_object_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'held'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_objects FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_package_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_package_installations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    package_version_id uuid NOT NULL,
    status character varying(30) NOT NULL,
    requested_capabilities_json jsonb NOT NULL,
    compatibility_receipt_json jsonb NOT NULL,
    acceptance_receipt_json jsonb NOT NULL,
    installed_by_user_id uuid NOT NULL,
    installed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_package_installation_status CHECK (((status)::text = ANY ((ARRAY['installed'::character varying, 'blocked'::character varying, 'uninstalled'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_package_installations FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_package_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_package_versions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    package_id uuid NOT NULL,
    version character varying(120) NOT NULL,
    content_hash character varying(64) NOT NULL,
    signature character varying(1000) NOT NULL,
    signature_key_ref character varying(500) NOT NULL,
    hive_contract_version character varying(120) NOT NULL,
    engine_capabilities_json jsonb NOT NULL,
    namespaces_json jsonb NOT NULL,
    dependencies_json jsonb NOT NULL,
    conflicts_json jsonb NOT NULL,
    manifest_json jsonb NOT NULL,
    schema_json jsonb NOT NULL,
    mappings_json jsonb NOT NULL,
    rules_json jsonb NOT NULL,
    queries_json jsonb NOT NULL,
    actions_json jsonb NOT NULL,
    permissions_json jsonb NOT NULL,
    acceptance_json jsonb NOT NULL,
    migrations_json jsonb NOT NULL,
    admission_status character varying(30) NOT NULL,
    admission_receipt_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_package_admission CHECK (((admission_status)::text = ANY ((ARRAY['pending'::character varying, 'admitted'::character varying, 'rejected'::character varying, 'incompatible'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_package_versions FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_packages (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    package_key character varying(240) NOT NULL,
    display_name character varying(300) NOT NULL,
    publisher character varying(300) NOT NULL,
    description text NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_package_status CHECK (((status)::text = ANY ((ARRAY['available'::character varying, 'retired'::character varying, 'blocked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_packages FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_property_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_property_types (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    property_ref character varying(500) NOT NULL,
    owner_type_ref character varying(500) NOT NULL,
    value_schema_json jsonb NOT NULL,
    cardinality_json jsonb NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_property_type_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_property_types FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_release_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_release_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    item_kind character varying(50) NOT NULL,
    item_id uuid NOT NULL,
    item_hash character varying(64) NOT NULL,
    source_refs_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.company_ontology_release_items FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_releases (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    version integer NOT NULL,
    activation_id uuid NOT NULL,
    package_version_id uuid NOT NULL,
    curation_run_id uuid NOT NULL,
    proposal_id uuid NOT NULL,
    release_hash character varying(64) NOT NULL,
    review_set_hash character varying(64) NOT NULL,
    source_coverage_json jsonb NOT NULL,
    conflict_ledger_json jsonb NOT NULL,
    unresolved_questions_json jsonb NOT NULL,
    deterministic_validation_json jsonb NOT NULL,
    semantic_review_receipts_json jsonb NOT NULL,
    acceptance_result_json jsonb NOT NULL,
    migration_plan_json jsonb NOT NULL,
    rollback_ref character varying(1000) NOT NULL,
    projection_rebuild_plan_json jsonb NOT NULL,
    status character varying(30) NOT NULL,
    supersedes_release_id uuid,
    restored_from_release_id uuid,
    published_by_user_id uuid NOT NULL,
    published_at timestamp with time zone NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    retired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_release_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying, 'publish_failed'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_releases FORCE ROW LEVEL SECURITY;


--
-- Name: company_ontology_rule_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_ontology_rule_definitions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    release_id uuid NOT NULL,
    namespace character varying(300) NOT NULL,
    rule_ref character varying(500) NOT NULL,
    rule_kind character varying(80) NOT NULL,
    owner_principal_ref character varying(500) NOT NULL,
    version integer NOT NULL,
    scope_json jsonb NOT NULL,
    input_schema_json jsonb NOT NULL,
    output_schema_json jsonb NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    source_refs_json jsonb NOT NULL,
    examples_json jsonb NOT NULL,
    counterexamples_json jsonb NOT NULL,
    risk character varying(40) NOT NULL,
    review_policy_json jsonb NOT NULL,
    conflict_precedence_json jsonb NOT NULL,
    evaluation_mode character varying(50) NOT NULL,
    acceptance_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    permission_resource_ref character varying(500) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_company_ontology_rule_evaluation CHECK (((evaluation_mode)::text = ANY ((ARRAY['deterministic_typed'::character varying, 'llm_semantic_candidate'::character varying, 'human_decision'::character varying, 'external_authoritative_result'::character varying])::text[]))),
    CONSTRAINT ck_company_ontology_rule_status CHECK (((status)::text = ANY ((ARRAY['candidate'::character varying, 'active'::character varying, 'superseded'::character varying, 'retired'::character varying, 'revoked'::character varying])::text[])))
);

ALTER TABLE ONLY public.company_ontology_rule_definitions FORCE ROW LEVEL SECURITY;


--
-- Name: config_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_revisions (
    id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    version integer NOT NULL,
    content_hash character varying(64) NOT NULL,
    content jsonb NOT NULL,
    diff_from_prev jsonb,
    change_source character varying(20) NOT NULL,
    changed_by_user_id uuid,
    changed_by_agent_id uuid,
    change_message text NOT NULL,
    is_active boolean NOT NULL,
    parent_revision_id uuid,
    rollback_of_revision_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.config_revisions FORCE ROW LEVEL SECURITY;


--
-- Name: coordination_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coordination_checkpoints (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    action character varying(255) NOT NULL,
    approver_id character varying(64) NOT NULL,
    escalation_chain jsonb NOT NULL,
    deadline_at timestamp with time zone NOT NULL,
    current_approver_id character varying(64) NOT NULL,
    status character varying(32) NOT NULL,
    metadata jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.coordination_checkpoints FORCE ROW LEVEL SECURITY;


--
-- Name: coordination_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coordination_leases (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    task_key character varying(255) NOT NULL,
    agent_id character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.coordination_leases FORCE ROW LEVEL SECURITY;


--
-- Name: coordination_signals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coordination_signals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    from_agent_id character varying(512) NOT NULL,
    to_agent_id character varying(512) NOT NULL,
    content character varying NOT NULL,
    signal_type character varying(128) NOT NULL,
    thread_id character varying(512) NOT NULL,
    metadata jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.coordination_signals FORCE ROW LEVEL SECURITY;


--
-- Name: decision_trace_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_trace_feedback (
    id uuid NOT NULL,
    decision_id character varying(128) NOT NULL,
    tenant_id uuid NOT NULL,
    refs character varying(160) NOT NULL,
    reaction character varying(80) NOT NULL,
    polarity character varying(40) NOT NULL,
    source character varying(80) NOT NULL,
    rationale_from_owner text NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.decision_trace_feedback FORCE ROW LEVEL SECURITY;


--
-- Name: decision_traces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decision_traces (
    id uuid NOT NULL,
    decision_id character varying(128) NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    session_id character varying(255),
    message_id character varying(255),
    tool_name character varying(200),
    checkpoint_id character varying(128),
    action character varying(255) NOT NULL,
    chosen character varying(80) NOT NULL,
    reasoning text NOT NULL,
    alternatives_json jsonb NOT NULL,
    situational_factors_json jsonb NOT NULL,
    charter_zone character varying(80) NOT NULL,
    preflight_json jsonb NOT NULL,
    sensitivity character varying(80) NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.decision_traces FORCE ROW LEVEL SECURITY;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    parent_id uuid,
    manager_id uuid,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.departments FORCE ROW LEVEL SECURITY;


--
-- Name: enterprise_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise_info (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    info_type character varying(50) NOT NULL,
    content json NOT NULL,
    version integer NOT NULL,
    visible_roles json NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.enterprise_info FORCE ROW LEVEL SECURITY;


--
-- Name: external_capability_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_capability_reviews (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_format character varying(60) NOT NULL,
    source_uri text NOT NULL,
    source_ref character varying(300),
    source_hash character varying(128) NOT NULL,
    normalized_name character varying(200) NOT NULL,
    status character varying(30) NOT NULL,
    admission_class character varying(40) NOT NULL,
    admission_report_json jsonb NOT NULL,
    governance_projection_json jsonb NOT NULL,
    normalized_manifest_json jsonb NOT NULL,
    created_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_capability_reviews FORCE ROW LEVEL SECURITY;


--
-- Name: external_capability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_capability_snapshots (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    review_id uuid NOT NULL,
    snapshot_key character varying(260) NOT NULL,
    source_format character varying(60) NOT NULL,
    source_uri text NOT NULL,
    source_ref character varying(300),
    source_hash character varying(128) NOT NULL,
    normalized_name character varying(200) NOT NULL,
    status character varying(30) NOT NULL,
    admission_class character varying(40) NOT NULL,
    admission_report_json jsonb NOT NULL,
    governance_projection_json jsonb NOT NULL,
    component_manifest_json jsonb NOT NULL,
    approved_by_user_id uuid,
    approved_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_by_user_id uuid,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_capability_snapshots FORCE ROW LEVEL SECURITY;


--
-- Name: external_extension_activations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_extension_activations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    status character varying(30) NOT NULL,
    activation_scope character varying(30) NOT NULL,
    session_id uuid,
    component_types_json jsonb NOT NULL,
    selected_components_json jsonb NOT NULL,
    credential_handles_json jsonb NOT NULL,
    activation_result_json jsonb NOT NULL,
    activated_by_user_id uuid,
    activated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_extension_activations FORCE ROW LEVEL SECURITY;


--
-- Name: external_extension_catalog_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_extension_catalog_entries (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    component_type character varying(40) NOT NULL,
    component_name character varying(200) NOT NULL,
    qualified_name character varying(300) NOT NULL,
    policy character varying(40) NOT NULL,
    status character varying(30) NOT NULL,
    source_format character varying(60) NOT NULL,
    source_uri text NOT NULL,
    metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_extension_catalog_entries FORCE ROW LEVEL SECURITY;


--
-- Name: external_extension_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_extension_components (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    component_type character varying(40) NOT NULL,
    component_name character varying(200) NOT NULL,
    qualified_name character varying(300) NOT NULL,
    source_path text,
    content_sha256 character varying(128),
    status character varying(30) NOT NULL,
    runtime_projection_json jsonb NOT NULL,
    metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_extension_components FORCE ROW LEVEL SECURITY;


--
-- Name: external_extension_hook_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_extension_hook_registrations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    component_id uuid,
    qualified_name character varying(300) NOT NULL,
    event character varying(80) NOT NULL,
    handler character varying(200) NOT NULL,
    mode character varying(30) NOT NULL,
    matcher_json jsonb NOT NULL,
    approval_required boolean NOT NULL,
    status character varying(30) NOT NULL,
    approval_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_extension_hook_registrations FORCE ROW LEVEL SECURITY;


--
-- Name: external_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_identities (
    id uuid NOT NULL,
    provider_id uuid NOT NULL,
    user_id uuid NOT NULL,
    provider_user_id character varying(255),
    provider_open_id character varying(255),
    provider_union_id character varying(255),
    email character varying(255),
    mobile character varying(64),
    raw_profile jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_identities FORCE ROW LEVEL SECURITY;


--
-- Name: external_marketplace_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_marketplace_entries (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_id uuid NOT NULL,
    external_key character varying(260) NOT NULL,
    display_name character varying(260) NOT NULL,
    description text,
    source_format character varying(60) NOT NULL,
    source_uri text NOT NULL,
    source_ref character varying(300),
    status character varying(30) NOT NULL,
    manifest_json jsonb NOT NULL,
    compatibility_json jsonb NOT NULL,
    review_id uuid,
    snapshot_id uuid,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_marketplace_entries FORCE ROW LEVEL SECURITY;


--
-- Name: external_marketplace_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_marketplace_sources (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    source_type character varying(60) NOT NULL,
    source_uri text NOT NULL,
    status character varying(30) NOT NULL,
    sync_status character varying(30) NOT NULL,
    last_sync_error text,
    config_json jsonb NOT NULL,
    created_by_user_id uuid,
    last_sync_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_marketplace_sources FORCE ROW LEVEL SECURITY;


--
-- Name: external_principal_binding_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_principal_binding_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    external_principal_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    previous_user_id uuid,
    new_user_id uuid,
    actor_user_id uuid,
    reason text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_external_principal_binding_events_action CHECK (((action)::text = ANY ((ARRAY['linked'::character varying, 'unlinked'::character varying, 'revoked'::character varying, 'reactivated'::character varying])::text[])))
);

ALTER TABLE ONLY public.external_principal_binding_events FORCE ROW LEVEL SECURITY;


--
-- Name: external_principals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_principals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    provider character varying(40) NOT NULL,
    installation_ref character varying(200) NOT NULL,
    channel_config_id uuid,
    subject_id character varying(512) NOT NULL,
    display_name character varying(200) NOT NULL,
    profile_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    linked_user_id uuid,
    binding_method character varying(40),
    binding_verified_at timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    linked_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_external_principals_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'revoked'::character varying])::text[]))),
    CONSTRAINT ck_external_principals_verified_binding CHECK (((linked_user_id IS NULL) OR ((linked_at IS NOT NULL) AND ((((provider)::text = 'wechat_personal'::text) AND ((binding_method)::text = 'wechat_qr'::text)) OR (((provider)::text = 'feishu'::text) AND ((binding_method)::text = 'feishu_qr'::text))) AND (binding_verified_at IS NOT NULL))))
);

ALTER TABLE ONLY public.external_principals FORCE ROW LEVEL SECURITY;


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    description text NOT NULL,
    flag_type character varying(20) NOT NULL,
    enabled boolean NOT NULL,
    rollout_percentage integer,
    allowed_tenant_ids uuid[],
    allowed_user_ids uuid[],
    overrides jsonb,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);

ALTER TABLE ONLY public.feature_flags FORCE ROW LEVEL SECURITY;


--
-- Name: guard_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guard_policies (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    zone_guard jsonb DEFAULT '{}'::jsonb NOT NULL,
    egress_guard jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.guard_policies FORCE ROW LEVEL SECURITY;


--
-- Name: hr_creation_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_creation_drafts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    hr_agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    requested_by_user_id uuid NOT NULL,
    status character varying(32) NOT NULL,
    blueprint_version integer NOT NULL,
    blueprint_hash character varying(80) NOT NULL,
    blueprint_json jsonb NOT NULL,
    preview_json jsonb NOT NULL,
    confirmed_by_user_id uuid,
    confirmed_at timestamp with time zone,
    rejected_by_user_id uuid,
    rejected_at timestamp with time zone,
    creation_idempotency_key character varying(200),
    provisioning_task_id uuid,
    claim_token uuid,
    claim_version integer NOT NULL,
    claim_heartbeat_at timestamp with time zone,
    claim_expires_at timestamp with time zone,
    attempt_count integer NOT NULL,
    created_agent_id uuid,
    provisioning_json jsonb NOT NULL,
    failure_code character varying(100),
    failure_message text,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_hr_creation_draft_status CHECK (((status)::text = ANY ((ARRAY['awaiting_confirmation'::character varying, 'confirmed'::character varying, 'creating'::character varying, 'provisioning'::character varying, 'completed'::character varying, 'failed'::character varying, 'rejected'::character varying, 'superseded'::character varying, 'expired'::character varying])::text[])))
);

ALTER TABLE ONLY public.hr_creation_drafts FORCE ROW LEVEL SECURITY;


--
-- Name: hr_provisioning_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hr_provisioning_steps (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    draft_id uuid NOT NULL,
    step_key character varying(160) NOT NULL,
    step_kind character varying(64) NOT NULL,
    order_index integer NOT NULL,
    required boolean NOT NULL,
    status character varying(32) NOT NULL,
    input_hash character varying(80) NOT NULL,
    source_key text,
    attempt_count integer NOT NULL,
    claim_version integer,
    started_at timestamp with time zone,
    heartbeat_at timestamp with time zone,
    completed_at timestamp with time zone,
    receipt_json jsonb NOT NULL,
    error_code character varying(100),
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_hr_provisioning_step_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'skipped'::character varying, 'waiting_review'::character varying])::text[])))
);

ALTER TABLE ONLY public.hr_provisioning_steps FORCE ROW LEVEL SECURITY;


--
-- Name: identity_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_providers (
    id uuid NOT NULL,
    provider_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean NOT NULL,
    sso_login_enabled boolean NOT NULL,
    config jsonb NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.identity_providers FORCE ROW LEVEL SECURITY;


--
-- Name: invitation_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invitation_codes (
    id uuid NOT NULL,
    code character varying(32) NOT NULL,
    tenant_id uuid NOT NULL,
    max_uses integer NOT NULL,
    used_count integer NOT NULL,
    is_active boolean NOT NULL,
    created_by uuid,
    granted_role character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_invitation_codes_granted_role CHECK (((granted_role)::text = ANY ((ARRAY['member'::character varying, 'org_admin'::character varying])::text[])))
);

ALTER TABLE ONLY public.invitation_codes FORCE ROW LEVEL SECURITY;


--
-- Name: invocation_spans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invocation_spans (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    execution_identity_type character varying(20),
    execution_identity_id uuid,
    execution_identity_label character varying(200),
    runtime_task_id uuid,
    session_id character varying(255),
    request_id uuid,
    decision_id character varying(128),
    input_hash character varying(64),
    claim_version integer,
    idempotency_key character varying(200),
    side_effect_refs jsonb NOT NULL,
    trace_id character varying(255) NOT NULL,
    span_id character varying(80) NOT NULL,
    parent_span_id character varying(80),
    parent_trace_id character varying(255),
    span_type character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    status character varying(30) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    duration_ms double precision NOT NULL,
    usage jsonb,
    evidence_refs jsonb NOT NULL,
    truth_evidence_json jsonb NOT NULL,
    metadata_json jsonb NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.invocation_spans FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_assertions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_assertions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    source_document_id uuid,
    subject_entity_id uuid,
    subject_text character varying(300) NOT NULL,
    predicate character varying(120) NOT NULL,
    object_entity_id uuid,
    object_text text NOT NULL,
    confidence double precision NOT NULL,
    status character varying(40) NOT NULL,
    source_refs_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.knowledge_assertions FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_documents (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    owner_user_id uuid,
    source_kind character varying(40) NOT NULL,
    source_uri text,
    source_sha256 character varying(64) NOT NULL,
    artifact_hash character varying(128),
    title character varying(300) NOT NULL,
    status character varying(40) NOT NULL,
    sensitivity character varying(30) DEFAULT 'PL1_public'::character varying NOT NULL,
    agent_searchable boolean NOT NULL,
    canonical_md_path text NOT NULL,
    canonical_md_sha256 character varying(64),
    doc_metadata_json jsonb NOT NULL,
    created_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_knowledge_documents_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[])))
);

ALTER TABLE ONLY public.knowledge_documents FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_entities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_entities (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    canonical_name character varying(300) NOT NULL,
    entity_type character varying(80) NOT NULL,
    aliases_json jsonb NOT NULL,
    description text,
    confidence double precision NOT NULL,
    merged_into_entity_id uuid,
    source_refs_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.knowledge_entities FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_grants (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    resource_type character varying(30) NOT NULL,
    resource_id uuid NOT NULL,
    document_id uuid,
    grantee_type character varying(30) NOT NULL,
    grantee_id uuid NOT NULL,
    permission character varying(30) NOT NULL,
    requester_user_id uuid,
    session_id character varying(255),
    purpose character varying(80),
    delegation_id character varying(255),
    sensitivity_ceiling character varying(30) DEFAULT 'PL1_public'::character varying NOT NULL,
    binding_key character varying(200) NOT NULL,
    grant_metadata_json jsonb NOT NULL,
    created_by_user_id uuid,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    revoked_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_knowledge_grant_agent_binding CHECK ((((grantee_type)::text <> 'agent'::text) OR (revoked_at IS NOT NULL) OR ((requester_user_id IS NOT NULL) AND (expires_at IS NOT NULL) AND ((((purpose)::text = 'autonomous_agent'::text) AND (requester_user_id = scope_id) AND (session_id IS NULL) AND (delegation_id IS NULL)) OR (((purpose)::text = 'interactive_session'::text) AND (session_id IS NOT NULL) AND (delegation_id IS NULL)) OR (((purpose)::text = ANY ((ARRAY['a2a_delegation'::character varying, 'subagent_delegation'::character varying])::text[])) AND (session_id IS NOT NULL) AND (delegation_id IS NOT NULL)))))),
    CONSTRAINT ck_knowledge_grant_resource_binding CHECK (((revoked_at IS NOT NULL) OR ((((resource_type)::text = 'scope'::text) AND (resource_id = scope_id) AND (document_id IS NULL)) OR (((resource_type)::text = 'document'::text) AND (document_id IS NOT NULL) AND (resource_id = document_id))))),
    CONSTRAINT ck_knowledge_grant_revoke_actor CHECK (((revoked_by_user_id IS NULL) OR (revoked_at IS NOT NULL))),
    CONSTRAINT ck_knowledge_grant_sensitivity_ceiling CHECK (((sensitivity_ceiling)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[])))
);

ALTER TABLE ONLY public.knowledge_grants FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_index_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_index_jobs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    document_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    artifact_hash character varying(128) NOT NULL,
    stage character varying(50) NOT NULL,
    status character varying(40) NOT NULL,
    error_message text,
    attempt_count integer NOT NULL,
    job_metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.knowledge_index_jobs FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_links (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    from_kind character varying(40) NOT NULL,
    from_id uuid NOT NULL,
    to_kind character varying(40) NOT NULL,
    to_id uuid NOT NULL,
    relation character varying(80) NOT NULL,
    confidence double precision NOT NULL,
    source_refs_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.knowledge_links FORCE ROW LEVEL SECURITY;


--
-- Name: knowledge_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_segments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    document_id uuid NOT NULL,
    scope_type character varying(30) NOT NULL,
    scope_id uuid NOT NULL,
    "position" integer NOT NULL,
    segment_hash character varying(64) NOT NULL,
    heading_path_json jsonb NOT NULL,
    content text NOT NULL,
    token_count integer NOT NULL,
    tsv tsvector,
    segment_metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.knowledge_segments FORCE ROW LEVEL SECURITY;


--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_models (
    id uuid NOT NULL,
    tenant_id uuid,
    provider character varying(50) NOT NULL,
    model character varying(100) NOT NULL,
    api_key_encrypted character varying(500) NOT NULL,
    base_url character varying(500),
    label character varying(200) NOT NULL,
    max_tokens_per_day integer,
    enabled boolean NOT NULL,
    supports_vision boolean NOT NULL,
    max_output_tokens integer,
    max_input_tokens integer,
    temperature double precision,
    reasoning_mode character varying(32),
    reasoning_effort character varying(32),
    reasoning_budget_tokens integer,
    reasoning_display character varying(32),
    preserve_reasoning boolean,
    text_verbosity character varying(32),
    provider_options jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.llm_models FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_bridge_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_bridge_connections (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid NOT NULL,
    device_name character varying(255) NOT NULL,
    client_kind character varying(64) NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    token_hash character varying(128) NOT NULL,
    scopes jsonb NOT NULL,
    status character varying(32) NOT NULL,
    last_seen_at timestamp with time zone,
    last_seen_ip character varying(64),
    last_seen_user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    expires_at timestamp with time zone,
    metadata_json jsonb NOT NULL
);

ALTER TABLE ONLY public.local_agent_bridge_connections FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_bridge_pairing_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_bridge_pairing_sessions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    connection_id uuid,
    pairing_code_hash character varying(128) NOT NULL,
    device_code_hash character varying(128) NOT NULL,
    device_name character varying(255) NOT NULL,
    client_kind character varying(64) NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    scopes jsonb NOT NULL,
    status character varying(32) NOT NULL,
    metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_at timestamp with time zone,
    claimed_at timestamp with time zone,
    rejected_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_capability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_capability_snapshots (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    subject_agent_id uuid NOT NULL,
    issuer character varying(120) NOT NULL,
    version integer NOT NULL,
    reported_capabilities_json jsonb NOT NULL,
    server_capabilities_json jsonb NOT NULL,
    agent_capabilities_json jsonb NOT NULL,
    effective_capabilities_json jsonb NOT NULL,
    snapshot_hash character varying(64) NOT NULL,
    signature character varying(64) NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.local_agent_capability_snapshots FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_channel_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_channel_events (
    id uuid NOT NULL,
    sequence bigint NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    source_agent_id uuid,
    session_id uuid NOT NULL,
    message_id uuid,
    direction character varying(32) NOT NULL,
    event_type character varying(64) NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.local_agent_channel_events FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_channel_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_channel_messages (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    source_agent_id uuid,
    session_id uuid NOT NULL,
    sender_user_id uuid,
    sender_agent_id uuid,
    direction character varying(32) NOT NULL,
    content text NOT NULL,
    attachments_json jsonb NOT NULL,
    metadata_json jsonb NOT NULL,
    idempotency_key character varying(200) NOT NULL,
    request_hash character varying(64),
    capability_snapshot_hash character varying(64),
    replay_key character varying(200) NOT NULL,
    receipt_trace_id character varying(255),
    receipt_span_id character varying(80),
    approval_id uuid,
    status character varying(32) NOT NULL,
    result text,
    delivery_attempt_count integer NOT NULL,
    delivery_lease_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    completed_at timestamp with time zone
);

ALTER TABLE ONLY public.local_agent_channel_messages FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_channel_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_channel_sessions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    source_agent_id uuid,
    channel_id uuid,
    connection_id uuid,
    chat_session_id uuid,
    local_session_id character varying(128),
    source character varying(32) NOT NULL,
    status character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.local_agent_channel_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_channel_ws_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_channel_ws_tickets (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    ticket_hash character varying(128) NOT NULL,
    scopes jsonb NOT NULL,
    metadata_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);

ALTER TABLE ONLY public.local_agent_channel_ws_tickets FORCE ROW LEVEL SECURITY;


--
-- Name: local_agent_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_agent_channels (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    connection_id uuid NOT NULL,
    runtime_kind character varying(64) NOT NULL,
    status character varying(32) NOT NULL,
    capabilities_json jsonb NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.local_agent_channels FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_server_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_server_tools (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    mcp_server_id uuid NOT NULL,
    tool_id uuid,
    mcp_tool_name character varying(200) NOT NULL,
    display_name character varying(200) NOT NULL,
    schema_hash character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_server_tools FORCE ROW LEVEL SECURITY;


--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_servers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    server_key character varying(200) NOT NULL,
    transport character varying(40),
    server_url character varying(500),
    registry_source character varying(40) NOT NULL,
    status character varying(30) NOT NULL,
    auth_status character varying(30) NOT NULL,
    config_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.mcp_servers FORCE ROW LEVEL SECURITY;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    body text NOT NULL,
    link character varying(500),
    ref_id uuid,
    is_read boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;


--
-- Name: org_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_departments (
    id uuid NOT NULL,
    feishu_id character varying(100),
    name character varying(200) NOT NULL,
    parent_id uuid,
    path character varying(500) NOT NULL,
    member_count integer NOT NULL,
    tenant_id uuid NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.org_departments FORCE ROW LEVEL SECURITY;


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_members (
    id uuid NOT NULL,
    provider_id uuid,
    external_id character varying(100),
    open_id character varying(100),
    unionid character varying(100),
    feishu_open_id character varying(100),
    feishu_user_id character varying(100),
    name character varying(100) NOT NULL,
    email character varying(200),
    avatar_url character varying(500),
    title character varying(200) NOT NULL,
    department_id uuid,
    department_path character varying(500) NOT NULL,
    phone character varying(50),
    status character varying(20) NOT NULL,
    tenant_id uuid NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.org_members FORCE ROW LEVEL SECURITY;


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    id uuid NOT NULL,
    type character varying(10) NOT NULL,
    ref_id uuid NOT NULL,
    display_name character varying(100) NOT NULL,
    avatar_url character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.participants FORCE ROW LEVEL SECURITY;


--
-- Name: pending_reply_contexts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_reply_contexts (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    recipient_channel character varying(30) NOT NULL,
    recipient_identity character varying(200) NOT NULL,
    outbound_message text NOT NULL,
    task_summary text NOT NULL,
    originator_name character varying(100),
    originator_identity character varying(200),
    expected_action text,
    full_context_json jsonb,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    fulfilled_at timestamp with time zone
);

ALTER TABLE ONLY public.pending_reply_contexts FORCE ROW LEVEL SECURITY;


--
-- Name: personal_knowledge_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_knowledge_proposals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    owner_user_id uuid NOT NULL,
    proposed_by_agent_id uuid NOT NULL,
    delegated_by_agent_id uuid,
    delegation_id character varying(128),
    title character varying(300) NOT NULL,
    proposed_content text NOT NULL,
    content_hash character varying(64) NOT NULL,
    baseline_document_id uuid,
    baseline_revision_id uuid,
    baseline_content_hash character varying(64),
    diff_unified text NOT NULL,
    target_collection character varying(120) NOT NULL,
    source_refs_json jsonb NOT NULL,
    sensitivity character varying(30) NOT NULL,
    purpose text NOT NULL,
    dedupe_key character varying(128) NOT NULL,
    idempotency_key character varying(200) NOT NULL,
    policy_outcome character varying(20) NOT NULL,
    policy_reason_codes_json jsonb NOT NULL,
    status character varying(20) NOT NULL,
    reviewed_by_user_id uuid,
    reviewed_at timestamp with time zone,
    review_reason text,
    document_id uuid,
    revision_id uuid,
    rollback_ref text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_personal_kb_proposal_policy_outcome CHECK (((policy_outcome)::text = ANY ((ARRAY['approve'::character varying, 'ask'::character varying, 'reject'::character varying])::text[]))),
    CONSTRAINT ck_personal_kb_proposal_sensitivity CHECK (((sensitivity)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[]))),
    CONSTRAINT ck_personal_kb_proposal_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'committed'::character varying, 'failed'::character varying])::text[])))
);

ALTER TABLE ONLY public.personal_knowledge_proposals FORCE ROW LEVEL SECURITY;


--
-- Name: plaza_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plaza_comments (
    id uuid NOT NULL,
    post_id uuid NOT NULL,
    author_id uuid NOT NULL,
    author_type character varying(10) NOT NULL,
    author_name character varying(100) NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.plaza_comments FORCE ROW LEVEL SECURITY;


--
-- Name: plaza_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plaza_likes (
    id uuid NOT NULL,
    post_id uuid NOT NULL,
    author_id uuid NOT NULL,
    author_type character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.plaza_likes FORCE ROW LEVEL SECURITY;


--
-- Name: plaza_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plaza_posts (
    id uuid NOT NULL,
    author_id uuid NOT NULL,
    author_type character varying(10) NOT NULL,
    author_name character varying(100) NOT NULL,
    content text NOT NULL,
    tenant_id uuid NOT NULL,
    likes_count integer NOT NULL,
    comments_count integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.plaza_posts FORCE ROW LEVEL SECURITY;


--
-- Name: plugin_dependency_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_dependency_edges (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    installed_plugin_id uuid NOT NULL,
    dependency_plugin_id uuid NOT NULL,
    dependency_key character varying(200) NOT NULL,
    dependency_version character varying(40) NOT NULL,
    source_kind character varying(40) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.plugin_dependency_edges FORCE ROW LEVEL SECURITY;


--
-- Name: plugin_hook_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_hook_registrations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    installed_plugin_id uuid NOT NULL,
    event character varying(60) NOT NULL,
    handler character varying(120) NOT NULL,
    matcher_json jsonb NOT NULL,
    mode character varying(20) NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.plugin_hook_registrations FORCE ROW LEVEL SECURITY;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(128) NOT NULL,
    device_id character varying(200) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.refresh_tokens FORCE ROW LEVEL SECURITY;


--
-- Name: resource_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_permissions (
    id uuid NOT NULL,
    principal_type character varying(20) NOT NULL,
    principal_id uuid,
    principal_key character varying(300),
    resource_type character varying(80) NOT NULL,
    resource_id uuid,
    resource_key character varying(500),
    actions text[] NOT NULL,
    conditions jsonb NOT NULL,
    effect character varying(10) DEFAULT 'allow'::character varying NOT NULL,
    sensitivity_ceiling character varying(30) DEFAULT 'PL1_public'::character varying NOT NULL,
    purposes text[] DEFAULT '{}'::text[] NOT NULL,
    source_acl_snapshot_hash character varying(64),
    tenant_id uuid NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_by_user_id uuid,
    revoked_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_resource_permissions_effect CHECK (((effect)::text = ANY ((ARRAY['allow'::character varying, 'deny'::character varying])::text[]))),
    CONSTRAINT ck_resource_permissions_principal_ref CHECK (((principal_id IS NOT NULL) OR (principal_key IS NOT NULL))),
    CONSTRAINT ck_resource_permissions_resource_ref CHECK (((resource_id IS NOT NULL) OR (resource_key IS NOT NULL))),
    CONSTRAINT ck_resource_permissions_revoke_actor CHECK (((revoked_by_user_id IS NULL) OR (revoked_at IS NOT NULL))),
    CONSTRAINT ck_resource_permissions_sensitivity_ceiling CHECK (((sensitivity_ceiling)::text = ANY ((ARRAY['PL1_public'::character varying, 'PL2_pii'::character varying, 'PL3_sensitive'::character varying, 'PL4_credential'::character varying])::text[])))
);

ALTER TABLE ONLY public.resource_permissions FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_budget_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_budget_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    budget_run_id uuid NOT NULL,
    event_type character varying(40) NOT NULL,
    reservation_key character varying(200),
    allowed boolean,
    would_deny boolean DEFAULT false NOT NULL,
    reason text,
    amounts_json jsonb,
    metadata_json jsonb,
    runtime_task_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.runtime_budget_events FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_budget_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_budget_policies (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    scope_type character varying(40) NOT NULL,
    source character varying(80),
    profile character varying(80),
    agent_id uuid,
    trigger_id uuid,
    enforcement_mode character varying(20) DEFAULT 'enforce'::character varying NOT NULL,
    fail_mode character varying(20) DEFAULT 'fail_closed'::character varying NOT NULL,
    max_tokens bigint,
    max_cache_miss_tokens bigint,
    max_subagents integer,
    max_team_sessions integer,
    max_delegations integer,
    max_background_tasks integer,
    max_continuation_wakes integer,
    max_provider_calls integer,
    max_failures integer,
    max_needs_reconciliation integer,
    max_child_failure_ratio double precision,
    max_parent_invocations integer,
    default_child_token_reservation bigint DEFAULT '50000'::bigint NOT NULL,
    default_llm_call_token_reservation bigint DEFAULT '50000'::bigint NOT NULL,
    policy_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.runtime_budget_policies FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_budget_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_budget_runs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    policy_id uuid,
    root_run_kind character varying(60) NOT NULL,
    root_run_key character varying(300) NOT NULL,
    root_runtime_task_id uuid,
    root_session_id character varying(512),
    root_agent_id uuid,
    root_user_id uuid,
    root_external_principal_id uuid,
    source character varying(80),
    profile character varying(80),
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    enforcement_mode character varying(20) DEFAULT 'enforce'::character varying NOT NULL,
    fail_mode character varying(20) DEFAULT 'fail_closed'::character varying NOT NULL,
    terminal_reason text,
    max_tokens bigint,
    max_cache_miss_tokens bigint,
    max_subagents integer,
    max_team_sessions integer,
    max_delegations integer,
    max_background_tasks integer,
    max_continuation_wakes integer,
    max_provider_calls integer,
    max_failures integer,
    max_needs_reconciliation integer,
    max_child_failure_ratio double precision,
    max_parent_invocations integer,
    reserved_tokens bigint DEFAULT '0'::bigint NOT NULL,
    used_tokens bigint DEFAULT '0'::bigint NOT NULL,
    reserved_cache_miss_tokens bigint DEFAULT '0'::bigint NOT NULL,
    used_cache_miss_tokens bigint DEFAULT '0'::bigint NOT NULL,
    reserved_subagents integer DEFAULT 0 NOT NULL,
    used_subagents integer DEFAULT 0 NOT NULL,
    reserved_team_sessions integer DEFAULT 0 NOT NULL,
    used_team_sessions integer DEFAULT 0 NOT NULL,
    reserved_delegations integer DEFAULT 0 NOT NULL,
    used_delegations integer DEFAULT 0 NOT NULL,
    reserved_background_tasks integer DEFAULT 0 NOT NULL,
    used_background_tasks integer DEFAULT 0 NOT NULL,
    reserved_continuation_wakes integer DEFAULT 0 NOT NULL,
    used_continuation_wakes integer DEFAULT 0 NOT NULL,
    reserved_provider_calls integer DEFAULT 0 NOT NULL,
    used_provider_calls integer DEFAULT 0 NOT NULL,
    parent_invocations integer DEFAULT 0 NOT NULL,
    policy_snapshot jsonb,
    metadata_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    completed_at timestamp with time zone
);

ALTER TABLE ONLY public.runtime_budget_runs FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_notification_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_notification_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_kind character varying(32) NOT NULL,
    source_run_id character varying(200) NOT NULL,
    parent_session_id uuid NOT NULL,
    parent_agent_id uuid NOT NULL,
    parent_user_id uuid NOT NULL,
    child_session_id uuid,
    child_agent_name character varying(200),
    terminal_status character varying(40) NOT NULL,
    task_type character varying(64) NOT NULL,
    root_runtime_task_id uuid,
    result_object_id uuid NOT NULL,
    result_ref character varying(180) NOT NULL,
    result_sha256 character varying(64) NOT NULL,
    result_size_bytes bigint NOT NULL,
    artifact_count integer DEFAULT 0 NOT NULL,
    mailbox_sequence bigint NOT NULL,
    delivery_mode character varying(32) DEFAULT 'parent_continuation'::character varying NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    payload_rank integer DEFAULT 100 NOT NULL,
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    locked_by character varying(200),
    locked_at timestamp with time zone,
    claim_token uuid,
    lease_expires_at timestamp with time zone,
    integration_page_id uuid,
    last_error text,
    delivery_receipt_json jsonb,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_runtime_notification_outbox_delivery_mode CHECK (((delivery_mode)::text = ANY ((ARRAY['parent_continuation'::character varying, 'session_projection'::character varying])::text[]))),
    CONSTRAINT ck_runtime_notification_outbox_source_kind CHECK (((source_kind)::text = ANY ((ARRAY['subagent'::character varying, 'agent_team'::character varying, 'workflow'::character varying, 'trigger'::character varying, 'delegation'::character varying, 'a2a_delegation'::character varying, 'a2a_continuation'::character varying, 'runtime_budget'::character varying, 'approval'::character varying])::text[]))),
    CONSTRAINT ck_runtime_notification_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'delivered'::character varying, 'dead_letter'::character varying])::text[])))
);

ALTER TABLE ONLY public.runtime_notification_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_result_integration_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_result_integration_pages (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    parent_session_id uuid NOT NULL,
    parent_agent_id uuid NOT NULL,
    parent_user_id uuid NOT NULL,
    root_runtime_task_id uuid,
    root_scope_key character varying(260) NOT NULL,
    integration_epoch bigint NOT NULL,
    delivery_mode character varying(32) NOT NULL,
    mailbox_sequence_start bigint NOT NULL,
    mailbox_sequence_end bigint NOT NULL,
    item_count integer NOT NULL,
    manifest_json jsonb NOT NULL,
    manifest_sha256 character varying(64) NOT NULL,
    coverage_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) DEFAULT 'prepared'::character varying NOT NULL,
    claim_token uuid,
    claimed_by character varying(200),
    lease_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_error text,
    delivery_receipt_json jsonb,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_runtime_result_integration_pages_delivery_mode CHECK (((delivery_mode)::text = ANY ((ARRAY['parent_continuation'::character varying, 'session_projection'::character varying])::text[]))),
    CONSTRAINT ck_runtime_result_integration_pages_item_count CHECK ((item_count >= 1)),
    CONSTRAINT ck_runtime_result_integration_pages_sequence_range CHECK ((mailbox_sequence_end >= mailbox_sequence_start)),
    CONSTRAINT ck_runtime_result_integration_pages_status CHECK (((status)::text = ANY ((ARRAY['prepared'::character varying, 'processing'::character varying, 'delivered'::character varying, 'dead_letter'::character varying])::text[])))
);

ALTER TABLE ONLY public.runtime_result_integration_pages FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_result_mailbox_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_result_mailbox_cursors (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    parent_session_id uuid NOT NULL,
    next_mailbox_sequence bigint DEFAULT 1 NOT NULL,
    next_integration_epoch bigint DEFAULT 1 NOT NULL,
    last_prepared_sequence bigint DEFAULT 0 NOT NULL,
    last_delivered_sequence bigint DEFAULT 0 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_runtime_result_mailbox_next_epoch CHECK ((next_integration_epoch >= 1)),
    CONSTRAINT ck_runtime_result_mailbox_next_sequence CHECK ((next_mailbox_sequence >= 1))
);

ALTER TABLE ONLY public.runtime_result_mailbox_cursors FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_result_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_result_objects (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_kind character varying(32) NOT NULL,
    source_run_id character varying(200) NOT NULL,
    payload_schema character varying(80) DEFAULT 'hive.runtime_result.v1'::character varying NOT NULL,
    payload_bytes bytea NOT NULL,
    sha256 character varying(64) NOT NULL,
    size_bytes bigint NOT NULL,
    media_type character varying(120) DEFAULT 'application/json'::character varying NOT NULL,
    encoding character varying(32) DEFAULT 'utf-8'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_runtime_result_objects_size_nonnegative CHECK ((size_bytes >= 0))
);

ALTER TABLE ONLY public.runtime_result_objects FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_root_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_root_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    root_runtime_task_id uuid NOT NULL,
    parent_runtime_task_id uuid,
    runtime_task_id uuid,
    source_agent_id uuid,
    root_user_id uuid,
    root_session_id character varying(512),
    intent_key character varying(300) NOT NULL,
    work_type character varying(64) NOT NULL,
    target_ref character varying(512) NOT NULL,
    path_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    state character varying(40) NOT NULL,
    admission_disposition character varying(24) NOT NULL,
    reason_code character varying(160),
    budget_reservation_key character varying(300),
    approval_ref character varying(512),
    child_session_id character varying(512),
    result_refs_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    recovery_claimed_by character varying(200),
    recovery_claim_expires_at timestamp with time zone,
    recovery_attempt_count integer DEFAULT 0 NOT NULL,
    next_recovery_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    terminal_at timestamp with time zone,
    CONSTRAINT ck_runtime_root_items_admission_disposition CHECK (((admission_disposition)::text = ANY ((ARRAY['requested'::character varying, 'admitted'::character varying, 'deferred'::character varying, 'not_admitted'::character varying])::text[]))),
    CONSTRAINT ck_runtime_root_items_state CHECK (((state)::text = ANY ((ARRAY['requested'::character varying, 'waiting_approval'::character varying, 'queued'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'killed'::character varying, 'skipped'::character varying, 'cancelled'::character varying, 'suspended'::character varying, 'needs_reconciliation'::character varying, 'not_admitted'::character varying])::text[])))
);

ALTER TABLE ONLY public.runtime_root_items FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_tasks (
    id uuid NOT NULL,
    task_type character varying(50) NOT NULL,
    parent_agent_id uuid,
    child_agent_id uuid,
    child_agent_name character varying(200),
    tenant_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    writer_generation integer DEFAULT 1 NOT NULL,
    prompt text,
    result_summary text,
    token_usage json,
    trace_id character varying(512),
    parent_session_id character varying(512),
    child_session_id character varying(512),
    root_user_id uuid,
    root_session_id character varying(512),
    delegation_chain_json json DEFAULT '[]'::json NOT NULL,
    depth integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    scheduled_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    completion_outbox_generation smallint DEFAULT 1,
    completion_outbox_settled_at timestamp with time zone,
    completion_outbox_attempted_at timestamp with time zone,
    completion_outbox_attempt_count integer DEFAULT 0 NOT NULL,
    completion_outbox_last_error character varying(100),
    terminal_boundary_generation smallint,
    terminal_boundary_enqueued_at timestamp with time zone,
    terminal_boundary_reconcile_attempted_at timestamp with time zone,
    terminal_boundary_reconcile_attempt_count integer DEFAULT 0 NOT NULL,
    terminal_boundary_reconcile_last_error character varying(100),
    priority integer DEFAULT 0 NOT NULL,
    claimed_by character varying(200),
    claim_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    claim_version integer DEFAULT 0 NOT NULL,
    root_idempotency_key character varying(200) NOT NULL,
    config_snapshot_hash character varying(64) NOT NULL,
    policy_snapshot_hash character varying(64) NOT NULL,
    budget_run_id uuid,
    root_runtime_task_id uuid,
    budget_reservation_key character varying(200),
    budget_admission_status character varying(40),
    budget_snapshot_json json,
    budget_terminal_reason text,
    metadata_json json,
    CONSTRAINT ck_runtime_tasks_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'killed'::character varying, 'skipped'::character varying, 'needs_reconciliation'::character varying, 'resumable'::character varying, 'suspended'::character varying])::text[]))),
    CONSTRAINT ck_runtime_tasks_task_type CHECK (((task_type)::text = ANY ((ARRAY['web_chat_turn'::character varying, 'goal_continuation'::character varying, 'team_member'::character varying, 'advanced_plan'::character varying, 'workflow'::character varying, 'delegation'::character varying, 'business_task'::character varying, 'subagent'::character varying, 'trigger'::character varying, 'heartbeat'::character varying, 'coordinator_worker'::character varying, 'harness_canary'::character varying, 'a2a_delegation'::character varying, 'approval_execution'::character varying, 'hr_provisioning'::character varying, 'dream'::character varying, 'a2a_continuation'::character varying])::text[])))
);

ALTER TABLE ONLY public.runtime_tasks FORCE ROW LEVEL SECURITY;


--
-- Name: runtime_terminal_boundary_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.runtime_terminal_boundary_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    runtime_task_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id character varying(200) NOT NULL,
    event_kind character varying(80) NOT NULL,
    terminal_status character varying(40) NOT NULL,
    authority_ref character varying(100) NOT NULL,
    authority_id character varying(200) NOT NULL,
    binding_json jsonb NOT NULL,
    binding_sha256 character varying(64) NOT NULL,
    idempotency_key character varying(64) NOT NULL,
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_by character varying(200),
    claim_token uuid,
    lease_expires_at timestamp with time zone,
    last_error text,
    delivery_receipt_json jsonb,
    delivered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_runtime_terminal_boundary_outbox_attempt_count CHECK ((attempt_count >= 0)),
    CONSTRAINT ck_runtime_terminal_boundary_outbox_binding_sha CHECK ((char_length((binding_sha256)::text) = 64)),
    CONSTRAINT ck_runtime_terminal_boundary_outbox_idempotency_sha CHECK ((char_length((idempotency_key)::text) = 64)),
    CONSTRAINT ck_runtime_terminal_boundary_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'delivered'::character varying, 'dead_letter'::character varying])::text[])))
);

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: security_audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_audit_events (
    id uuid NOT NULL,
    sequence_num bigint,
    event_type character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    actor_type character varying(20) NOT NULL,
    actor_id uuid,
    tenant_id uuid NOT NULL,
    resource_type character varying(30),
    resource_id uuid,
    action character varying(100) NOT NULL,
    details jsonb NOT NULL,
    ip_address inet,
    user_agent text,
    request_id uuid,
    prev_hash character varying(64) NOT NULL,
    event_hash character varying(64) NOT NULL,
    execution_identity_type character varying(20),
    execution_identity_id uuid,
    execution_identity_label character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.security_audit_events FORCE ROW LEVEL SECURITY;


--
-- Name: session_carry_forwards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_carry_forwards (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    purpose character varying(64) NOT NULL,
    source_admission_id uuid NOT NULL,
    source_input_id uuid NOT NULL,
    source_hook_run_id uuid NOT NULL,
    source_evidence_refs_json jsonb NOT NULL,
    context_source_item_id uuid NOT NULL,
    state character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    target_turn_id character varying(200),
    target_round_id character varying(200),
    claim_generation integer DEFAULT 0 NOT NULL,
    claim_owner character varying(200),
    claim_lease_expires_at timestamp with time zone,
    model_request_snapshot_ref character varying(300),
    consumed_event_id uuid,
    recovery_owner character varying(200),
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_carry_forward_consumed CHECK ((((state)::text <> 'consumed'::text) OR ((target_turn_id IS NOT NULL) AND (target_round_id IS NOT NULL) AND (model_request_snapshot_ref IS NOT NULL) AND (consumed_event_id IS NOT NULL)))),
    CONSTRAINT ck_session_carry_forward_state CHECK (((state)::text = ANY ((ARRAY['pending'::character varying, 'turn_claimed'::character varying, 'round_bound'::character varying, 'consumed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_carry_forwards FORCE ROW LEVEL SECURITY;


--
-- Name: session_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_commands (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    principal_type character varying(32) DEFAULT 'user'::character varying NOT NULL,
    principal_id uuid NOT NULL,
    session_id uuid NOT NULL,
    namespace character varying(40) NOT NULL,
    causation_command_id uuid,
    idempotency_key character varying(200) NOT NULL,
    command_kind character varying(80) NOT NULL,
    request_hash character varying(64) NOT NULL,
    target_hash character varying(64) NOT NULL,
    request_json jsonb NOT NULL,
    target_json jsonb NOT NULL,
    status character varying(32) DEFAULT 'accepted'::character varying NOT NULL,
    receipt_ref character varying(300) NOT NULL,
    rejection_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_commands_namespace CHECK (((namespace)::text = ANY ((ARRAY['human_input'::character varying, 'control_input'::character varying, 'evaluation_feedback'::character varying, 'turn_replacement'::character varying])::text[]))),
    CONSTRAINT ck_session_commands_principal_type CHECK (((principal_type)::text = ANY ((ARRAY['user'::character varying, 'external_principal'::character varying])::text[]))),
    CONSTRAINT ck_session_commands_status CHECK (((status)::text = ANY ((ARRAY['accepted'::character varying, 'applied'::character varying, 'rejected'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_commands FORCE ROW LEVEL SECURITY;


--
-- Name: session_control_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_control_inputs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    command_id uuid NOT NULL,
    kind character varying(48) NOT NULL,
    expected_run_id uuid NOT NULL,
    request_item_id uuid,
    request_version integer,
    authority_snapshot_hash character varying(64) NOT NULL,
    response_schema character varying(300),
    response_payload_json jsonb NOT NULL,
    response_payload_hash character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'accepted'::character varying NOT NULL,
    settlement_ref character varying(300),
    recovery_owner character varying(200),
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_control_inputs_kind CHECK (((kind)::text = ANY ((ARRAY['cancel_run'::character varying, 'approval_response'::character varying, 'permission_response'::character varying, 'workflow_gate_response'::character varying])::text[]))),
    CONSTRAINT ck_session_control_inputs_status CHECK (((status)::text = ANY ((ARRAY['accepted'::character varying, 'applying'::character varying, 'applied'::character varying, 'rejected'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_control_inputs FORCE ROW LEVEL SECURITY;


--
-- Name: session_event_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_event_cursors (
    session_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    next_sequence bigint DEFAULT 1 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_event_cursor_positive CHECK ((next_sequence > 0))
);

ALTER TABLE ONLY public.session_event_cursors FORCE ROW LEVEL SECURITY;


--
-- Name: session_event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_event_outbox (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    event_id uuid NOT NULL,
    sequence bigint NOT NULL,
    envelope_json jsonb NOT NULL,
    envelope_sha256 character varying(64) NOT NULL,
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_by character varying(200),
    claim_expires_at timestamp with time zone,
    last_error text,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_event_outbox_sha CHECK ((char_length((envelope_sha256)::text) = 64)),
    CONSTRAINT ck_session_event_outbox_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'publishing'::character varying, 'published'::character varying, 'failed'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_event_outbox FORCE ROW LEVEL SECURITY;


--
-- Name: session_feedback_aggregates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_feedback_aggregates (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    target_item_id uuid NOT NULL,
    target_result_id uuid,
    revision integer DEFAULT 1 NOT NULL,
    current_value_json jsonb,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    last_mutation_item_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_feedback_aggregate_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'withdrawn'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_feedback_aggregates FORCE ROW LEVEL SECURITY;


--
-- Name: session_feedback_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_feedback_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    message_id uuid,
    decision_trace_id character varying(128),
    user_id uuid NOT NULL,
    label character varying(20) NOT NULL,
    reason text NOT NULL,
    attribution_json jsonb NOT NULL,
    calibration_result_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.session_feedback_events FORCE ROW LEVEL SECURITY;


--
-- Name: session_input_admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_input_admissions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    command_id uuid NOT NULL,
    input_id uuid NOT NULL,
    input_revision integer NOT NULL,
    state character varying(40) DEFAULT 'admission_pending'::character varying NOT NULL,
    hook_run_id uuid NOT NULL,
    hook_idempotency_key character varying(200) NOT NULL,
    hook_result_hash character varying(64),
    hook_item_id uuid,
    additional_context_refs_json jsonb NOT NULL,
    carry_forward character varying(40) DEFAULT 'none'::character varying NOT NULL,
    dispatch_state character varying(40) DEFAULT 'not_applicable'::character varying NOT NULL,
    dispatch_receipt_json jsonb NOT NULL,
    dispatch_attempts integer DEFAULT 0 NOT NULL,
    dispatch_last_error text,
    lease_owner character varying(200),
    lease_expires_at timestamp with time zone,
    recovery_owner character varying(200),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_input_admissions_dispatch_state CHECK (((dispatch_state)::text = ANY ((ARRAY['not_applicable'::character varying, 'pending'::character varying, 'dispatching'::character varying, 'dispatched'::character varying, 'needs_reconciliation'::character varying])::text[]))),
    CONSTRAINT ck_session_input_admissions_state CHECK (((state)::text = ANY ((ARRAY['admission_pending'::character varying, 'hook_running'::character varying, 'hook_result_committed'::character varying, 'admitted'::character varying, 'rejected'::character varying, 'cancelled'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_input_admissions FORCE ROW LEVEL SECURITY;


--
-- Name: session_model_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_model_results (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    turn_id character varying(200) NOT NULL,
    run_id uuid NOT NULL,
    round_id character varying(200) NOT NULL,
    provider_request_id character varying(300) NOT NULL,
    state character varying(32) DEFAULT 'prepared'::character varying NOT NULL,
    model_request_hash character varying(64) NOT NULL,
    model_request_snapshot_json jsonb NOT NULL,
    bound_input_ids_json jsonb NOT NULL,
    last_content_sequence bigint,
    seal_json jsonb,
    round_committed_event_id uuid,
    reconciliation_owner character varying(200),
    reconciliation_lease_expires_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_model_results_state CHECK (((state)::text = ANY ((ARRAY['prepared'::character varying, 'streaming'::character varying, 'sealed'::character varying, 'round_committed'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_model_results FORCE ROW LEVEL SECURITY;


--
-- Name: session_next_round_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_next_round_plans (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    run_id uuid NOT NULL,
    source_result_id uuid NOT NULL,
    next_round_id character varying(200) NOT NULL,
    plan_generation integer DEFAULT 1 NOT NULL,
    obligation_ids_json jsonb NOT NULL,
    ordered_sources_json jsonb NOT NULL,
    fences_json jsonb NOT NULL,
    plan_hash character varying(64) NOT NULL,
    state character varying(32) DEFAULT 'prepared'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_next_round_plan_state CHECK (((state)::text = ANY ((ARRAY['prepared'::character varying, 'committed'::character varying, 'dispatched'::character varying, 'abandoned'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_next_round_plans FORCE ROW LEVEL SECURITY;


--
-- Name: session_round_obligations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_round_obligations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    turn_id character varying(200) NOT NULL,
    run_id uuid NOT NULL,
    source_result_id uuid NOT NULL,
    kind character varying(32) NOT NULL,
    source_generation integer NOT NULL,
    source_ref character varying(300) NOT NULL,
    payload_json jsonb NOT NULL,
    state character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    claim_owner character varying(200),
    claim_lease_expires_at timestamp with time zone,
    settlement_ref character varying(300),
    recovery_owner character varying(200),
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_round_obligation_kind CHECK (((kind)::text = ANY ((ARRAY['tool_followup'::character varying, 'pending_input'::character varying, 'hook_retry'::character varying, 'compact_continue'::character varying])::text[]))),
    CONSTRAINT ck_session_round_obligation_state CHECK (((state)::text = ANY ((ARRAY['pending'::character varying, 'claimed'::character varying, 'settled'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_round_obligations FORCE ROW LEVEL SECURITY;


--
-- Name: session_run_outcomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_run_outcomes (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    turn_id character varying(200) NOT NULL,
    run_id uuid NOT NULL,
    terminal_result_id uuid NOT NULL,
    state character varying(32) DEFAULT 'prepared'::character varying NOT NULL,
    eligibility_snapshot_hash character varying(64) NOT NULL,
    seal_json jsonb,
    terminal_event_id uuid,
    reconciliation_owner character varying(200),
    reconciliation_lease_expires_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_run_outcomes_state CHECK (((state)::text = ANY ((ARRAY['prepared'::character varying, 'sealed'::character varying, 'terminal_committed'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_run_outcomes FORCE ROW LEVEL SECURITY;


--
-- Name: session_tool_invocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_tool_invocations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    run_id uuid NOT NULL,
    round_id character varying(200) NOT NULL,
    provider_request_id character varying(300) NOT NULL,
    provider_tool_use_id character varying(300) NOT NULL,
    tool_name character varying(200) DEFAULT ''::character varying NOT NULL,
    provider_arguments_json jsonb NOT NULL,
    invocation_item_id uuid NOT NULL,
    args_hash character varying(64) NOT NULL,
    effective_arguments_json jsonb,
    effective_args_hash character varying(64),
    authority_snapshot_hash character varying(64) NOT NULL,
    effect_idempotency_key character varying(300) NOT NULL,
    effect_state character varying(32) DEFAULT 'prepared_not_started'::character varying NOT NULL,
    execution_fence_ref character varying(300),
    receipt_ref character varying(300),
    result_event_id uuid,
    recovery_owner character varying(200),
    permission_item_id uuid,
    permission_state character varying(32) DEFAULT 'not_required'::character varying NOT NULL,
    permission_request_version integer DEFAULT 0 NOT NULL,
    permission_authority_snapshot_hash character varying(64),
    permission_response_schema character varying(300),
    permission_expires_at timestamp with time zone,
    permission_receipt_ref character varying(300),
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_session_tool_effect_state CHECK (((effect_state)::text = ANY ((ARRAY['prepared_not_started'::character varying, 'effect_started'::character varying, 'effect_committed'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[]))),
    CONSTRAINT ck_session_tool_permission_state CHECK (((permission_state)::text = ANY ((ARRAY['not_required'::character varying, 'waiting'::character varying, 'approved'::character varying, 'denied'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_tool_invocations FORCE ROW LEVEL SECURITY;


--
-- Name: session_turn_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_turn_inputs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    command_id uuid NOT NULL,
    intent character varying(48) NOT NULL,
    content_parts_json jsonb NOT NULL,
    content_hash character varying(64) NOT NULL,
    target_turn_id character varying(200),
    target_run_id uuid,
    request_item_id uuid,
    fork_after_sequence bigint,
    terminal_fallback character varying(32),
    queue_priority character varying(16) NOT NULL,
    queue_ordinal bigint NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    status character varying(32) DEFAULT 'accepted'::character varying NOT NULL,
    bound_round_id character varying(200),
    model_request_snapshot_ref character varying(300),
    rolled_over_to_turn_id character varying(200),
    settlement_ref character varying(300),
    recovery_owner character varying(200),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_turn_inputs_intent CHECK (((intent)::text = ANY ((ARRAY['start_turn'::character varying, 'steer_current_turn'::character varying, 'queue_next_turn'::character varying, 'interrupt_and_replace'::character varying, 'answer_request'::character varying, 'fork_side_thread'::character varying])::text[]))),
    CONSTRAINT ck_session_turn_inputs_priority CHECK (((queue_priority)::text = ANY ((ARRAY['now'::character varying, 'next'::character varying, 'later'::character varying])::text[]))),
    CONSTRAINT ck_session_turn_inputs_status CHECK (((status)::text = ANY ((ARRAY['accepted'::character varying, 'queued'::character varying, 'bound'::character varying, 'applied'::character varying, 'rolled_over'::character varying, 'rejected'::character varying, 'cancelled'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_turn_inputs FORCE ROW LEVEL SECURITY;


--
-- Name: session_turn_replacements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_turn_replacements (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    command_id uuid NOT NULL,
    old_turn_id character varying(200) NOT NULL,
    old_run_id uuid NOT NULL,
    cancel_control_id uuid,
    cancel_command_id uuid,
    replacement_turn_id character varying(200) NOT NULL,
    replacement_input_id uuid NOT NULL,
    state character varying(40) DEFAULT 'requested'::character varying NOT NULL,
    lease_owner character varying(200),
    lease_expires_at timestamp with time zone,
    generation integer DEFAULT 1 NOT NULL,
    last_event_id uuid,
    CONSTRAINT ck_session_turn_replacements_state CHECK (((state)::text = ANY ((ARRAY['requested'::character varying, 'cancel_accepted'::character varying, 'old_run_fenced'::character varying, 'replacement_queued'::character varying, 'replacement_admitted'::character varying, 'completed'::character varying, 'failed'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.session_turn_replacements FORCE ROW LEVEL SECURITY;


--
-- Name: session_writer_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_writer_epochs (
    id character varying(40) NOT NULL,
    state character varying(24) DEFAULT 'legacy_open'::character varying NOT NULL,
    new_run_generation integer DEFAULT 1 NOT NULL,
    allowed_existing_generations_json jsonb NOT NULL,
    enforcement_mode character varying(16) DEFAULT 'observe'::character varying NOT NULL,
    release_id character varying(200),
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_session_writer_epoch_enforcement CHECK (((enforcement_mode)::text = ANY ((ARRAY['observe'::character varying, 'enforce'::character varying])::text[]))),
    CONSTRAINT ck_session_writer_epoch_state CHECK (((state)::text = ANY ((ARRAY['legacy_open'::character varying, 'v1_draining'::character varying, 'v2_only'::character varying])::text[])))
);


--
-- Name: session_writer_heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session_writer_heartbeats (
    id uuid NOT NULL,
    service character varying(40) NOT NULL,
    instance_id character varying(200) NOT NULL,
    artifact_digest character varying(128) NOT NULL,
    supported_generations_json jsonb NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: skill_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_files (
    id uuid NOT NULL,
    skill_id uuid NOT NULL,
    path character varying(500) NOT NULL,
    content text NOT NULL
);

ALTER TABLE ONLY public.skill_files FORCE ROW LEVEL SECURITY;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    category character varying(50) NOT NULL,
    icon character varying(10) NOT NULL,
    folder_name character varying(100) NOT NULL,
    is_builtin boolean NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.skills FORCE ROW LEVEL SECURITY;


--
-- Name: sso_scan_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sso_scan_sessions (
    id uuid NOT NULL,
    status character varying(50) NOT NULL,
    provider_type character varying(50),
    tenant_id uuid NOT NULL,
    user_id uuid,
    access_token text,
    error_msg text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.sso_scan_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: storage_blob_refs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_blob_refs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    blob_id uuid NOT NULL,
    owner_type character varying(60) NOT NULL,
    owner_id character varying(300) NOT NULL,
    purpose character varying(80) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pinned_until timestamp with time zone,
    legal_hold boolean DEFAULT false NOT NULL,
    metadata_json jsonb NOT NULL
);

ALTER TABLE ONLY public.storage_blob_refs FORCE ROW LEVEL SECURITY;


--
-- Name: storage_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_blobs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope_type character varying(20) DEFAULT 'tenant'::character varying NOT NULL,
    kind character varying(60) NOT NULL,
    retention_class character varying(40) NOT NULL,
    state character varying(24) NOT NULL,
    provider character varying(40) NOT NULL,
    bucket character varying(200) NOT NULL,
    object_key text NOT NULL,
    content_sha256 character varying(64) NOT NULL,
    size_bytes bigint NOT NULL,
    media_type character varying(200),
    encryption_key_id character varying(300),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    verified_at timestamp with time zone,
    delete_after timestamp with time zone,
    quarantined_at timestamp with time zone,
    deleted_at timestamp with time zone,
    last_error text,
    metadata_json jsonb NOT NULL,
    CONSTRAINT ck_storage_blobs_scope_type CHECK (((scope_type)::text = ANY ((ARRAY['tenant'::character varying, 'system'::character varying])::text[]))),
    CONSTRAINT ck_storage_blobs_sha256_length CHECK ((char_length((content_sha256)::text) = 64)),
    CONSTRAINT ck_storage_blobs_size_nonnegative CHECK ((size_bytes >= 0)),
    CONSTRAINT ck_storage_blobs_state CHECK (((state)::text = ANY ((ARRAY['uploading'::character varying, 'available'::character varying, 'quarantined'::character varying, 'deleting'::character varying, 'deleted'::character varying, 'failed'::character varying])::text[])))
);

ALTER TABLE ONLY public.storage_blobs FORCE ROW LEVEL SECURITY;


--
-- Name: storage_gc_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_gc_runs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    policy_version character varying(80) NOT NULL,
    mode character varying(24) NOT NULL,
    status character varying(24) NOT NULL,
    manifest_sha256 character varying(64) NOT NULL,
    candidate_count bigint NOT NULL,
    candidate_bytes bigint NOT NULL,
    processed_count bigint NOT NULL,
    processed_bytes bigint NOT NULL,
    failed_count bigint NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    receipt_json jsonb NOT NULL,
    CONSTRAINT ck_storage_gc_runs_mode CHECK (((mode)::text = ANY ((ARRAY['inventory'::character varying, 'backfill'::character varying, 'dry_run'::character varying, 'quarantine'::character varying, 'sweep'::character varying, 'restore'::character varying])::text[]))),
    CONSTRAINT ck_storage_gc_runs_sha256_length CHECK ((char_length((manifest_sha256)::text) = 64)),
    CONSTRAINT ck_storage_gc_runs_status CHECK (((status)::text = ANY ((ARRAY['running'::character varying, 'completed'::character varying, 'partial'::character varying, 'failed'::character varying])::text[])))
);

ALTER TABLE ONLY public.storage_gc_runs FORCE ROW LEVEL SECURITY;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying(100) NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.system_settings FORCE ROW LEVEL SECURITY;


--
-- Name: task_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_logs (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.task_logs FORCE ROW LEVEL SECURITY;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    type public.task_type_enum NOT NULL,
    status character varying(32) NOT NULL,
    priority public.task_priority_enum NOT NULL,
    assignee character varying(50) NOT NULL,
    created_by uuid NOT NULL,
    root_session_id uuid,
    authority_state character varying(24) NOT NULL,
    request_id character varying(128) NOT NULL,
    request_hash character varying(64) NOT NULL,
    active_runtime_task_id uuid,
    execution_attempt integer NOT NULL,
    last_execution_status character varying(32),
    last_error text,
    last_result text,
    due_date timestamp with time zone,
    plan_id uuid,
    plan_version integer,
    plan_hash character varying(80),
    plan_exempt_reason character varying(100),
    plan_authorization jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_tasks_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'doing'::character varying, 'done'::character varying, 'blocked'::character varying, 'failed'::character varying, 'cancelled'::character varying, 'needs_reconciliation'::character varying])::text[])))
);

ALTER TABLE ONLY public.tasks FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_channel_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_channel_configs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    channel_type character varying(30) NOT NULL,
    app_id character varying(255),
    app_secret character varying(1024),
    encrypt_key character varying(1024),
    verification_token character varying(1024),
    extra_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tenant_channel_configs FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_installed_plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_installed_plugins (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    plugin_key character varying(200) NOT NULL,
    version character varying(40) NOT NULL,
    source_kind character varying(40) NOT NULL,
    source_ref character varying(500),
    status character varying(30) NOT NULL,
    config_json jsonb NOT NULL,
    lockfile_json jsonb NOT NULL,
    installed_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tenant_installed_plugins FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_scope_quarantine_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_scope_quarantine_records (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_table character varying(100) NOT NULL,
    source_row_id character varying(100) NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tenant_scope_quarantine_records FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_settings (
    tenant_id uuid NOT NULL,
    key character varying(100) NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tenant_settings FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_tool_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_tool_configs (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    tool_id uuid NOT NULL,
    config jsonb NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tenant_tool_configs FORCE ROW LEVEL SECURITY;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL,
    im_provider public.im_provider_enum NOT NULL,
    im_config json,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    min_heartbeat_interval_minutes integer NOT NULL,
    timezone character varying(50) NOT NULL,
    default_max_triggers integer NOT NULL,
    min_poll_interval_floor integer NOT NULL,
    max_webhook_rate_ceiling integer NOT NULL,
    default_tokens_per_day integer,
    default_tokens_per_month integer,
    quota_tokens_per_day integer,
    quota_tokens_per_month integer,
    tokens_used_today integer NOT NULL,
    tokens_used_month integer NOT NULL,
    tokens_used_total integer NOT NULL,
    tokens_reset_at timestamp with time zone,
    sync_version integer DEFAULT 1 NOT NULL,
    memory_backend character varying(32)
);

ALTER TABLE ONLY public.tenants FORCE ROW LEVEL SECURITY;


--
-- Name: token_usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_usage_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid,
    user_id uuid,
    source character varying(100) NOT NULL,
    provider character varying(50),
    model character varying(200),
    tokens integer NOT NULL,
    usage jsonb,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.token_usage_events FORCE ROW LEVEL SECURITY;


--
-- Name: tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tools (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(200) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    category character varying(50) NOT NULL,
    icon character varying(10) NOT NULL,
    parameters_schema json NOT NULL,
    config json NOT NULL,
    config_schema json NOT NULL,
    mcp_server_url character varying(500),
    mcp_server_name character varying(200),
    mcp_tool_name character varying(200),
    mcp_raw_description text,
    mcp_raw_schema json,
    mcp_metadata_fingerprint character varying(64),
    mcp_metadata_risk_flags json,
    mcp_trust_status character varying(32),
    mcp_trust_tier character varying(40),
    mcp_reviewed_fingerprint character varying(64),
    mcp_reviewed_by uuid,
    mcp_reviewed_at timestamp with time zone,
    enabled boolean NOT NULL,
    is_default boolean NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tools FORCE ROW LEVEL SECURITY;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    avatar_url character varying(500),
    role public.user_role_enum NOT NULL,
    tenant_id uuid,
    department_id uuid,
    title character varying(100),
    feishu_open_id character varying(255),
    feishu_union_id character varying(255),
    feishu_user_id character varying(255),
    oidc_sub character varying(255),
    oidc_issuer character varying(500),
    is_active boolean NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    quota_tokens_per_day integer,
    quota_tokens_per_month integer,
    tokens_used_today integer NOT NULL,
    tokens_used_month integer NOT NULL,
    tokens_used_total integer NOT NULL,
    tokens_reset_at timestamp with time zone
);

ALTER TABLE ONLY public.users FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_definitions (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    definition_version integer DEFAULT 1 NOT NULL,
    definition_hash character varying(80) NOT NULL,
    definition_json jsonb NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    visibility_scope character varying(20) DEFAULT 'agent'::character varying NOT NULL,
    call_policy jsonb,
    owner_type character varying(20) DEFAULT 'user'::character varying NOT NULL,
    owner_id uuid,
    created_by_user_id uuid,
    created_by_agent_id uuid,
    promoted_from_run_id uuid,
    promotion_proposal_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.workflow_definitions FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_leaf_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_leaf_calls (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_id character varying(100) NOT NULL,
    leaf_id character varying(200) NOT NULL,
    input_hash character varying(80),
    definition_hash character varying(80),
    idempotency_key character varying(200),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    result_ref text,
    token_usage jsonb,
    error text,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.workflow_leaf_calls FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_preview_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_preview_artifacts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    requested_by_user_id uuid NOT NULL,
    proposal_id uuid,
    candidate_id character varying(160),
    status character varying(24) DEFAULT 'ready'::character varying NOT NULL,
    artifact_version integer DEFAULT 1 NOT NULL,
    artifact_hash character varying(80) NOT NULL,
    definition_hash character varying(80) NOT NULL,
    args_hash character varying(80) NOT NULL,
    definition_json jsonb NOT NULL,
    args_json jsonb NOT NULL,
    preview_json jsonb NOT NULL,
    confirmed_by_user_id uuid,
    confirmation_source character varying(64),
    confirmation_evidence_id character varying(200),
    confirmed_at timestamp with time zone,
    run_id uuid,
    claim_token uuid,
    claim_expires_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    failure_code character varying(100),
    failure_message text,
    started_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_workflow_preview_artifact_status CHECK (((status)::text = ANY ((ARRAY['ready'::character varying, 'starting'::character varying, 'started'::character varying, 'failed'::character varying, 'expired'::character varying])::text[])))
);

ALTER TABLE ONLY public.workflow_preview_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_promotion_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_promotion_proposals (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    run_id uuid NOT NULL,
    root_session_id uuid NOT NULL,
    requester_user_id uuid NOT NULL,
    reviewer_user_id uuid,
    proposal_hash character varying(64) NOT NULL,
    run_evidence_hash character varying(64) NOT NULL,
    definition_hash character varying(64) NOT NULL,
    definition_json jsonb NOT NULL,
    run_evidence_json jsonb NOT NULL,
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    review_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp with time zone,
    CONSTRAINT ck_workflow_promotion_proposal_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'stale'::character varying, 'withdrawn'::character varying])::text[])))
);

ALTER TABLE ONLY public.workflow_promotion_proposals FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_proposal_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_proposal_artifacts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    session_id uuid NOT NULL,
    requested_by_user_id uuid NOT NULL,
    status character varying(24) DEFAULT 'open'::character varying NOT NULL,
    artifact_version integer DEFAULT 1 NOT NULL,
    artifact_hash character varying(80) NOT NULL,
    proposal_json jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_workflow_proposal_artifact_status CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'previewed'::character varying, 'expired'::character varying])::text[])))
);

ALTER TABLE ONLY public.workflow_proposal_artifacts FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_quotas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_quotas (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    run_id uuid NOT NULL,
    allocated_tokens bigint DEFAULT '0'::bigint NOT NULL,
    consumed_tokens bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.workflow_quotas FORCE ROW LEVEL SECURITY;


--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_steps (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    run_id uuid NOT NULL,
    step_id character varying(100) NOT NULL,
    step_type character varying(30) DEFAULT 'agent_step'::character varying NOT NULL,
    status character varying(40) DEFAULT 'pending'::character varying NOT NULL,
    input_hash character varying(80),
    definition_hash character varying(80),
    result_ref text,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone
);

ALTER TABLE ONLY public.workflow_steps FORCE ROW LEVEL SECURITY;


--
-- Name: workspace_resource_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_resource_manifests (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    path character varying(1024) NOT NULL,
    owner_user_id uuid,
    root_session_id uuid,
    authority_state character varying(24) NOT NULL,
    source character varying(64) NOT NULL,
    content_hash character varying(64),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_workspace_resource_manifest_authority_state CHECK (((authority_state)::text = ANY ((ARRAY['owned'::character varying, 'quarantined'::character varying])::text[])))
);

ALTER TABLE ONLY public.workspace_resource_manifests FORCE ROW LEVEL SECURITY;


--
-- Name: agent_activity_logs agent_activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_activity_logs
    ADD CONSTRAINT agent_activity_logs_pkey PRIMARY KEY (id);


--
-- Name: agent_capability_installs agent_capability_installs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_capability_installs
    ADD CONSTRAINT agent_capability_installs_pkey PRIMARY KEY (id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_pkey PRIMARY KEY (id);


--
-- Name: agent_collaboration_groups agent_collaboration_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_groups
    ADD CONSTRAINT agent_collaboration_groups_pkey PRIMARY KEY (id);


--
-- Name: agent_mcp_server_assignments agent_mcp_server_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_server_assignments
    ADD CONSTRAINT agent_mcp_server_assignments_pkey PRIMARY KEY (id);


--
-- Name: agent_mcp_tool_overrides agent_mcp_tool_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_tool_overrides
    ADD CONSTRAINT agent_mcp_tool_overrides_pkey PRIMARY KEY (id);


--
-- Name: agent_permissions agent_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_permissions
    ADD CONSTRAINT agent_permissions_pkey PRIMARY KEY (id);


--
-- Name: agent_plan_recommendations agent_plan_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_pkey PRIMARY KEY (id);


--
-- Name: agent_plan_requests agent_plan_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_pkey PRIMARY KEY (id);


--
-- Name: agent_plugin_assignments agent_plugin_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plugin_assignments
    ADD CONSTRAINT agent_plugin_assignments_pkey PRIMARY KEY (id);


--
-- Name: agent_relationships agent_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_relationships
    ADD CONSTRAINT agent_relationships_pkey PRIMARY KEY (id);


--
-- Name: agent_schedules agent_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_pkey PRIMARY KEY (id);


--
-- Name: agent_session_goals agent_session_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_session_goals
    ADD CONSTRAINT agent_session_goals_pkey PRIMARY KEY (id);


--
-- Name: agent_team_events agent_team_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_events
    ADD CONSTRAINT agent_team_events_pkey PRIMARY KEY (id);


--
-- Name: agent_team_members agent_team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_members
    ADD CONSTRAINT agent_team_members_pkey PRIMARY KEY (id);


--
-- Name: agent_teams agent_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_teams
    ADD CONSTRAINT agent_teams_pkey PRIMARY KEY (id);


--
-- Name: agent_templates agent_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_pkey PRIMARY KEY (id);


--
-- Name: agent_tools agent_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_pkey PRIMARY KEY (id);


--
-- Name: agent_triggers agent_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: ai_asset_records ai_asset_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_pkey PRIMARY KEY (id);


--
-- Name: ai_asset_usage_events ai_asset_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_usage_events
    ADD CONSTRAINT ai_asset_usage_events_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkey PRIMARY KEY (version_num);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: budget_transition_outbox budget_transition_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_pkey PRIMARY KEY (id);


--
-- Name: capability_factor_reviews capability_factor_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factor_reviews
    ADD CONSTRAINT capability_factor_reviews_pkey PRIMARY KEY (id);


--
-- Name: capability_factors capability_factors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factors
    ADD CONSTRAINT capability_factors_pkey PRIMARY KEY (id);


--
-- Name: capability_policies capability_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_policies
    ADD CONSTRAINT capability_policies_pkey PRIMARY KEY (id);


--
-- Name: capability_promotion_proposals capability_promotion_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_pkey PRIMARY KEY (id);


--
-- Name: channel_configs channel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_pkey PRIMARY KEY (id);


--
-- Name: channel_delivery_outbox channel_delivery_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_pkey PRIMARY KEY (id);


--
-- Name: channel_ingress_events channel_ingress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_pkey PRIMARY KEY (id);


--
-- Name: charter_proposals charter_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charter_proposals
    ADD CONSTRAINT charter_proposals_pkey PRIMARY KEY (id);


--
-- Name: chat_artifacts chat_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: chat_transcript_events chat_transcript_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_events company_knowledge_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_events
    ADD CONSTRAINT company_knowledge_events_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_evidence company_knowledge_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_evidence
    ADD CONSTRAINT company_knowledge_evidence_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_outbox company_knowledge_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_outbox
    ADD CONSTRAINT company_knowledge_outbox_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_proposals company_knowledge_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT company_knowledge_proposals_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_publications company_knowledge_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_reviews company_knowledge_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_reviews
    ADD CONSTRAINT company_knowledge_reviews_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_source_contracts company_knowledge_source_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_source_contracts
    ADD CONSTRAINT company_knowledge_source_contracts_pkey PRIMARY KEY (id);


--
-- Name: company_knowledge_sources company_knowledge_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_sources
    ADD CONSTRAINT company_knowledge_sources_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_action_types company_ontology_action_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_action_types
    ADD CONSTRAINT company_ontology_action_types_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_activations company_ontology_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT company_ontology_activations_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_assertions company_ontology_assertions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_curation_runs company_ontology_curation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT company_ontology_curation_runs_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_event_types company_ontology_event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_event_types
    ADD CONSTRAINT company_ontology_event_types_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_events company_ontology_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT company_ontology_events_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_evidence_bindings company_ontology_evidence_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_evidence_bindings
    ADD CONSTRAINT company_ontology_evidence_bindings_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_link_types company_ontology_link_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_link_types
    ADD CONSTRAINT company_ontology_link_types_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_links company_ontology_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_object_identities company_ontology_object_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT company_ontology_object_identities_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_object_types company_ontology_object_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_types
    ADD CONSTRAINT company_ontology_object_types_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_objects company_ontology_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_objects
    ADD CONSTRAINT company_ontology_objects_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_package_installations company_ontology_package_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_installations
    ADD CONSTRAINT company_ontology_package_installations_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_package_versions company_ontology_package_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_versions
    ADD CONSTRAINT company_ontology_package_versions_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_packages company_ontology_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_packages
    ADD CONSTRAINT company_ontology_packages_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_property_types company_ontology_property_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_property_types
    ADD CONSTRAINT company_ontology_property_types_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_release_items company_ontology_release_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_release_items
    ADD CONSTRAINT company_ontology_release_items_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_releases company_ontology_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_pkey PRIMARY KEY (id);


--
-- Name: company_ontology_rule_definitions company_ontology_rule_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_rule_definitions
    ADD CONSTRAINT company_ontology_rule_definitions_pkey PRIMARY KEY (id);


--
-- Name: config_revisions config_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_pkey PRIMARY KEY (id);


--
-- Name: coordination_checkpoints coordination_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_checkpoints
    ADD CONSTRAINT coordination_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: coordination_leases coordination_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_leases
    ADD CONSTRAINT coordination_leases_pkey PRIMARY KEY (id);


--
-- Name: coordination_signals coordination_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_signals
    ADD CONSTRAINT coordination_signals_pkey PRIMARY KEY (id);


--
-- Name: decision_trace_feedback decision_trace_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_trace_feedback
    ADD CONSTRAINT decision_trace_feedback_pkey PRIMARY KEY (id);


--
-- Name: decision_traces decision_traces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_traces
    ADD CONSTRAINT decision_traces_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: enterprise_info enterprise_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_info
    ADD CONSTRAINT enterprise_info_pkey PRIMARY KEY (id);


--
-- Name: external_capability_reviews external_capability_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_reviews
    ADD CONSTRAINT external_capability_reviews_pkey PRIMARY KEY (id);


--
-- Name: external_capability_snapshots external_capability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT external_capability_snapshots_pkey PRIMARY KEY (id);


--
-- Name: external_extension_activations external_extension_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_pkey PRIMARY KEY (id);


--
-- Name: external_extension_catalog_entries external_extension_catalog_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_catalog_entries
    ADD CONSTRAINT external_extension_catalog_entries_pkey PRIMARY KEY (id);


--
-- Name: external_extension_components external_extension_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_components
    ADD CONSTRAINT external_extension_components_pkey PRIMARY KEY (id);


--
-- Name: external_extension_hook_registrations external_extension_hook_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_hook_registrations
    ADD CONSTRAINT external_extension_hook_registrations_pkey PRIMARY KEY (id);


--
-- Name: external_identities external_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT external_identities_pkey PRIMARY KEY (id);


--
-- Name: external_marketplace_entries external_marketplace_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT external_marketplace_entries_pkey PRIMARY KEY (id);


--
-- Name: external_marketplace_sources external_marketplace_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_sources
    ADD CONSTRAINT external_marketplace_sources_pkey PRIMARY KEY (id);


--
-- Name: external_principal_binding_events external_principal_binding_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_pkey PRIMARY KEY (id);


--
-- Name: external_principals external_principals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principals
    ADD CONSTRAINT external_principals_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: guard_policies guard_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guard_policies
    ADD CONSTRAINT guard_policies_pkey PRIMARY KEY (id);


--
-- Name: hr_creation_drafts hr_creation_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_pkey PRIMARY KEY (id);


--
-- Name: hr_provisioning_steps hr_provisioning_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_provisioning_steps
    ADD CONSTRAINT hr_provisioning_steps_pkey PRIMARY KEY (id);


--
-- Name: identity_providers identity_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_providers
    ADD CONSTRAINT identity_providers_pkey PRIMARY KEY (id);


--
-- Name: invitation_codes invitation_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitation_codes
    ADD CONSTRAINT invitation_codes_pkey PRIMARY KEY (id);


--
-- Name: invocation_spans invocation_spans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT invocation_spans_pkey PRIMARY KEY (id);


--
-- Name: knowledge_assertions knowledge_assertions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT knowledge_assertions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_documents knowledge_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_pkey PRIMARY KEY (id);


--
-- Name: knowledge_entities knowledge_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT knowledge_entities_pkey PRIMARY KEY (id);


--
-- Name: knowledge_grants knowledge_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_pkey PRIMARY KEY (id);


--
-- Name: knowledge_index_jobs knowledge_index_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_index_jobs
    ADD CONSTRAINT knowledge_index_jobs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_links knowledge_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT knowledge_links_pkey PRIMARY KEY (id);


--
-- Name: knowledge_segments knowledge_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_segments
    ADD CONSTRAINT knowledge_segments_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (id);


--
-- Name: local_agent_bridge_connections local_agent_bridge_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_connections
    ADD CONSTRAINT local_agent_bridge_connections_pkey PRIMARY KEY (id);


--
-- Name: local_agent_bridge_pairing_sessions local_agent_bridge_pairing_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT local_agent_bridge_pairing_sessions_pkey PRIMARY KEY (id);


--
-- Name: local_agent_capability_snapshots local_agent_capability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT local_agent_capability_snapshots_pkey PRIMARY KEY (id);


--
-- Name: local_agent_channel_events local_agent_channel_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_pkey PRIMARY KEY (id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_pkey PRIMARY KEY (id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_pkey PRIMARY KEY (id);


--
-- Name: local_agent_channel_ws_tickets local_agent_channel_ws_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_ws_tickets
    ADD CONSTRAINT local_agent_channel_ws_tickets_pkey PRIMARY KEY (id);


--
-- Name: local_agent_channels local_agent_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channels
    ADD CONSTRAINT local_agent_channels_pkey PRIMARY KEY (id);


--
-- Name: mcp_server_tools mcp_server_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_tools
    ADD CONSTRAINT mcp_server_tools_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: org_departments org_departments_feishu_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_departments
    ADD CONSTRAINT org_departments_feishu_id_key UNIQUE (feishu_id);


--
-- Name: org_departments org_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_departments
    ADD CONSTRAINT org_departments_pkey PRIMARY KEY (id);


--
-- Name: org_members org_members_feishu_open_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_feishu_open_id_key UNIQUE (feishu_open_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (id);


--
-- Name: pending_reply_contexts pending_reply_contexts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_reply_contexts
    ADD CONSTRAINT pending_reply_contexts_pkey PRIMARY KEY (id);


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_pkey PRIMARY KEY (id);


--
-- Name: plaza_comments plaza_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plaza_comments
    ADD CONSTRAINT plaza_comments_pkey PRIMARY KEY (id);


--
-- Name: plaza_likes plaza_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plaza_likes
    ADD CONSTRAINT plaza_likes_pkey PRIMARY KEY (id);


--
-- Name: plaza_posts plaza_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plaza_posts
    ADD CONSTRAINT plaza_posts_pkey PRIMARY KEY (id);


--
-- Name: plugin_dependency_edges plugin_dependency_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_dependency_edges
    ADD CONSTRAINT plugin_dependency_edges_pkey PRIMARY KEY (id);


--
-- Name: plugin_hook_registrations plugin_hook_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_hook_registrations
    ADD CONSTRAINT plugin_hook_registrations_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: resource_permissions resource_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_permissions
    ADD CONSTRAINT resource_permissions_pkey PRIMARY KEY (id);


--
-- Name: runtime_budget_events runtime_budget_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_events
    ADD CONSTRAINT runtime_budget_events_pkey PRIMARY KEY (id);


--
-- Name: runtime_budget_policies runtime_budget_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_policies
    ADD CONSTRAINT runtime_budget_policies_pkey PRIMARY KEY (id);


--
-- Name: runtime_budget_runs runtime_budget_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_runs
    ADD CONSTRAINT runtime_budget_runs_pkey PRIMARY KEY (id);


--
-- Name: runtime_notification_outbox runtime_notification_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_pkey PRIMARY KEY (id);


--
-- Name: runtime_result_integration_pages runtime_result_integration_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT runtime_result_integration_pages_pkey PRIMARY KEY (id);


--
-- Name: runtime_result_mailbox_cursors runtime_result_mailbox_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_mailbox_cursors
    ADD CONSTRAINT runtime_result_mailbox_cursors_pkey PRIMARY KEY (id);


--
-- Name: runtime_result_objects runtime_result_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_objects
    ADD CONSTRAINT runtime_result_objects_pkey PRIMARY KEY (id);


--
-- Name: runtime_root_items runtime_root_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_root_items
    ADD CONSTRAINT runtime_root_items_pkey PRIMARY KEY (id);


--
-- Name: runtime_tasks runtime_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_tasks
    ADD CONSTRAINT runtime_tasks_pkey PRIMARY KEY (id);


--
-- Name: runtime_terminal_boundary_outbox runtime_terminal_boundary_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT runtime_terminal_boundary_outbox_pkey PRIMARY KEY (id);


--
-- Name: security_audit_events security_audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_audit_events
    ADD CONSTRAINT security_audit_events_pkey PRIMARY KEY (id);


--
-- Name: security_audit_events security_audit_events_sequence_num_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_audit_events
    ADD CONSTRAINT security_audit_events_sequence_num_key UNIQUE (sequence_num);


--
-- Name: session_carry_forwards session_carry_forwards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_pkey PRIMARY KEY (id);


--
-- Name: session_commands session_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_commands
    ADD CONSTRAINT session_commands_pkey PRIMARY KEY (id);


--
-- Name: session_control_inputs session_control_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT session_control_inputs_pkey PRIMARY KEY (id);


--
-- Name: session_event_cursors session_event_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_cursors
    ADD CONSTRAINT session_event_cursors_pkey PRIMARY KEY (session_id);


--
-- Name: session_event_outbox session_event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT session_event_outbox_pkey PRIMARY KEY (id);


--
-- Name: session_feedback_aggregates session_feedback_aggregates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_aggregates
    ADD CONSTRAINT session_feedback_aggregates_pkey PRIMARY KEY (id);


--
-- Name: session_feedback_events session_feedback_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_pkey PRIMARY KEY (id);


--
-- Name: session_input_admissions session_input_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT session_input_admissions_pkey PRIMARY KEY (id);


--
-- Name: session_model_results session_model_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT session_model_results_pkey PRIMARY KEY (id);


--
-- Name: session_next_round_plans session_next_round_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT session_next_round_plans_pkey PRIMARY KEY (id);


--
-- Name: session_round_obligations session_round_obligations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT session_round_obligations_pkey PRIMARY KEY (id);


--
-- Name: session_run_outcomes session_run_outcomes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_pkey PRIMARY KEY (id);


--
-- Name: session_tool_invocations session_tool_invocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_pkey PRIMARY KEY (id);


--
-- Name: session_tool_invocations session_tool_invocations_result_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_result_event_id_key UNIQUE (result_event_id);


--
-- Name: session_turn_inputs session_turn_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT session_turn_inputs_pkey PRIMARY KEY (id);


--
-- Name: session_turn_replacements session_turn_replacements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_pkey PRIMARY KEY (id);


--
-- Name: session_writer_epochs session_writer_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_writer_epochs
    ADD CONSTRAINT session_writer_epochs_pkey PRIMARY KEY (id);


--
-- Name: session_writer_heartbeats session_writer_heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_writer_heartbeats
    ADD CONSTRAINT session_writer_heartbeats_pkey PRIMARY KEY (id);


--
-- Name: skill_files skill_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_files
    ADD CONSTRAINT skill_files_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: sso_scan_sessions sso_scan_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_scan_sessions
    ADD CONSTRAINT sso_scan_sessions_pkey PRIMARY KEY (id);


--
-- Name: storage_blob_refs storage_blob_refs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blob_refs
    ADD CONSTRAINT storage_blob_refs_pkey PRIMARY KEY (id);


--
-- Name: storage_blobs storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blobs
    ADD CONSTRAINT storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: storage_gc_runs storage_gc_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_gc_runs
    ADD CONSTRAINT storage_gc_runs_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: task_logs task_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenant_channel_configs tenant_channel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_channel_configs
    ADD CONSTRAINT tenant_channel_configs_pkey PRIMARY KEY (id);


--
-- Name: tenant_installed_plugins tenant_installed_plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_installed_plugins
    ADD CONSTRAINT tenant_installed_plugins_pkey PRIMARY KEY (id);


--
-- Name: tenant_scope_quarantine_records tenant_scope_quarantine_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_scope_quarantine_records
    ADD CONSTRAINT tenant_scope_quarantine_records_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: tenant_tool_configs tenant_tool_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_tool_configs
    ADD CONSTRAINT tenant_tool_configs_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: token_usage_events token_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage_events
    ADD CONSTRAINT token_usage_events_pkey PRIMARY KEY (id);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (id);


--
-- Name: agent_capability_installs uq_agent_capability_install; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_capability_installs
    ADD CONSTRAINT uq_agent_capability_install UNIQUE (agent_id, kind, normalized_key);


--
-- Name: agent_collaboration_group_members uq_agent_collaboration_group_member_agent; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT uq_agent_collaboration_group_member_agent UNIQUE (group_id, agent_id);


--
-- Name: agent_mcp_server_assignments uq_agent_mcp_assignment_tenant_agent_server; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_server_assignments
    ADD CONSTRAINT uq_agent_mcp_assignment_tenant_agent_server UNIQUE (tenant_id, agent_id, mcp_server_id);


--
-- Name: agent_mcp_tool_overrides uq_agent_mcp_override_tenant_agent_server_tool; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_tool_overrides
    ADD CONSTRAINT uq_agent_mcp_override_tenant_agent_server_tool UNIQUE (tenant_id, agent_id, mcp_server_id, tool_name);


--
-- Name: agent_plugin_assignments uq_agent_plugin_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plugin_assignments
    ADD CONSTRAINT uq_agent_plugin_assignment UNIQUE (tenant_id, agent_id, installed_plugin_id);


--
-- Name: agent_tools uq_agent_tools_agent_tool; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT uq_agent_tools_agent_tool UNIQUE (agent_id, tool_id);


--
-- Name: agent_triggers uq_agent_trigger_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT uq_agent_trigger_name UNIQUE (agent_id, name);


--
-- Name: ai_asset_records uq_ai_asset_native_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT uq_ai_asset_native_key UNIQUE (tenant_id, asset_type, native_key);


--
-- Name: ai_asset_usage_events uq_ai_asset_usage_event_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_usage_events
    ADD CONSTRAINT uq_ai_asset_usage_event_idempotency UNIQUE (tenant_id, asset_id, idempotency_key);


--
-- Name: approval_requests uq_approval_requests_execution_idempotency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT uq_approval_requests_execution_idempotency_key UNIQUE (execution_idempotency_key);


--
-- Name: approval_requests uq_approval_requests_execution_task_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT uq_approval_requests_execution_task_id UNIQUE (execution_task_id);


--
-- Name: budget_transition_outbox uq_budget_transition_outbox_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT uq_budget_transition_outbox_event UNIQUE (budget_event_id);


--
-- Name: capability_policies uq_capability_policy; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_policies
    ADD CONSTRAINT uq_capability_policy UNIQUE (tenant_id, agent_id, capability);


--
-- Name: channel_configs uq_channel_configs_agent_channel; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT uq_channel_configs_agent_channel UNIQUE (agent_id, channel_type);


--
-- Name: channel_delivery_outbox uq_channel_delivery_outbox_runtime_target; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT uq_channel_delivery_outbox_runtime_target UNIQUE (tenant_id, runtime_task_id, delivery_kind, target_hash);


--
-- Name: channel_ingress_events uq_channel_ingress_provider_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT uq_channel_ingress_provider_event UNIQUE (tenant_id, provider, installation_ref, provider_event_id);


--
-- Name: chat_artifacts uq_chat_artifacts_agent_session_run_path_snapshot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT uq_chat_artifacts_agent_session_run_path_snapshot UNIQUE (agent_id, session_id, runtime_task_id, path, snapshot_hash);


--
-- Name: chat_sessions uq_chat_sessions_agent_ext_conv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT uq_chat_sessions_agent_ext_conv UNIQUE (agent_id, external_conv_id);


--
-- Name: chat_transcript_events uq_chat_transcript_events_session_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT uq_chat_transcript_events_session_sequence UNIQUE (session_id, sequence);


--
-- Name: company_knowledge_events uq_company_knowledge_event_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_events
    ADD CONSTRAINT uq_company_knowledge_event_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_knowledge_events uq_company_knowledge_event_stream_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_events
    ADD CONSTRAINT uq_company_knowledge_event_stream_sequence UNIQUE (tenant_id, stream_sequence);


--
-- Name: company_knowledge_evidence uq_company_knowledge_evidence_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_evidence
    ADD CONSTRAINT uq_company_knowledge_evidence_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_knowledge_import_jobs uq_company_knowledge_import_job_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT uq_company_knowledge_import_job_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_knowledge_outbox uq_company_knowledge_outbox_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_outbox
    ADD CONSTRAINT uq_company_knowledge_outbox_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_knowledge_proposals uq_company_knowledge_proposal_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT uq_company_knowledge_proposal_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_knowledge_proposals uq_company_knowledge_proposal_materialization_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT uq_company_knowledge_proposal_materialization_idempotency UNIQUE (tenant_id, materialization_idempotency_key);


--
-- Name: company_knowledge_publications uq_company_knowledge_publication_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT uq_company_knowledge_publication_version UNIQUE (tenant_id, logical_resource_key, version);


--
-- Name: company_knowledge_reviews uq_company_knowledge_review_round; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_reviews
    ADD CONSTRAINT uq_company_knowledge_review_round UNIQUE (tenant_id, proposal_id, reviewer_user_id, review_round);


--
-- Name: company_knowledge_source_contracts uq_company_knowledge_source_contract_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_source_contracts
    ADD CONSTRAINT uq_company_knowledge_source_contract_version UNIQUE (tenant_id, stable_source_id, version);


--
-- Name: company_knowledge_sources uq_company_knowledge_source_revision; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_sources
    ADD CONSTRAINT uq_company_knowledge_source_revision UNIQUE (tenant_id, source_contract_id, source_item_id, source_revision);


--
-- Name: company_ontology_action_types uq_company_ontology_action_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_action_types
    ADD CONSTRAINT uq_company_ontology_action_type UNIQUE (tenant_id, release_id, action_type_ref);


--
-- Name: company_ontology_activations uq_company_ontology_activation_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT uq_company_ontology_activation_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_ontology_activations uq_company_ontology_activation_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT uq_company_ontology_activation_version UNIQUE (tenant_id, namespace, activation_version);


--
-- Name: company_ontology_assertions uq_company_ontology_assertion_release_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT uq_company_ontology_assertion_release_key UNIQUE (tenant_id, release_id, stable_assertion_key);


--
-- Name: company_ontology_curation_runs uq_company_ontology_curation_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT uq_company_ontology_curation_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: company_ontology_events uq_company_ontology_event_release_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT uq_company_ontology_event_release_key UNIQUE (tenant_id, release_id, stable_event_key);


--
-- Name: company_ontology_event_types uq_company_ontology_event_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_event_types
    ADD CONSTRAINT uq_company_ontology_event_type UNIQUE (tenant_id, release_id, event_type_ref);


--
-- Name: company_ontology_evidence_bindings uq_company_ontology_evidence_binding; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_evidence_bindings
    ADD CONSTRAINT uq_company_ontology_evidence_binding UNIQUE (tenant_id, subject_kind, subject_id, bundle_key, evidence_id);


--
-- Name: company_ontology_links uq_company_ontology_link_release_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT uq_company_ontology_link_release_key UNIQUE (tenant_id, release_id, stable_link_key);


--
-- Name: company_ontology_link_types uq_company_ontology_link_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_link_types
    ADD CONSTRAINT uq_company_ontology_link_type UNIQUE (tenant_id, release_id, link_type_ref);


--
-- Name: company_ontology_objects uq_company_ontology_object_release_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_objects
    ADD CONSTRAINT uq_company_ontology_object_release_key UNIQUE (tenant_id, release_id, stable_object_key);


--
-- Name: company_ontology_object_types uq_company_ontology_object_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_types
    ADD CONSTRAINT uq_company_ontology_object_type UNIQUE (tenant_id, release_id, type_ref);


--
-- Name: company_ontology_package_versions uq_company_ontology_package_content_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_versions
    ADD CONSTRAINT uq_company_ontology_package_content_hash UNIQUE (tenant_id, content_hash);


--
-- Name: company_ontology_package_installations uq_company_ontology_package_installation; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_installations
    ADD CONSTRAINT uq_company_ontology_package_installation UNIQUE (tenant_id, package_version_id);


--
-- Name: company_ontology_packages uq_company_ontology_package_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_packages
    ADD CONSTRAINT uq_company_ontology_package_key UNIQUE (tenant_id, package_key);


--
-- Name: company_ontology_package_versions uq_company_ontology_package_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_versions
    ADD CONSTRAINT uq_company_ontology_package_version UNIQUE (tenant_id, package_id, version);


--
-- Name: company_ontology_property_types uq_company_ontology_property_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_property_types
    ADD CONSTRAINT uq_company_ontology_property_type UNIQUE (tenant_id, release_id, property_ref);


--
-- Name: company_ontology_release_items uq_company_ontology_release_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_release_items
    ADD CONSTRAINT uq_company_ontology_release_item UNIQUE (tenant_id, release_id, item_kind, item_id);


--
-- Name: company_ontology_releases uq_company_ontology_release_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT uq_company_ontology_release_version UNIQUE (tenant_id, namespace, version);


--
-- Name: company_ontology_rule_definitions uq_company_ontology_rule_definition; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_rule_definitions
    ADD CONSTRAINT uq_company_ontology_rule_definition UNIQUE (tenant_id, release_id, rule_ref);


--
-- Name: company_ontology_object_identities uq_company_ontology_source_identity_object; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT uq_company_ontology_source_identity_object UNIQUE (tenant_id, object_id, source_contract_id, source_identity_key);


--
-- Name: config_revisions uq_config_revision_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT uq_config_revision_version UNIQUE (entity_type, entity_id, version);


--
-- Name: coordination_leases uq_coordination_lease_tenant_task; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_leases
    ADD CONSTRAINT uq_coordination_lease_tenant_task UNIQUE (tenant_id, task_key);


--
-- Name: enterprise_info uq_enterprise_info_tenant_info_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_info
    ADD CONSTRAINT uq_enterprise_info_tenant_info_type UNIQUE (tenant_id, info_type);


--
-- Name: external_extension_catalog_entries uq_external_catalog_snapshot_component; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_catalog_entries
    ADD CONSTRAINT uq_external_catalog_snapshot_component UNIQUE (tenant_id, snapshot_id, qualified_name);


--
-- Name: external_extension_components uq_external_component_snapshot_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_components
    ADD CONSTRAINT uq_external_component_snapshot_name UNIQUE (tenant_id, snapshot_id, qualified_name);


--
-- Name: external_extension_hook_registrations uq_external_hook_snapshot_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_hook_registrations
    ADD CONSTRAINT uq_external_hook_snapshot_name UNIQUE (tenant_id, snapshot_id, qualified_name);


--
-- Name: external_identities uq_external_identities_provider_open_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT uq_external_identities_provider_open_id UNIQUE (provider_id, provider_open_id);


--
-- Name: external_identities uq_external_identities_provider_union_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT uq_external_identities_provider_union_id UNIQUE (provider_id, provider_union_id);


--
-- Name: external_identities uq_external_identities_provider_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT uq_external_identities_provider_user_id UNIQUE (provider_id, provider_user_id);


--
-- Name: external_marketplace_entries uq_external_marketplace_entry_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT uq_external_marketplace_entry_key UNIQUE (tenant_id, source_id, external_key);


--
-- Name: external_marketplace_sources uq_external_marketplace_source_uri; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_sources
    ADD CONSTRAINT uq_external_marketplace_source_uri UNIQUE (tenant_id, source_uri);


--
-- Name: external_principals uq_external_principals_tenant_provider_installation_subject; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principals
    ADD CONSTRAINT uq_external_principals_tenant_provider_installation_subject UNIQUE (tenant_id, provider, installation_ref, subject_id);


--
-- Name: external_capability_reviews uq_external_review_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_reviews
    ADD CONSTRAINT uq_external_review_source UNIQUE (tenant_id, source_format, source_uri, source_hash);


--
-- Name: external_capability_snapshots uq_external_snapshot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT uq_external_snapshot_key UNIQUE (tenant_id, snapshot_key);


--
-- Name: hr_creation_drafts uq_hr_creation_draft_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT uq_hr_creation_draft_idempotency UNIQUE (tenant_id, creation_idempotency_key);


--
-- Name: hr_creation_drafts uq_hr_creation_drafts_provisioning_task_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT uq_hr_creation_drafts_provisioning_task_id UNIQUE (provisioning_task_id);


--
-- Name: hr_provisioning_steps uq_hr_provisioning_step_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_provisioning_steps
    ADD CONSTRAINT uq_hr_provisioning_step_key UNIQUE (tenant_id, draft_id, step_key);


--
-- Name: identity_providers uq_identity_providers_type_tenant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_providers
    ADD CONSTRAINT uq_identity_providers_type_tenant UNIQUE (provider_type, tenant_id);


--
-- Name: tenant_installed_plugins uq_installed_plugins_tenant_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_installed_plugins
    ADD CONSTRAINT uq_installed_plugins_tenant_key UNIQUE (tenant_id, plugin_key);


--
-- Name: invocation_spans uq_invocation_spans_trace_span; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT uq_invocation_spans_trace_span UNIQUE (tenant_id, trace_id, span_id);


--
-- Name: knowledge_assertions uq_knowledge_assertion_text; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT uq_knowledge_assertion_text UNIQUE (tenant_id, scope_type, scope_id, subject_text, predicate, object_text);


--
-- Name: knowledge_documents uq_knowledge_document_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT uq_knowledge_document_source UNIQUE (tenant_id, scope_type, scope_id, source_sha256);


--
-- Name: knowledge_entities uq_knowledge_entity_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT uq_knowledge_entity_name UNIQUE (tenant_id, scope_type, scope_id, entity_type, canonical_name);


--
-- Name: knowledge_grants uq_knowledge_grant_resource_grantee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT uq_knowledge_grant_resource_grantee UNIQUE (tenant_id, scope_type, scope_id, resource_type, resource_id, grantee_type, grantee_id, permission, binding_key);


--
-- Name: knowledge_index_jobs uq_knowledge_index_job_artifact; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_index_jobs
    ADD CONSTRAINT uq_knowledge_index_job_artifact UNIQUE (tenant_id, document_id, artifact_hash);


--
-- Name: knowledge_links uq_knowledge_link_edge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT uq_knowledge_link_edge UNIQUE (tenant_id, scope_type, scope_id, from_kind, from_id, to_kind, to_id, relation);


--
-- Name: knowledge_segments uq_knowledge_segment_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_segments
    ADD CONSTRAINT uq_knowledge_segment_hash UNIQUE (tenant_id, document_id, segment_hash);


--
-- Name: knowledge_segments uq_knowledge_segment_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_segments
    ADD CONSTRAINT uq_knowledge_segment_position UNIQUE (tenant_id, document_id, "position");


--
-- Name: llm_models uq_llm_models_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT uq_llm_models_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: local_agent_capability_snapshots uq_local_agent_capability_snapshot_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT uq_local_agent_capability_snapshot_hash UNIQUE (snapshot_hash);


--
-- Name: local_agent_capability_snapshots uq_local_agent_capability_snapshot_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT uq_local_agent_capability_snapshot_version UNIQUE (channel_id, version);


--
-- Name: local_agent_channel_events uq_local_agent_channel_events_session_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT uq_local_agent_channel_events_session_sequence UNIQUE (session_id, sequence);


--
-- Name: local_agent_channel_messages uq_local_agent_channel_messages_tenant_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT uq_local_agent_channel_messages_tenant_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: local_agent_channel_ws_tickets uq_local_agent_channel_ws_ticket_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_ws_tickets
    ADD CONSTRAINT uq_local_agent_channel_ws_ticket_hash UNIQUE (ticket_hash);


--
-- Name: local_agent_channels uq_local_agent_channels_connection_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channels
    ADD CONSTRAINT uq_local_agent_channels_connection_id UNIQUE (connection_id);


--
-- Name: local_agent_bridge_connections uq_local_bridge_connection_token_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_connections
    ADD CONSTRAINT uq_local_bridge_connection_token_hash UNIQUE (token_hash);


--
-- Name: local_agent_bridge_pairing_sessions uq_local_bridge_device_code_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT uq_local_bridge_device_code_hash UNIQUE (device_code_hash);


--
-- Name: local_agent_bridge_pairing_sessions uq_local_bridge_pairing_code_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT uq_local_bridge_pairing_code_hash UNIQUE (pairing_code_hash);


--
-- Name: mcp_server_tools uq_mcp_server_tools_tenant_server_tool; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_tools
    ADD CONSTRAINT uq_mcp_server_tools_tenant_server_tool UNIQUE (tenant_id, mcp_server_id, mcp_tool_name);


--
-- Name: mcp_servers uq_mcp_servers_tenant_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT uq_mcp_servers_tenant_key UNIQUE (tenant_id, server_key);


--
-- Name: participants uq_participants_type_ref; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT uq_participants_type_ref UNIQUE (type, ref_id);


--
-- Name: personal_knowledge_proposals uq_personal_kb_proposal_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT uq_personal_kb_proposal_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: plugin_dependency_edges uq_plugin_dependency_edge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_dependency_edges
    ADD CONSTRAINT uq_plugin_dependency_edge UNIQUE (tenant_id, installed_plugin_id, dependency_plugin_id);


--
-- Name: plugin_hook_registrations uq_plugin_hook_registration; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_hook_registrations
    ADD CONSTRAINT uq_plugin_hook_registration UNIQUE (tenant_id, installed_plugin_id, event, handler);


--
-- Name: runtime_budget_events uq_runtime_budget_event_key_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_events
    ADD CONSTRAINT uq_runtime_budget_event_key_type UNIQUE (budget_run_id, reservation_key, event_type);


--
-- Name: runtime_budget_runs uq_runtime_budget_root_run; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_runs
    ADD CONSTRAINT uq_runtime_budget_root_run UNIQUE (tenant_id, root_run_kind, root_run_key);


--
-- Name: runtime_notification_outbox uq_runtime_notification_outbox_delivery; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT uq_runtime_notification_outbox_delivery UNIQUE (tenant_id, source_kind, source_run_id, parent_session_id, terminal_status);


--
-- Name: runtime_notification_outbox uq_runtime_notification_outbox_mailbox_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT uq_runtime_notification_outbox_mailbox_sequence UNIQUE (tenant_id, parent_session_id, mailbox_sequence);


--
-- Name: runtime_result_integration_pages uq_runtime_result_integration_pages_parent_epoch; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT uq_runtime_result_integration_pages_parent_epoch UNIQUE (tenant_id, parent_session_id, integration_epoch);


--
-- Name: runtime_result_mailbox_cursors uq_runtime_result_mailbox_cursor_parent; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_mailbox_cursors
    ADD CONSTRAINT uq_runtime_result_mailbox_cursor_parent UNIQUE (tenant_id, parent_session_id);


--
-- Name: runtime_result_objects uq_runtime_result_objects_source_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_objects
    ADD CONSTRAINT uq_runtime_result_objects_source_hash UNIQUE (tenant_id, source_kind, source_run_id, sha256);


--
-- Name: runtime_root_items uq_runtime_root_items_root_intent; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_root_items
    ADD CONSTRAINT uq_runtime_root_items_root_intent UNIQUE (tenant_id, root_runtime_task_id, intent_key);


--
-- Name: runtime_tasks uq_runtime_tasks_root_idempotency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_tasks
    ADD CONSTRAINT uq_runtime_tasks_root_idempotency_key UNIQUE (root_idempotency_key);


--
-- Name: runtime_terminal_boundary_outbox uq_runtime_terminal_boundary_authority_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT uq_runtime_terminal_boundary_authority_event UNIQUE (tenant_id, event_kind, authority_ref, authority_id);


--
-- Name: runtime_terminal_boundary_outbox uq_runtime_terminal_boundary_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT uq_runtime_terminal_boundary_idempotency UNIQUE (tenant_id, idempotency_key);


--
-- Name: session_carry_forwards uq_session_carry_forward_context_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT uq_session_carry_forward_context_item UNIQUE (tenant_id, context_source_item_id);


--
-- Name: session_carry_forwards uq_session_carry_forward_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT uq_session_carry_forward_source UNIQUE (tenant_id, source_admission_id, purpose);


--
-- Name: session_commands uq_session_commands_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_commands
    ADD CONSTRAINT uq_session_commands_idempotency UNIQUE (tenant_id, principal_type, principal_id, session_id, namespace, idempotency_key);


--
-- Name: session_control_inputs uq_session_control_inputs_command; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT uq_session_control_inputs_command UNIQUE (command_id);


--
-- Name: session_event_outbox uq_session_event_outbox_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT uq_session_event_outbox_event UNIQUE (event_id);


--
-- Name: session_event_outbox uq_session_event_outbox_session_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT uq_session_event_outbox_session_sequence UNIQUE (session_id, sequence);


--
-- Name: session_feedback_aggregates uq_session_feedback_aggregate_scope; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_aggregates
    ADD CONSTRAINT uq_session_feedback_aggregate_scope UNIQUE (tenant_id, session_id, id);


--
-- Name: session_input_admissions uq_session_input_admissions_hook_run; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT uq_session_input_admissions_hook_run UNIQUE (hook_run_id);


--
-- Name: session_input_admissions uq_session_input_admissions_input_revision; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT uq_session_input_admissions_input_revision UNIQUE (input_id, input_revision);


--
-- Name: session_model_results uq_session_model_results_provider_request; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT uq_session_model_results_provider_request UNIQUE (provider_request_id);


--
-- Name: session_model_results uq_session_model_results_round; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT uq_session_model_results_round UNIQUE (run_id, round_id);


--
-- Name: session_next_round_plans uq_session_next_round_plan_generation; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT uq_session_next_round_plan_generation UNIQUE (run_id, next_round_id, plan_generation);


--
-- Name: session_next_round_plans uq_session_next_round_plan_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT uq_session_next_round_plan_hash UNIQUE (run_id, next_round_id, plan_hash);


--
-- Name: session_round_obligations uq_session_round_obligation_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT uq_session_round_obligation_source UNIQUE (source_result_id, kind, source_generation, source_ref);


--
-- Name: session_run_outcomes uq_session_run_outcomes_run; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT uq_session_run_outcomes_run UNIQUE (run_id);


--
-- Name: session_tool_invocations uq_session_tool_effect_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT uq_session_tool_effect_key UNIQUE (effect_idempotency_key);


--
-- Name: session_tool_invocations uq_session_tool_provider_mapping; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT uq_session_tool_provider_mapping UNIQUE (provider_request_id, provider_tool_use_id);


--
-- Name: session_turn_inputs uq_session_turn_inputs_command; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT uq_session_turn_inputs_command UNIQUE (command_id);


--
-- Name: session_turn_inputs uq_session_turn_inputs_fifo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT uq_session_turn_inputs_fifo UNIQUE (session_id, queue_priority, queue_ordinal);


--
-- Name: session_turn_replacements uq_session_turn_replacements_command; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT uq_session_turn_replacements_command UNIQUE (command_id);


--
-- Name: session_turn_replacements uq_session_turn_replacements_turn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT uq_session_turn_replacements_turn UNIQUE (replacement_turn_id);


--
-- Name: session_writer_heartbeats uq_session_writer_heartbeat_instance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_writer_heartbeats
    ADD CONSTRAINT uq_session_writer_heartbeat_instance UNIQUE (service, instance_id);


--
-- Name: storage_blob_refs uq_storage_blob_refs_owner_purpose; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blob_refs
    ADD CONSTRAINT uq_storage_blob_refs_owner_purpose UNIQUE (tenant_id, blob_id, owner_type, owner_id, purpose);


--
-- Name: storage_blobs uq_storage_blobs_provider_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blobs
    ADD CONSTRAINT uq_storage_blobs_provider_location UNIQUE (provider, bucket, object_key);


--
-- Name: storage_blobs uq_storage_blobs_tenant_digest; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blobs
    ADD CONSTRAINT uq_storage_blobs_tenant_digest UNIQUE (tenant_id, content_sha256);


--
-- Name: storage_blobs uq_storage_blobs_tenant_id_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blobs
    ADD CONSTRAINT uq_storage_blobs_tenant_id_id UNIQUE (tenant_id, id);


--
-- Name: storage_gc_runs uq_storage_gc_runs_manifest_mode; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_gc_runs
    ADD CONSTRAINT uq_storage_gc_runs_manifest_mode UNIQUE (tenant_id, manifest_sha256, mode);


--
-- Name: tasks uq_tasks_tenant_agent_request_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT uq_tasks_tenant_agent_request_id UNIQUE (tenant_id, agent_id, request_id);


--
-- Name: tenant_channel_configs uq_tenant_channel_tenant_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_channel_configs
    ADD CONSTRAINT uq_tenant_channel_tenant_type UNIQUE (tenant_id, channel_type);


--
-- Name: tenant_scope_quarantine_records uq_tenant_scope_quarantine_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_scope_quarantine_records
    ADD CONSTRAINT uq_tenant_scope_quarantine_source UNIQUE (source_table, source_row_id);


--
-- Name: tenant_tool_configs uq_tenant_tool_config; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_tool_configs
    ADD CONSTRAINT uq_tenant_tool_config UNIQUE (tenant_id, tool_id);


--
-- Name: tools uq_tools_name_tenant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT uq_tools_name_tenant UNIQUE (name, tenant_id);


--
-- Name: workflow_definitions uq_workflow_definition_promotion_proposal; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT uq_workflow_definition_promotion_proposal UNIQUE (promotion_proposal_id);


--
-- Name: workflow_definitions uq_workflow_definition_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT uq_workflow_definition_version UNIQUE (tenant_id, name, definition_version);


--
-- Name: workflow_leaf_calls uq_workflow_leaf_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_leaf_calls
    ADD CONSTRAINT uq_workflow_leaf_idempotency UNIQUE (run_id, idempotency_key);


--
-- Name: workflow_leaf_calls uq_workflow_leaf_per_step; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_leaf_calls
    ADD CONSTRAINT uq_workflow_leaf_per_step UNIQUE (run_id, step_id, leaf_id);


--
-- Name: workflow_promotion_proposals uq_workflow_promotion_proposal_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT uq_workflow_promotion_proposal_hash UNIQUE (tenant_id, proposal_hash);


--
-- Name: workflow_quotas uq_workflow_quota_per_run; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_quotas
    ADD CONSTRAINT uq_workflow_quota_per_run UNIQUE (run_id);


--
-- Name: workflow_steps uq_workflow_step_per_run; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT uq_workflow_step_per_run UNIQUE (run_id, step_id);


--
-- Name: workspace_resource_manifests uq_workspace_resource_manifest_agent_path; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT uq_workspace_resource_manifest_agent_path UNIQUE (agent_id, path);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflow_definitions workflow_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT workflow_definitions_pkey PRIMARY KEY (id);


--
-- Name: workflow_leaf_calls workflow_leaf_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_leaf_calls
    ADD CONSTRAINT workflow_leaf_calls_pkey PRIMARY KEY (id);


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_pkey PRIMARY KEY (id);


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_run_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_run_id_key UNIQUE (run_id);


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_pkey PRIMARY KEY (id);


--
-- Name: workflow_proposal_artifacts workflow_proposal_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_proposal_artifacts
    ADD CONSTRAINT workflow_proposal_artifacts_pkey PRIMARY KEY (id);


--
-- Name: workflow_quotas workflow_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_quotas
    ADD CONSTRAINT workflow_quotas_pkey PRIMARY KEY (id);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workspace_resource_manifests workspace_resource_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT workspace_resource_manifests_pkey PRIMARY KEY (id);


--
-- Name: ix_agent_activity_logs_agent_action_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_agent_action_created_at ON public.agent_activity_logs USING btree (agent_id, action_type, created_at DESC);


--
-- Name: ix_agent_activity_logs_agent_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_agent_created_at ON public.agent_activity_logs USING btree (agent_id, created_at DESC);


--
-- Name: ix_agent_activity_logs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_agent_id ON public.agent_activity_logs USING btree (agent_id);


--
-- Name: ix_agent_activity_logs_authority_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_authority_state ON public.agent_activity_logs USING btree (authority_state);


--
-- Name: ix_agent_activity_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_created_at ON public.agent_activity_logs USING btree (created_at);


--
-- Name: ix_agent_activity_logs_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_owner_user_id ON public.agent_activity_logs USING btree (owner_user_id);


--
-- Name: ix_agent_activity_logs_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_root_session_id ON public.agent_activity_logs USING btree (root_session_id);


--
-- Name: ix_agent_activity_logs_tenant_action_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_tenant_action_created_at ON public.agent_activity_logs USING btree (tenant_id, action_type, created_at DESC);


--
-- Name: ix_agent_activity_logs_tenant_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_tenant_created_at ON public.agent_activity_logs USING btree (tenant_id, created_at DESC);


--
-- Name: ix_agent_activity_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_activity_logs_tenant_id ON public.agent_activity_logs USING btree (tenant_id);


--
-- Name: ix_agent_capability_installs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_capability_installs_agent_id ON public.agent_capability_installs USING btree (agent_id);


--
-- Name: ix_agent_capability_installs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_capability_installs_created_at ON public.agent_capability_installs USING btree (created_at);


--
-- Name: ix_agent_capability_installs_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_capability_installs_kind ON public.agent_capability_installs USING btree (kind);


--
-- Name: ix_agent_capability_installs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_capability_installs_status ON public.agent_capability_installs USING btree (status);


--
-- Name: ix_agent_capability_installs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_capability_installs_tenant_id ON public.agent_capability_installs USING btree (tenant_id);


--
-- Name: ix_agent_collaboration_group_members_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_agent_id ON public.agent_collaboration_group_members USING btree (agent_id);


--
-- Name: ix_agent_collaboration_group_members_approved_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_approved_by_user_id ON public.agent_collaboration_group_members USING btree (approved_by_user_id);


--
-- Name: ix_agent_collaboration_group_members_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_created_at ON public.agent_collaboration_group_members USING btree (created_at);


--
-- Name: ix_agent_collaboration_group_members_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_group_id ON public.agent_collaboration_group_members USING btree (group_id);


--
-- Name: ix_agent_collaboration_group_members_invited_by_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_invited_by_agent_id ON public.agent_collaboration_group_members USING btree (invited_by_agent_id);


--
-- Name: ix_agent_collaboration_group_members_invited_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_invited_by_user_id ON public.agent_collaboration_group_members USING btree (invited_by_user_id);


--
-- Name: ix_agent_collaboration_group_members_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_status ON public.agent_collaboration_group_members USING btree (status);


--
-- Name: ix_agent_collaboration_group_members_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_group_members_tenant_id ON public.agent_collaboration_group_members USING btree (tenant_id);


--
-- Name: ix_agent_collaboration_groups_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_groups_created_at ON public.agent_collaboration_groups USING btree (created_at);


--
-- Name: ix_agent_collaboration_groups_created_by_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_groups_created_by_agent_id ON public.agent_collaboration_groups USING btree (created_by_agent_id);


--
-- Name: ix_agent_collaboration_groups_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_groups_status ON public.agent_collaboration_groups USING btree (status);


--
-- Name: ix_agent_collaboration_groups_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_groups_tenant_id ON public.agent_collaboration_groups USING btree (tenant_id);


--
-- Name: ix_agent_collaboration_groups_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_groups_tenant_status ON public.agent_collaboration_groups USING btree (tenant_id, status);


--
-- Name: ix_agent_collaboration_members_agent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_members_agent_status ON public.agent_collaboration_group_members USING btree (agent_id, status);


--
-- Name: ix_agent_collaboration_members_owner_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_members_owner_status ON public.agent_collaboration_group_members USING btree (agent_owner_user_id, status);


--
-- Name: ix_agent_collaboration_members_tenant_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_collaboration_members_tenant_group ON public.agent_collaboration_group_members USING btree (tenant_id, group_id);


--
-- Name: ix_agent_mcp_server_assignments_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_server_assignments_agent_id ON public.agent_mcp_server_assignments USING btree (agent_id);


--
-- Name: ix_agent_mcp_server_assignments_mcp_server_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_server_assignments_mcp_server_id ON public.agent_mcp_server_assignments USING btree (mcp_server_id);


--
-- Name: ix_agent_mcp_server_assignments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_server_assignments_tenant_id ON public.agent_mcp_server_assignments USING btree (tenant_id);


--
-- Name: ix_agent_mcp_tool_overrides_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_tool_overrides_agent_id ON public.agent_mcp_tool_overrides USING btree (agent_id);


--
-- Name: ix_agent_mcp_tool_overrides_mcp_server_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_tool_overrides_mcp_server_id ON public.agent_mcp_tool_overrides USING btree (mcp_server_id);


--
-- Name: ix_agent_mcp_tool_overrides_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_mcp_tool_overrides_tenant_id ON public.agent_mcp_tool_overrides USING btree (tenant_id);


--
-- Name: ix_agent_permissions_scope_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_permissions_scope_lookup ON public.agent_permissions USING btree (scope_type, scope_id, agent_id);


--
-- Name: ix_agent_permissions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_permissions_tenant_id ON public.agent_permissions USING btree (tenant_id);


--
-- Name: ix_agent_plan_recommendations_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_agent_id ON public.agent_plan_recommendations USING btree (agent_id);


--
-- Name: ix_agent_plan_recommendations_agent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_agent_status ON public.agent_plan_recommendations USING btree (agent_id, status);


--
-- Name: ix_agent_plan_recommendations_recommended_to_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_recommended_to_user_id ON public.agent_plan_recommendations USING btree (recommended_to_user_id);


--
-- Name: ix_agent_plan_recommendations_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_runtime_task_id ON public.agent_plan_recommendations USING btree (runtime_task_id);


--
-- Name: ix_agent_plan_recommendations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_session_id ON public.agent_plan_recommendations USING btree (session_id);


--
-- Name: ix_agent_plan_recommendations_session_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_session_status ON public.agent_plan_recommendations USING btree (session_id, status);


--
-- Name: ix_agent_plan_recommendations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_tenant_id ON public.agent_plan_recommendations USING btree (tenant_id);


--
-- Name: ix_agent_plan_recommendations_user_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_recommendations_user_session ON public.agent_plan_recommendations USING btree (recommended_to_user_id, session_id);


--
-- Name: ix_agent_plan_requests_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_agent_id ON public.agent_plan_requests USING btree (agent_id);


--
-- Name: ix_agent_plan_requests_agent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_agent_status ON public.agent_plan_requests USING btree (agent_id, status);


--
-- Name: ix_agent_plan_requests_requested_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_requested_by_user_id ON public.agent_plan_requests USING btree (requested_by_user_id);


--
-- Name: ix_agent_plan_requests_runtime_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_runtime_task ON public.agent_plan_requests USING btree (runtime_task_id);


--
-- Name: ix_agent_plan_requests_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_runtime_task_id ON public.agent_plan_requests USING btree (runtime_task_id);


--
-- Name: ix_agent_plan_requests_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_session_created ON public.agent_plan_requests USING btree (session_id, created_at);


--
-- Name: ix_agent_plan_requests_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_session_id ON public.agent_plan_requests USING btree (session_id);


--
-- Name: ix_agent_plan_requests_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_tenant_id ON public.agent_plan_requests USING btree (tenant_id);


--
-- Name: ix_agent_plan_requests_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plan_requests_tenant_status ON public.agent_plan_requests USING btree (tenant_id, status);


--
-- Name: ix_agent_plugin_assignments_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plugin_assignments_agent_id ON public.agent_plugin_assignments USING btree (agent_id);


--
-- Name: ix_agent_plugin_assignments_installed_plugin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plugin_assignments_installed_plugin_id ON public.agent_plugin_assignments USING btree (installed_plugin_id);


--
-- Name: ix_agent_plugin_assignments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_plugin_assignments_tenant_id ON public.agent_plugin_assignments USING btree (tenant_id);


--
-- Name: ix_agent_relationships_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_relationships_tenant_id ON public.agent_relationships USING btree (tenant_id);


--
-- Name: ix_agent_schedules_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_schedules_agent_id ON public.agent_schedules USING btree (agent_id);


--
-- Name: ix_agent_schedules_next_run_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_schedules_next_run_at ON public.agent_schedules USING btree (next_run_at);


--
-- Name: ix_agent_schedules_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_schedules_tenant_id ON public.agent_schedules USING btree (tenant_id);


--
-- Name: ix_agent_session_goals_active_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_agent_session_goals_active_session ON public.agent_session_goals USING btree (agent_id, chat_session_id) WHERE ((status)::text = 'active'::text);


--
-- Name: ix_agent_session_goals_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_agent_id ON public.agent_session_goals USING btree (agent_id);


--
-- Name: ix_agent_session_goals_chat_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_chat_session_id ON public.agent_session_goals USING btree (chat_session_id);


--
-- Name: ix_agent_session_goals_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_created_at ON public.agent_session_goals USING btree (created_at);


--
-- Name: ix_agent_session_goals_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_created_by_user_id ON public.agent_session_goals USING btree (created_by_user_id);


--
-- Name: ix_agent_session_goals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_status ON public.agent_session_goals USING btree (status);


--
-- Name: ix_agent_session_goals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_tenant_id ON public.agent_session_goals USING btree (tenant_id);


--
-- Name: ix_agent_session_goals_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_session_goals_tenant_status ON public.agent_session_goals USING btree (tenant_id, status);


--
-- Name: ix_agent_team_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_created_at ON public.agent_team_events USING btree (created_at);


--
-- Name: ix_agent_team_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_event_type ON public.agent_team_events USING btree (event_type);


--
-- Name: ix_agent_team_events_receiver_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_receiver_member_id ON public.agent_team_events USING btree (receiver_member_id);


--
-- Name: ix_agent_team_events_sender_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_sender_member_id ON public.agent_team_events USING btree (sender_member_id);


--
-- Name: ix_agent_team_events_team_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_team_created ON public.agent_team_events USING btree (team_id, created_at);


--
-- Name: ix_agent_team_events_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_team_id ON public.agent_team_events USING btree (team_id);


--
-- Name: ix_agent_team_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_events_type ON public.agent_team_events USING btree (event_type);


--
-- Name: ix_agent_team_members_chat_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_chat_session_id ON public.agent_team_members USING btree (chat_session_id);


--
-- Name: ix_agent_team_members_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_created_at ON public.agent_team_members USING btree (created_at);


--
-- Name: ix_agent_team_members_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_runtime_task_id ON public.agent_team_members USING btree (runtime_task_id);


--
-- Name: ix_agent_team_members_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_session ON public.agent_team_members USING btree (chat_session_id);


--
-- Name: ix_agent_team_members_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_status ON public.agent_team_members USING btree (status);


--
-- Name: ix_agent_team_members_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_team_id ON public.agent_team_members USING btree (team_id);


--
-- Name: ix_agent_team_members_team_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_team_members_team_status ON public.agent_team_members USING btree (team_id, status);


--
-- Name: ix_agent_teams_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_created_at ON public.agent_teams USING btree (created_at);


--
-- Name: ix_agent_teams_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_created_by_user_id ON public.agent_teams USING btree (created_by_user_id);


--
-- Name: ix_agent_teams_lead_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_lead_agent_id ON public.agent_teams USING btree (lead_agent_id);


--
-- Name: ix_agent_teams_lead_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_lead_session ON public.agent_teams USING btree (lead_agent_id, parent_session_id);


--
-- Name: ix_agent_teams_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_parent_session_id ON public.agent_teams USING btree (parent_session_id);


--
-- Name: ix_agent_teams_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_status ON public.agent_teams USING btree (status);


--
-- Name: ix_agent_teams_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_tenant_id ON public.agent_teams USING btree (tenant_id);


--
-- Name: ix_agent_teams_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_teams_tenant_status ON public.agent_teams USING btree (tenant_id, status);


--
-- Name: ix_agent_tools_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_tools_tenant_id ON public.agent_tools USING btree (tenant_id);


--
-- Name: ix_agent_triggers_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_triggers_agent_id ON public.agent_triggers USING btree (agent_id);


--
-- Name: ix_agent_triggers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_triggers_tenant_id ON public.agent_triggers USING btree (tenant_id);


--
-- Name: ix_agents_creator_tenant_active_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agents_creator_tenant_active_created_at ON public.agents USING btree (creator_id, tenant_id, deleted_at, deactivated_at, created_at);


--
-- Name: ix_agents_tenant_active_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agents_tenant_active_created_at ON public.agents USING btree (tenant_id, deleted_at, deactivated_at, agent_class, created_at);


--
-- Name: ix_ai_asset_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_content_hash ON public.ai_asset_records USING btree (content_hash);


--
-- Name: ix_ai_asset_records_active_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_active_revision_id ON public.ai_asset_records USING btree (active_revision_id);


--
-- Name: ix_ai_asset_records_admission_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_admission_state ON public.ai_asset_records USING btree (admission_state);


--
-- Name: ix_ai_asset_records_asset_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_asset_type ON public.ai_asset_records USING btree (asset_type);


--
-- Name: ix_ai_asset_records_lifecycle_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_lifecycle_status ON public.ai_asset_records USING btree (lifecycle_status);


--
-- Name: ix_ai_asset_records_native_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_native_entity_id ON public.ai_asset_records USING btree (native_entity_id);


--
-- Name: ix_ai_asset_records_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_tenant_id ON public.ai_asset_records USING btree (tenant_id);


--
-- Name: ix_ai_asset_records_trust_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_records_trust_state ON public.ai_asset_records USING btree (trust_state);


--
-- Name: ix_ai_asset_tenant_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_tenant_type_status ON public.ai_asset_records USING btree (tenant_id, asset_type, lifecycle_status);


--
-- Name: ix_ai_asset_usage_events_asset_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_asset_created ON public.ai_asset_usage_events USING btree (asset_id, created_at);


--
-- Name: ix_ai_asset_usage_events_asset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_asset_id ON public.ai_asset_usage_events USING btree (asset_id);


--
-- Name: ix_ai_asset_usage_events_asset_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_asset_revision_id ON public.ai_asset_usage_events USING btree (asset_revision_id);


--
-- Name: ix_ai_asset_usage_events_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_runtime_task_id ON public.ai_asset_usage_events USING btree (runtime_task_id);


--
-- Name: ix_ai_asset_usage_events_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_session_id ON public.ai_asset_usage_events USING btree (session_id);


--
-- Name: ix_ai_asset_usage_events_span_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_span_id ON public.ai_asset_usage_events USING btree (span_id);


--
-- Name: ix_ai_asset_usage_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_tenant_id ON public.ai_asset_usage_events USING btree (tenant_id);


--
-- Name: ix_ai_asset_usage_events_tenant_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_tenant_kind ON public.ai_asset_usage_events USING btree (tenant_id, usage_kind);


--
-- Name: ix_ai_asset_usage_events_tool_call_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_tool_call_id ON public.ai_asset_usage_events USING btree (tool_call_id);


--
-- Name: ix_ai_asset_usage_events_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_trace_id ON public.ai_asset_usage_events USING btree (trace_id);


--
-- Name: ix_ai_asset_usage_events_usage_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_asset_usage_events_usage_kind ON public.ai_asset_usage_events USING btree (usage_kind);


--
-- Name: ix_approval_requests_decision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_decision_id ON public.approval_requests USING btree (decision_id);


--
-- Name: ix_approval_requests_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_expires_at ON public.approval_requests USING btree (expires_at);


--
-- Name: ix_approval_requests_input_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_input_hash ON public.approval_requests USING btree (input_hash);


--
-- Name: ix_approval_requests_requested_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_requested_by ON public.approval_requests USING btree (requested_by);


--
-- Name: ix_approval_requests_requested_by_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_requested_by_external_principal_id ON public.approval_requests USING btree (requested_by_external_principal_id);


--
-- Name: ix_approval_requests_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_requests_tenant_id ON public.approval_requests USING btree (tenant_id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_external_principal_id ON public.audit_logs USING btree (external_principal_id);


--
-- Name: ix_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: ix_budget_transition_outbox_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_agent_id ON public.budget_transition_outbox USING btree (agent_id);


--
-- Name: ix_budget_transition_outbox_available_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_available_at ON public.budget_transition_outbox USING btree (available_at);


--
-- Name: ix_budget_transition_outbox_budget_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_budget_event_id ON public.budget_transition_outbox USING btree (budget_event_id);


--
-- Name: ix_budget_transition_outbox_budget_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_budget_run_id ON public.budget_transition_outbox USING btree (budget_run_id);


--
-- Name: ix_budget_transition_outbox_channel_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_channel_config_id ON public.budget_transition_outbox USING btree (channel_config_id);


--
-- Name: ix_budget_transition_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_claim ON public.budget_transition_outbox USING btree (status, available_at, locked_at);


--
-- Name: ix_budget_transition_outbox_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_external_principal_id ON public.budget_transition_outbox USING btree (external_principal_id);


--
-- Name: ix_budget_transition_outbox_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_locked_by ON public.budget_transition_outbox USING btree (locked_by);


--
-- Name: ix_budget_transition_outbox_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_runtime_task_id ON public.budget_transition_outbox USING btree (runtime_task_id);


--
-- Name: ix_budget_transition_outbox_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_session_id ON public.budget_transition_outbox USING btree (session_id);


--
-- Name: ix_budget_transition_outbox_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_status ON public.budget_transition_outbox USING btree (status);


--
-- Name: ix_budget_transition_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_tenant_id ON public.budget_transition_outbox USING btree (tenant_id);


--
-- Name: ix_budget_transition_outbox_transition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_transition ON public.budget_transition_outbox USING btree (transition);


--
-- Name: ix_budget_transition_outbox_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_transition_outbox_user_id ON public.budget_transition_outbox USING btree (user_id);


--
-- Name: ix_capability_factor_reviews_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factor_reviews_created_at ON public.capability_factor_reviews USING btree (created_at);


--
-- Name: ix_capability_factor_reviews_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factor_reviews_decision ON public.capability_factor_reviews USING btree (decision);


--
-- Name: ix_capability_factor_reviews_factor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factor_reviews_factor_id ON public.capability_factor_reviews USING btree (factor_id);


--
-- Name: ix_capability_factor_reviews_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factor_reviews_tenant_id ON public.capability_factor_reviews USING btree (tenant_id);


--
-- Name: ix_capability_factors_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_created_at ON public.capability_factors USING btree (created_at);


--
-- Name: ix_capability_factors_factor_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_factor_kind ON public.capability_factors USING btree (factor_kind);


--
-- Name: ix_capability_factors_originating_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_originating_agent_id ON public.capability_factors USING btree (originating_agent_id);


--
-- Name: ix_capability_factors_originating_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_originating_user_id ON public.capability_factors USING btree (originating_user_id);


--
-- Name: ix_capability_factors_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_status ON public.capability_factors USING btree (status);


--
-- Name: ix_capability_factors_suggested_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_suggested_scope ON public.capability_factors USING btree (suggested_scope);


--
-- Name: ix_capability_factors_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_factors_tenant_id ON public.capability_factors USING btree (tenant_id);


--
-- Name: ix_capability_policies_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_policies_tenant_id ON public.capability_policies USING btree (tenant_id);


--
-- Name: ix_capability_promotion_proposals_approver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_approver_id ON public.capability_promotion_proposals USING btree (approver_id);


--
-- Name: ix_capability_promotion_proposals_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_created_at ON public.capability_promotion_proposals USING btree (created_at);


--
-- Name: ix_capability_promotion_proposals_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_decision ON public.capability_promotion_proposals USING btree (decision);


--
-- Name: ix_capability_promotion_proposals_factor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_factor_id ON public.capability_promotion_proposals USING btree (factor_id);


--
-- Name: ix_capability_promotion_proposals_resulting_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_resulting_snapshot_id ON public.capability_promotion_proposals USING btree (resulting_snapshot_id);


--
-- Name: ix_capability_promotion_proposals_review_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_review_id ON public.capability_promotion_proposals USING btree (review_id);


--
-- Name: ix_capability_promotion_proposals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_capability_promotion_proposals_tenant_id ON public.capability_promotion_proposals USING btree (tenant_id);


--
-- Name: ix_channel_configs_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_configs_agent_id ON public.channel_configs USING btree (agent_id);


--
-- Name: ix_channel_configs_self_identity_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_configs_self_identity_user_id ON public.channel_configs USING btree (self_identity_user_id);


--
-- Name: ix_channel_configs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_configs_tenant_id ON public.channel_configs USING btree (tenant_id);


--
-- Name: ix_channel_delivery_outbox_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_agent_id ON public.channel_delivery_outbox USING btree (agent_id);


--
-- Name: ix_channel_delivery_outbox_available_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_available_at ON public.channel_delivery_outbox USING btree (available_at);


--
-- Name: ix_channel_delivery_outbox_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_channel ON public.channel_delivery_outbox USING btree (channel);


--
-- Name: ix_channel_delivery_outbox_channel_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_channel_config_id ON public.channel_delivery_outbox USING btree (channel_config_id);


--
-- Name: ix_channel_delivery_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_claim ON public.channel_delivery_outbox USING btree (status, available_at, locked_at);


--
-- Name: ix_channel_delivery_outbox_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_external_principal_id ON public.channel_delivery_outbox USING btree (external_principal_id);


--
-- Name: ix_channel_delivery_outbox_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_locked_by ON public.channel_delivery_outbox USING btree (locked_by);


--
-- Name: ix_channel_delivery_outbox_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_runtime_task_id ON public.channel_delivery_outbox USING btree (runtime_task_id);


--
-- Name: ix_channel_delivery_outbox_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_session_id ON public.channel_delivery_outbox USING btree (session_id);


--
-- Name: ix_channel_delivery_outbox_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_status ON public.channel_delivery_outbox USING btree (status);


--
-- Name: ix_channel_delivery_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_tenant_id ON public.channel_delivery_outbox USING btree (tenant_id);


--
-- Name: ix_channel_delivery_outbox_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_delivery_outbox_user_id ON public.channel_delivery_outbox USING btree (user_id);


--
-- Name: ix_channel_ingress_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_claim ON public.channel_ingress_events USING btree (status, available_at, locked_at);


--
-- Name: ix_channel_ingress_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_agent_id ON public.channel_ingress_events USING btree (agent_id);


--
-- Name: ix_channel_ingress_events_available_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_available_at ON public.channel_ingress_events USING btree (available_at);


--
-- Name: ix_channel_ingress_events_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_external_principal_id ON public.channel_ingress_events USING btree (external_principal_id);


--
-- Name: ix_channel_ingress_events_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_locked_by ON public.channel_ingress_events USING btree (locked_by);


--
-- Name: ix_channel_ingress_events_result_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_result_runtime_task_id ON public.channel_ingress_events USING btree (result_runtime_task_id);


--
-- Name: ix_channel_ingress_events_result_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_result_session_id ON public.channel_ingress_events USING btree (result_session_id);


--
-- Name: ix_channel_ingress_events_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_status ON public.channel_ingress_events USING btree (status);


--
-- Name: ix_channel_ingress_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_ingress_events_tenant_id ON public.channel_ingress_events USING btree (tenant_id);


--
-- Name: ix_charter_proposals_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_charter_proposals_agent_id ON public.charter_proposals USING btree (agent_id);


--
-- Name: ix_charter_proposals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_charter_proposals_status ON public.charter_proposals USING btree (status);


--
-- Name: ix_charter_proposals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_charter_proposals_tenant_id ON public.charter_proposals USING btree (tenant_id);


--
-- Name: ix_chat_artifacts_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_agent_id ON public.chat_artifacts USING btree (agent_id);


--
-- Name: ix_chat_artifacts_authority_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_authority_state ON public.chat_artifacts USING btree (authority_state);


--
-- Name: ix_chat_artifacts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_created_at ON public.chat_artifacts USING btree (created_at);


--
-- Name: ix_chat_artifacts_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_message_id ON public.chat_artifacts USING btree (message_id);


--
-- Name: ix_chat_artifacts_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_owner_user_id ON public.chat_artifacts USING btree (owner_user_id);


--
-- Name: ix_chat_artifacts_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_root_session_id ON public.chat_artifacts USING btree (root_session_id);


--
-- Name: ix_chat_artifacts_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_runtime_task_id ON public.chat_artifacts USING btree (runtime_task_id);


--
-- Name: ix_chat_artifacts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_session_id ON public.chat_artifacts USING btree (session_id);


--
-- Name: ix_chat_artifacts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_artifacts_tenant_id ON public.chat_artifacts USING btree (tenant_id);


--
-- Name: ix_chat_messages_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_agent_id ON public.chat_messages USING btree (agent_id);


--
-- Name: ix_chat_messages_conversation_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_conversation_created_at ON public.chat_messages USING btree (conversation_id, created_at);


--
-- Name: ix_chat_messages_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_created_at ON public.chat_messages USING btree (created_at);


--
-- Name: ix_chat_messages_decision_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_decision_trace_id ON public.chat_messages USING btree (decision_trace_id);


--
-- Name: ix_chat_messages_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_external_principal_id ON public.chat_messages USING btree (external_principal_id);


--
-- Name: ix_chat_messages_source_ingress_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_source_ingress_event_id ON public.chat_messages USING btree (source_ingress_event_id);


--
-- Name: ix_chat_messages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_messages_tenant_id ON public.chat_messages USING btree (tenant_id);


--
-- Name: ix_chat_sessions_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_agent_id ON public.chat_sessions USING btree (agent_id);


--
-- Name: ix_chat_sessions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_created_at ON public.chat_sessions USING btree (created_at);


--
-- Name: ix_chat_sessions_dashboard_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_dashboard_recent ON public.chat_sessions USING btree (tenant_id, user_id, listed_surface, last_message_at DESC NULLS LAST, created_at DESC);


--
-- Name: ix_chat_sessions_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_external_principal_id ON public.chat_sessions USING btree (external_principal_id);


--
-- Name: ix_chat_sessions_listed_surface; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_listed_surface ON public.chat_sessions USING btree (listed_surface);


--
-- Name: ix_chat_sessions_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_runtime_task_id ON public.chat_sessions USING btree (runtime_task_id);


--
-- Name: ix_chat_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_tenant_id ON public.chat_sessions USING btree (tenant_id);


--
-- Name: ix_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_user_id ON public.chat_sessions USING btree (user_id);


--
-- Name: ix_chat_transcript_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_agent_id ON public.chat_transcript_events USING btree (agent_id);


--
-- Name: ix_chat_transcript_events_causation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_causation_id ON public.chat_transcript_events USING btree (causation_id);


--
-- Name: ix_chat_transcript_events_command_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_command_id ON public.chat_transcript_events USING btree (command_id);


--
-- Name: ix_chat_transcript_events_correlation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_correlation_id ON public.chat_transcript_events USING btree (correlation_id);


--
-- Name: ix_chat_transcript_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_created_at ON public.chat_transcript_events USING btree (created_at);


--
-- Name: ix_chat_transcript_events_input_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_input_id ON public.chat_transcript_events USING btree (input_id);


--
-- Name: ix_chat_transcript_events_invocation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_invocation_id ON public.chat_transcript_events USING btree (invocation_id);


--
-- Name: ix_chat_transcript_events_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_item_id ON public.chat_transcript_events USING btree (item_id);


--
-- Name: ix_chat_transcript_events_listed_surface; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_listed_surface ON public.chat_transcript_events USING btree (listed_surface);


--
-- Name: ix_chat_transcript_events_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_message_id ON public.chat_transcript_events USING btree (message_id);


--
-- Name: ix_chat_transcript_events_parent_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_parent_event_id ON public.chat_transcript_events USING btree (parent_event_id);


--
-- Name: ix_chat_transcript_events_projection_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_projection_status ON public.chat_transcript_events USING btree (projection_status);


--
-- Name: ix_chat_transcript_events_result_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_result_id ON public.chat_transcript_events USING btree (result_id);


--
-- Name: ix_chat_transcript_events_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_run_id ON public.chat_transcript_events USING btree (run_id);


--
-- Name: ix_chat_transcript_events_session_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_session_sequence ON public.chat_transcript_events USING btree (session_id, sequence);


--
-- Name: ix_chat_transcript_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_tenant_id ON public.chat_transcript_events USING btree (tenant_id);


--
-- Name: ix_chat_transcript_events_turn_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_transcript_events_turn_id ON public.chat_transcript_events USING btree (turn_id);


--
-- Name: ix_company_knowledge_event_stream; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_event_stream ON public.company_knowledge_events USING btree (tenant_id, resource_type, resource_id, created_at);


--
-- Name: ix_company_knowledge_event_tenant_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_event_tenant_sequence ON public.company_knowledge_events USING btree (tenant_id, stream_sequence);


--
-- Name: ix_company_knowledge_event_trace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_event_trace ON public.company_knowledge_events USING btree (tenant_id, trace_id, created_at);


--
-- Name: ix_company_knowledge_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_events_event_type ON public.company_knowledge_events USING btree (event_type);


--
-- Name: ix_company_knowledge_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_events_tenant_id ON public.company_knowledge_events USING btree (tenant_id);


--
-- Name: ix_company_knowledge_evidence_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_content_hash ON public.company_knowledge_evidence USING btree (content_hash);


--
-- Name: ix_company_knowledge_evidence_evidence_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_evidence_kind ON public.company_knowledge_evidence USING btree (evidence_kind);


--
-- Name: ix_company_knowledge_evidence_source_acl_snapshot_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_source_acl_snapshot_hash ON public.company_knowledge_evidence USING btree (source_acl_snapshot_hash);


--
-- Name: ix_company_knowledge_evidence_source_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_source_created ON public.company_knowledge_evidence USING btree (tenant_id, source_id, created_at);


--
-- Name: ix_company_knowledge_evidence_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_source_id ON public.company_knowledge_evidence USING btree (source_id);


--
-- Name: ix_company_knowledge_evidence_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_status ON public.company_knowledge_evidence USING btree (status);


--
-- Name: ix_company_knowledge_evidence_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_evidence_tenant_id ON public.company_knowledge_evidence USING btree (tenant_id);


--
-- Name: ix_company_knowledge_import_job_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_job_claim ON public.company_knowledge_import_jobs USING btree (tenant_id, status, available_at, created_at);


--
-- Name: ix_company_knowledge_import_jobs_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_document_id ON public.company_knowledge_import_jobs USING btree (document_id);


--
-- Name: ix_company_knowledge_import_jobs_evidence_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_evidence_id ON public.company_knowledge_import_jobs USING btree (evidence_id);


--
-- Name: ix_company_knowledge_import_jobs_proposal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_proposal_id ON public.company_knowledge_import_jobs USING btree (proposal_id);


--
-- Name: ix_company_knowledge_import_jobs_source_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_source_contract_id ON public.company_knowledge_import_jobs USING btree (source_contract_id);


--
-- Name: ix_company_knowledge_import_jobs_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_source_id ON public.company_knowledge_import_jobs USING btree (source_id);


--
-- Name: ix_company_knowledge_import_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_status ON public.company_knowledge_import_jobs USING btree (status);


--
-- Name: ix_company_knowledge_import_jobs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_import_jobs_tenant_id ON public.company_knowledge_import_jobs USING btree (tenant_id);


--
-- Name: ix_company_knowledge_outbox_aggregate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_outbox_aggregate_id ON public.company_knowledge_outbox USING btree (aggregate_id);


--
-- Name: ix_company_knowledge_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_outbox_claim ON public.company_knowledge_outbox USING btree (status, available_at, created_at);


--
-- Name: ix_company_knowledge_outbox_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_outbox_status ON public.company_knowledge_outbox USING btree (status);


--
-- Name: ix_company_knowledge_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_outbox_tenant_id ON public.company_knowledge_outbox USING btree (tenant_id);


--
-- Name: ix_company_knowledge_proposal_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposal_queue ON public.company_knowledge_proposals USING btree (tenant_id, status, submitted_at);


--
-- Name: ix_company_knowledge_proposals_materialized_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposals_materialized_document_id ON public.company_knowledge_proposals USING btree (materialized_document_id);


--
-- Name: ix_company_knowledge_proposals_proposed_namespace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposals_proposed_namespace ON public.company_knowledge_proposals USING btree (proposed_namespace);


--
-- Name: ix_company_knowledge_proposals_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposals_source_id ON public.company_knowledge_proposals USING btree (source_id);


--
-- Name: ix_company_knowledge_proposals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposals_status ON public.company_knowledge_proposals USING btree (status);


--
-- Name: ix_company_knowledge_proposals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_proposals_tenant_id ON public.company_knowledge_proposals USING btree (tenant_id);


--
-- Name: ix_company_knowledge_publication_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_knowledge_publication_active ON public.company_knowledge_publications USING btree (tenant_id, logical_resource_key) WHERE ((status)::text = 'active'::text);


--
-- Name: ix_company_knowledge_publication_discovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publication_discovery ON public.company_knowledge_publications USING btree (tenant_id, namespace, status, valid_from, valid_until);


--
-- Name: ix_company_knowledge_publications_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_content_hash ON public.company_knowledge_publications USING btree (content_hash);


--
-- Name: ix_company_knowledge_publications_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_document_id ON public.company_knowledge_publications USING btree (document_id);


--
-- Name: ix_company_knowledge_publications_namespace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_namespace ON public.company_knowledge_publications USING btree (namespace);


--
-- Name: ix_company_knowledge_publications_proposal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_proposal_id ON public.company_knowledge_publications USING btree (proposal_id);


--
-- Name: ix_company_knowledge_publications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_status ON public.company_knowledge_publications USING btree (status);


--
-- Name: ix_company_knowledge_publications_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_publications_tenant_id ON public.company_knowledge_publications USING btree (tenant_id);


--
-- Name: ix_company_knowledge_review_proposal_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_review_proposal_created ON public.company_knowledge_reviews USING btree (tenant_id, proposal_id, created_at);


--
-- Name: ix_company_knowledge_reviews_proposal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_reviews_proposal_id ON public.company_knowledge_reviews USING btree (proposal_id);


--
-- Name: ix_company_knowledge_reviews_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_reviews_tenant_id ON public.company_knowledge_reviews USING btree (tenant_id);


--
-- Name: ix_company_knowledge_source_contract_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_knowledge_source_contract_active ON public.company_knowledge_source_contracts USING btree (tenant_id, stable_source_id) WHERE ((status)::text = 'active'::text);


--
-- Name: ix_company_knowledge_source_contracts_contract_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_source_contracts_contract_hash ON public.company_knowledge_source_contracts USING btree (contract_hash);


--
-- Name: ix_company_knowledge_source_contracts_source_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_source_contracts_source_kind ON public.company_knowledge_source_contracts USING btree (source_kind);


--
-- Name: ix_company_knowledge_source_contracts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_source_contracts_status ON public.company_knowledge_source_contracts USING btree (status);


--
-- Name: ix_company_knowledge_source_contracts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_source_contracts_tenant_id ON public.company_knowledge_source_contracts USING btree (tenant_id);


--
-- Name: ix_company_knowledge_sources_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_content_hash ON public.company_knowledge_sources USING btree (content_hash);


--
-- Name: ix_company_knowledge_sources_namespace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_namespace ON public.company_knowledge_sources USING btree (namespace);


--
-- Name: ix_company_knowledge_sources_source_acl_snapshot_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_source_acl_snapshot_hash ON public.company_knowledge_sources USING btree (source_acl_snapshot_hash);


--
-- Name: ix_company_knowledge_sources_source_contract_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_source_contract_id ON public.company_knowledge_sources USING btree (source_contract_id);


--
-- Name: ix_company_knowledge_sources_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_status ON public.company_knowledge_sources USING btree (status);


--
-- Name: ix_company_knowledge_sources_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_knowledge_sources_tenant_id ON public.company_knowledge_sources USING btree (tenant_id);


--
-- Name: ix_company_ontology_action_types_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_action_types_release_id ON public.company_ontology_action_types USING btree (release_id);


--
-- Name: ix_company_ontology_action_types_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_action_types_tenant_id ON public.company_ontology_action_types USING btree (tenant_id);


--
-- Name: ix_company_ontology_activation_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_ontology_activation_active ON public.company_ontology_activations USING btree (tenant_id, namespace) WHERE ((status)::text = 'active'::text);


--
-- Name: ix_company_ontology_activations_installation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_activations_installation_id ON public.company_ontology_activations USING btree (installation_id);


--
-- Name: ix_company_ontology_activations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_activations_status ON public.company_ontology_activations USING btree (status);


--
-- Name: ix_company_ontology_activations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_activations_tenant_id ON public.company_ontology_activations USING btree (tenant_id);


--
-- Name: ix_company_ontology_assertion_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_assertion_subject ON public.company_ontology_assertions USING btree (tenant_id, subject_object_id, predicate_ref, status);


--
-- Name: ix_company_ontology_assertions_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_assertions_release_id ON public.company_ontology_assertions USING btree (release_id);


--
-- Name: ix_company_ontology_assertions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_assertions_status ON public.company_ontology_assertions USING btree (status);


--
-- Name: ix_company_ontology_assertions_subject_object_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_assertions_subject_object_id ON public.company_ontology_assertions USING btree (subject_object_id);


--
-- Name: ix_company_ontology_assertions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_assertions_tenant_id ON public.company_ontology_assertions USING btree (tenant_id);


--
-- Name: ix_company_ontology_curation_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_curation_recovery ON public.company_ontology_curation_runs USING btree (tenant_id, status, updated_at);


--
-- Name: ix_company_ontology_curation_runs_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_curation_runs_runtime_task_id ON public.company_ontology_curation_runs USING btree (runtime_task_id);


--
-- Name: ix_company_ontology_curation_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_curation_runs_status ON public.company_ontology_curation_runs USING btree (status);


--
-- Name: ix_company_ontology_curation_runs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_curation_runs_tenant_id ON public.company_ontology_curation_runs USING btree (tenant_id);


--
-- Name: ix_company_ontology_event_types_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_event_types_release_id ON public.company_ontology_event_types USING btree (release_id);


--
-- Name: ix_company_ontology_event_types_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_event_types_tenant_id ON public.company_ontology_event_types USING btree (tenant_id);


--
-- Name: ix_company_ontology_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_events_tenant_id ON public.company_ontology_events USING btree (tenant_id);


--
-- Name: ix_company_ontology_evidence_bindings_subject_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_evidence_bindings_subject_id ON public.company_ontology_evidence_bindings USING btree (subject_id);


--
-- Name: ix_company_ontology_evidence_bindings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_evidence_bindings_tenant_id ON public.company_ontology_evidence_bindings USING btree (tenant_id);


--
-- Name: ix_company_ontology_link_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_link_from ON public.company_ontology_links USING btree (tenant_id, from_object_id, link_type_ref, status);


--
-- Name: ix_company_ontology_link_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_link_to ON public.company_ontology_links USING btree (tenant_id, to_object_id, link_type_ref, status);


--
-- Name: ix_company_ontology_link_types_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_link_types_release_id ON public.company_ontology_link_types USING btree (release_id);


--
-- Name: ix_company_ontology_link_types_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_link_types_tenant_id ON public.company_ontology_link_types USING btree (tenant_id);


--
-- Name: ix_company_ontology_links_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_links_tenant_id ON public.company_ontology_links USING btree (tenant_id);


--
-- Name: ix_company_ontology_object_identities_object_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_object_identities_object_id ON public.company_ontology_object_identities USING btree (object_id);


--
-- Name: ix_company_ontology_object_identities_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_object_identities_tenant_id ON public.company_ontology_object_identities USING btree (tenant_id);


--
-- Name: ix_company_ontology_object_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_object_type_status ON public.company_ontology_objects USING btree (tenant_id, object_type_ref, status);


--
-- Name: ix_company_ontology_object_types_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_object_types_release_id ON public.company_ontology_object_types USING btree (release_id);


--
-- Name: ix_company_ontology_object_types_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_object_types_tenant_id ON public.company_ontology_object_types USING btree (tenant_id);


--
-- Name: ix_company_ontology_objects_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_objects_release_id ON public.company_ontology_objects USING btree (release_id);


--
-- Name: ix_company_ontology_objects_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_objects_tenant_id ON public.company_ontology_objects USING btree (tenant_id);


--
-- Name: ix_company_ontology_package_installations_package_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_installations_package_version_id ON public.company_ontology_package_installations USING btree (package_version_id);


--
-- Name: ix_company_ontology_package_installations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_installations_status ON public.company_ontology_package_installations USING btree (status);


--
-- Name: ix_company_ontology_package_installations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_installations_tenant_id ON public.company_ontology_package_installations USING btree (tenant_id);


--
-- Name: ix_company_ontology_package_versions_admission_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_versions_admission_status ON public.company_ontology_package_versions USING btree (admission_status);


--
-- Name: ix_company_ontology_package_versions_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_versions_package_id ON public.company_ontology_package_versions USING btree (package_id);


--
-- Name: ix_company_ontology_package_versions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_package_versions_tenant_id ON public.company_ontology_package_versions USING btree (tenant_id);


--
-- Name: ix_company_ontology_packages_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_packages_status ON public.company_ontology_packages USING btree (status);


--
-- Name: ix_company_ontology_packages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_packages_tenant_id ON public.company_ontology_packages USING btree (tenant_id);


--
-- Name: ix_company_ontology_property_types_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_property_types_release_id ON public.company_ontology_property_types USING btree (release_id);


--
-- Name: ix_company_ontology_property_types_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_property_types_tenant_id ON public.company_ontology_property_types USING btree (tenant_id);


--
-- Name: ix_company_ontology_release_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_ontology_release_active ON public.company_ontology_releases USING btree (tenant_id, namespace) WHERE ((status)::text = 'active'::text);


--
-- Name: ix_company_ontology_release_items_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_release_items_release_id ON public.company_ontology_release_items USING btree (release_id);


--
-- Name: ix_company_ontology_release_items_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_release_items_tenant_id ON public.company_ontology_release_items USING btree (tenant_id);


--
-- Name: ix_company_ontology_releases_release_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_releases_release_hash ON public.company_ontology_releases USING btree (release_hash);


--
-- Name: ix_company_ontology_releases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_releases_status ON public.company_ontology_releases USING btree (status);


--
-- Name: ix_company_ontology_releases_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_releases_tenant_id ON public.company_ontology_releases USING btree (tenant_id);


--
-- Name: ix_company_ontology_rule_definitions_release_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_rule_definitions_release_id ON public.company_ontology_rule_definitions USING btree (release_id);


--
-- Name: ix_company_ontology_rule_definitions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_ontology_rule_definitions_tenant_id ON public.company_ontology_rule_definitions USING btree (tenant_id);


--
-- Name: ix_config_revisions_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_config_revisions_entity_id ON public.config_revisions USING btree (entity_id);


--
-- Name: ix_config_revisions_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_config_revisions_entity_type ON public.config_revisions USING btree (entity_type);


--
-- Name: ix_config_revisions_parent_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_config_revisions_parent_revision_id ON public.config_revisions USING btree (parent_revision_id);


--
-- Name: ix_config_revisions_rollback_of_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_config_revisions_rollback_of_revision_id ON public.config_revisions USING btree (rollback_of_revision_id);


--
-- Name: ix_coordination_checkpoints_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_checkpoints_status ON public.coordination_checkpoints USING btree (status);


--
-- Name: ix_coordination_checkpoints_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_checkpoints_tenant_id ON public.coordination_checkpoints USING btree (tenant_id);


--
-- Name: ix_coordination_leases_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_leases_tenant_id ON public.coordination_leases USING btree (tenant_id);


--
-- Name: ix_coordination_signals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_signals_tenant_id ON public.coordination_signals USING btree (tenant_id);


--
-- Name: ix_coordination_signals_thread_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_signals_thread_id ON public.coordination_signals USING btree (thread_id);


--
-- Name: ix_coordination_signals_to_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_coordination_signals_to_agent_id ON public.coordination_signals USING btree (to_agent_id);


--
-- Name: ix_decision_trace_feedback_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_trace_feedback_created ON public.decision_trace_feedback USING btree (created_at);


--
-- Name: ix_decision_trace_feedback_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_trace_feedback_created_at ON public.decision_trace_feedback USING btree (created_at);


--
-- Name: ix_decision_trace_feedback_decision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_trace_feedback_decision_id ON public.decision_trace_feedback USING btree (decision_id);


--
-- Name: ix_decision_trace_feedback_tenant_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_trace_feedback_tenant_decision ON public.decision_trace_feedback USING btree (tenant_id, decision_id);


--
-- Name: ix_decision_trace_feedback_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_trace_feedback_tenant_id ON public.decision_trace_feedback USING btree (tenant_id);


--
-- Name: ix_decision_traces_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_agent_id ON public.decision_traces USING btree (agent_id);


--
-- Name: ix_decision_traces_checkpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_checkpoint_id ON public.decision_traces USING btree (checkpoint_id);


--
-- Name: ix_decision_traces_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_created_at ON public.decision_traces USING btree (created_at);


--
-- Name: ix_decision_traces_decision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_decision_traces_decision_id ON public.decision_traces USING btree (decision_id);


--
-- Name: ix_decision_traces_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_message_id ON public.decision_traces USING btree (message_id);


--
-- Name: ix_decision_traces_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_session_id ON public.decision_traces USING btree (session_id);


--
-- Name: ix_decision_traces_tenant_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_tenant_agent ON public.decision_traces USING btree (tenant_id, agent_id);


--
-- Name: ix_decision_traces_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_tenant_id ON public.decision_traces USING btree (tenant_id);


--
-- Name: ix_decision_traces_tenant_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_tenant_session ON public.decision_traces USING btree (tenant_id, session_id);


--
-- Name: ix_decision_traces_tool_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_tool_created ON public.decision_traces USING btree (tool_name, created_at);


--
-- Name: ix_decision_traces_tool_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_tool_name ON public.decision_traces USING btree (tool_name);


--
-- Name: ix_decision_traces_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decision_traces_user_id ON public.decision_traces USING btree (user_id);


--
-- Name: ix_departments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_departments_tenant_id ON public.departments USING btree (tenant_id);


--
-- Name: ix_enterprise_info_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_enterprise_info_tenant_id ON public.enterprise_info USING btree (tenant_id);


--
-- Name: ix_external_capability_reviews_admission_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_admission_class ON public.external_capability_reviews USING btree (admission_class);


--
-- Name: ix_external_capability_reviews_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_created_by_user_id ON public.external_capability_reviews USING btree (created_by_user_id);


--
-- Name: ix_external_capability_reviews_normalized_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_normalized_name ON public.external_capability_reviews USING btree (normalized_name);


--
-- Name: ix_external_capability_reviews_source_format; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_source_format ON public.external_capability_reviews USING btree (source_format);


--
-- Name: ix_external_capability_reviews_source_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_source_hash ON public.external_capability_reviews USING btree (source_hash);


--
-- Name: ix_external_capability_reviews_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_status ON public.external_capability_reviews USING btree (status);


--
-- Name: ix_external_capability_reviews_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_reviews_tenant_id ON public.external_capability_reviews USING btree (tenant_id);


--
-- Name: ix_external_capability_snapshots_admission_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_admission_class ON public.external_capability_snapshots USING btree (admission_class);


--
-- Name: ix_external_capability_snapshots_approved_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_approved_by_user_id ON public.external_capability_snapshots USING btree (approved_by_user_id);


--
-- Name: ix_external_capability_snapshots_normalized_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_normalized_name ON public.external_capability_snapshots USING btree (normalized_name);


--
-- Name: ix_external_capability_snapshots_review_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_review_id ON public.external_capability_snapshots USING btree (review_id);


--
-- Name: ix_external_capability_snapshots_source_format; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_source_format ON public.external_capability_snapshots USING btree (source_format);


--
-- Name: ix_external_capability_snapshots_source_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_source_hash ON public.external_capability_snapshots USING btree (source_hash);


--
-- Name: ix_external_capability_snapshots_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_status ON public.external_capability_snapshots USING btree (status);


--
-- Name: ix_external_capability_snapshots_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_capability_snapshots_tenant_id ON public.external_capability_snapshots USING btree (tenant_id);


--
-- Name: ix_external_extension_activation_agent_unique_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_external_extension_activation_agent_unique_active ON public.external_extension_activations USING btree (tenant_id, agent_id, snapshot_id) WHERE (((activation_scope)::text = 'agent'::text) AND ((status)::text = 'active'::text));


--
-- Name: ix_external_extension_activation_session_unique_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_external_extension_activation_session_unique_active ON public.external_extension_activations USING btree (tenant_id, agent_id, snapshot_id, session_id) WHERE (((activation_scope)::text = 'session'::text) AND ((status)::text = 'active'::text));


--
-- Name: ix_external_extension_activations_activated_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_activated_by_user_id ON public.external_extension_activations USING btree (activated_by_user_id);


--
-- Name: ix_external_extension_activations_activation_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_activation_scope ON public.external_extension_activations USING btree (activation_scope);


--
-- Name: ix_external_extension_activations_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_agent_id ON public.external_extension_activations USING btree (agent_id);


--
-- Name: ix_external_extension_activations_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_expires_at ON public.external_extension_activations USING btree (expires_at);


--
-- Name: ix_external_extension_activations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_session_id ON public.external_extension_activations USING btree (session_id);


--
-- Name: ix_external_extension_activations_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_snapshot_id ON public.external_extension_activations USING btree (snapshot_id);


--
-- Name: ix_external_extension_activations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_status ON public.external_extension_activations USING btree (status);


--
-- Name: ix_external_extension_activations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_activations_tenant_id ON public.external_extension_activations USING btree (tenant_id);


--
-- Name: ix_external_extension_catalog_entries_component_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_component_name ON public.external_extension_catalog_entries USING btree (component_name);


--
-- Name: ix_external_extension_catalog_entries_component_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_component_type ON public.external_extension_catalog_entries USING btree (component_type);


--
-- Name: ix_external_extension_catalog_entries_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_policy ON public.external_extension_catalog_entries USING btree (policy);


--
-- Name: ix_external_extension_catalog_entries_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_snapshot_id ON public.external_extension_catalog_entries USING btree (snapshot_id);


--
-- Name: ix_external_extension_catalog_entries_source_format; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_source_format ON public.external_extension_catalog_entries USING btree (source_format);


--
-- Name: ix_external_extension_catalog_entries_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_status ON public.external_extension_catalog_entries USING btree (status);


--
-- Name: ix_external_extension_catalog_entries_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_catalog_entries_tenant_id ON public.external_extension_catalog_entries USING btree (tenant_id);


--
-- Name: ix_external_extension_components_component_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_component_name ON public.external_extension_components USING btree (component_name);


--
-- Name: ix_external_extension_components_component_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_component_type ON public.external_extension_components USING btree (component_type);


--
-- Name: ix_external_extension_components_content_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_content_sha256 ON public.external_extension_components USING btree (content_sha256);


--
-- Name: ix_external_extension_components_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_snapshot_id ON public.external_extension_components USING btree (snapshot_id);


--
-- Name: ix_external_extension_components_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_status ON public.external_extension_components USING btree (status);


--
-- Name: ix_external_extension_components_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_components_tenant_id ON public.external_extension_components USING btree (tenant_id);


--
-- Name: ix_external_extension_hook_registrations_component_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_hook_registrations_component_id ON public.external_extension_hook_registrations USING btree (component_id);


--
-- Name: ix_external_extension_hook_registrations_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_hook_registrations_event ON public.external_extension_hook_registrations USING btree (event);


--
-- Name: ix_external_extension_hook_registrations_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_hook_registrations_snapshot_id ON public.external_extension_hook_registrations USING btree (snapshot_id);


--
-- Name: ix_external_extension_hook_registrations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_hook_registrations_status ON public.external_extension_hook_registrations USING btree (status);


--
-- Name: ix_external_extension_hook_registrations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_extension_hook_registrations_tenant_id ON public.external_extension_hook_registrations USING btree (tenant_id);


--
-- Name: ix_external_identities_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_identities_provider_id ON public.external_identities USING btree (provider_id);


--
-- Name: ix_external_identities_provider_open_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_identities_provider_open_id ON public.external_identities USING btree (provider_open_id);


--
-- Name: ix_external_identities_provider_union_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_identities_provider_union_id ON public.external_identities USING btree (provider_union_id);


--
-- Name: ix_external_identities_provider_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_identities_provider_user_id ON public.external_identities USING btree (provider_user_id);


--
-- Name: ix_external_identities_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_identities_user_id ON public.external_identities USING btree (user_id);


--
-- Name: ix_external_marketplace_entries_review_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_review_id ON public.external_marketplace_entries USING btree (review_id);


--
-- Name: ix_external_marketplace_entries_snapshot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_snapshot_id ON public.external_marketplace_entries USING btree (snapshot_id);


--
-- Name: ix_external_marketplace_entries_source_format; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_source_format ON public.external_marketplace_entries USING btree (source_format);


--
-- Name: ix_external_marketplace_entries_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_source_id ON public.external_marketplace_entries USING btree (source_id);


--
-- Name: ix_external_marketplace_entries_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_status ON public.external_marketplace_entries USING btree (status);


--
-- Name: ix_external_marketplace_entries_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_entries_tenant_id ON public.external_marketplace_entries USING btree (tenant_id);


--
-- Name: ix_external_marketplace_sources_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_sources_created_by_user_id ON public.external_marketplace_sources USING btree (created_by_user_id);


--
-- Name: ix_external_marketplace_sources_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_sources_source_type ON public.external_marketplace_sources USING btree (source_type);


--
-- Name: ix_external_marketplace_sources_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_sources_status ON public.external_marketplace_sources USING btree (status);


--
-- Name: ix_external_marketplace_sources_sync_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_sources_sync_status ON public.external_marketplace_sources USING btree (sync_status);


--
-- Name: ix_external_marketplace_sources_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_marketplace_sources_tenant_id ON public.external_marketplace_sources USING btree (tenant_id);


--
-- Name: ix_external_principal_binding_events_actor_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principal_binding_events_actor_user_id ON public.external_principal_binding_events USING btree (actor_user_id);


--
-- Name: ix_external_principal_binding_events_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principal_binding_events_external_principal_id ON public.external_principal_binding_events USING btree (external_principal_id);


--
-- Name: ix_external_principal_binding_events_principal_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principal_binding_events_principal_created ON public.external_principal_binding_events USING btree (external_principal_id, created_at);


--
-- Name: ix_external_principal_binding_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principal_binding_events_tenant_id ON public.external_principal_binding_events USING btree (tenant_id);


--
-- Name: ix_external_principals_channel_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_channel_config_id ON public.external_principals USING btree (channel_config_id);


--
-- Name: ix_external_principals_linked_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_linked_user_id ON public.external_principals USING btree (linked_user_id);


--
-- Name: ix_external_principals_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_provider ON public.external_principals USING btree (provider);


--
-- Name: ix_external_principals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_status ON public.external_principals USING btree (status);


--
-- Name: ix_external_principals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_tenant_id ON public.external_principals USING btree (tenant_id);


--
-- Name: ix_external_principals_tenant_provider_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_external_principals_tenant_provider_status ON public.external_principals USING btree (tenant_id, provider, status);


--
-- Name: ix_feature_flags_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_feature_flags_key ON public.feature_flags USING btree (key);


--
-- Name: ix_guard_policies_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_guard_policies_tenant_id ON public.guard_policies USING btree (tenant_id);


--
-- Name: ix_hr_creation_drafts_created_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_created_agent_id ON public.hr_creation_drafts USING btree (created_agent_id);


--
-- Name: ix_hr_creation_drafts_hr_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_hr_agent_id ON public.hr_creation_drafts USING btree (hr_agent_id);


--
-- Name: ix_hr_creation_drafts_hr_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_hr_status ON public.hr_creation_drafts USING btree (hr_agent_id, status);


--
-- Name: ix_hr_creation_drafts_requested_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_requested_by_user_id ON public.hr_creation_drafts USING btree (requested_by_user_id);


--
-- Name: ix_hr_creation_drafts_requester_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_requester_status ON public.hr_creation_drafts USING btree (requested_by_user_id, status);


--
-- Name: ix_hr_creation_drafts_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_session_created ON public.hr_creation_drafts USING btree (session_id, created_at);


--
-- Name: ix_hr_creation_drafts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_session_id ON public.hr_creation_drafts USING btree (session_id);


--
-- Name: ix_hr_creation_drafts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_creation_drafts_tenant_id ON public.hr_creation_drafts USING btree (tenant_id);


--
-- Name: ix_hr_provisioning_steps_draft_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_provisioning_steps_draft_order ON public.hr_provisioning_steps USING btree (draft_id, order_index);


--
-- Name: ix_hr_provisioning_steps_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hr_provisioning_steps_tenant_status ON public.hr_provisioning_steps USING btree (tenant_id, status);


--
-- Name: ix_identity_providers_provider_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_identity_providers_provider_type ON public.identity_providers USING btree (provider_type);


--
-- Name: ix_identity_providers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_identity_providers_tenant_id ON public.identity_providers USING btree (tenant_id);


--
-- Name: ix_invitation_codes_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_invitation_codes_code ON public.invitation_codes USING btree (code);


--
-- Name: ix_invitation_codes_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invitation_codes_tenant_id ON public.invitation_codes USING btree (tenant_id);


--
-- Name: ix_invocation_spans_agent_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_agent_started ON public.invocation_spans USING btree (agent_id, started_at);


--
-- Name: ix_invocation_spans_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_created_at ON public.invocation_spans USING btree (created_at);


--
-- Name: ix_invocation_spans_decision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_decision_id ON public.invocation_spans USING btree (decision_id);


--
-- Name: ix_invocation_spans_execution_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_execution_identity ON public.invocation_spans USING btree (tenant_id, execution_identity_type, execution_identity_id);


--
-- Name: ix_invocation_spans_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_idempotency_key ON public.invocation_spans USING btree (idempotency_key);


--
-- Name: ix_invocation_spans_parent_trace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_parent_trace ON public.invocation_spans USING btree (tenant_id, parent_trace_id);


--
-- Name: ix_invocation_spans_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_request_id ON public.invocation_spans USING btree (request_id);


--
-- Name: ix_invocation_spans_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_runtime_task_id ON public.invocation_spans USING btree (runtime_task_id);


--
-- Name: ix_invocation_spans_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_session_id ON public.invocation_spans USING btree (session_id);


--
-- Name: ix_invocation_spans_span_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_span_type ON public.invocation_spans USING btree (span_type);


--
-- Name: ix_invocation_spans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_status ON public.invocation_spans USING btree (status);


--
-- Name: ix_invocation_spans_tenant_trace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invocation_spans_tenant_trace ON public.invocation_spans USING btree (tenant_id, trace_id);


--
-- Name: ix_knowledge_assertions_object_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_object_entity_id ON public.knowledge_assertions USING btree (object_entity_id);


--
-- Name: ix_knowledge_assertions_predicate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_predicate ON public.knowledge_assertions USING btree (predicate);


--
-- Name: ix_knowledge_assertions_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_scope_id ON public.knowledge_assertions USING btree (scope_id);


--
-- Name: ix_knowledge_assertions_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_scope_type ON public.knowledge_assertions USING btree (scope_type);


--
-- Name: ix_knowledge_assertions_source_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_source_document_id ON public.knowledge_assertions USING btree (source_document_id);


--
-- Name: ix_knowledge_assertions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_status ON public.knowledge_assertions USING btree (status);


--
-- Name: ix_knowledge_assertions_subject_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_subject_entity_id ON public.knowledge_assertions USING btree (subject_entity_id);


--
-- Name: ix_knowledge_assertions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_assertions_tenant_id ON public.knowledge_assertions USING btree (tenant_id);


--
-- Name: ix_knowledge_documents_agent_searchable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_agent_searchable ON public.knowledge_documents USING btree (agent_searchable);


--
-- Name: ix_knowledge_documents_artifact_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_artifact_hash ON public.knowledge_documents USING btree (artifact_hash);


--
-- Name: ix_knowledge_documents_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_created_by_user_id ON public.knowledge_documents USING btree (created_by_user_id);


--
-- Name: ix_knowledge_documents_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_owner_user_id ON public.knowledge_documents USING btree (owner_user_id);


--
-- Name: ix_knowledge_documents_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_scope_id ON public.knowledge_documents USING btree (scope_id);


--
-- Name: ix_knowledge_documents_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_scope_type ON public.knowledge_documents USING btree (scope_type);


--
-- Name: ix_knowledge_documents_sensitivity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_sensitivity ON public.knowledge_documents USING btree (sensitivity);


--
-- Name: ix_knowledge_documents_source_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_source_kind ON public.knowledge_documents USING btree (source_kind);


--
-- Name: ix_knowledge_documents_source_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_source_sha256 ON public.knowledge_documents USING btree (source_sha256);


--
-- Name: ix_knowledge_documents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_status ON public.knowledge_documents USING btree (status);


--
-- Name: ix_knowledge_documents_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_documents_tenant_id ON public.knowledge_documents USING btree (tenant_id);


--
-- Name: ix_knowledge_entities_canonical_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_canonical_name ON public.knowledge_entities USING btree (canonical_name);


--
-- Name: ix_knowledge_entities_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_entity_type ON public.knowledge_entities USING btree (entity_type);


--
-- Name: ix_knowledge_entities_merged_into_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_merged_into_entity_id ON public.knowledge_entities USING btree (merged_into_entity_id);


--
-- Name: ix_knowledge_entities_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_scope_id ON public.knowledge_entities USING btree (scope_id);


--
-- Name: ix_knowledge_entities_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_scope_type ON public.knowledge_entities USING btree (scope_type);


--
-- Name: ix_knowledge_entities_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entities_tenant_id ON public.knowledge_entities USING btree (tenant_id);


--
-- Name: ix_knowledge_grants_binding_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_binding_key ON public.knowledge_grants USING btree (binding_key);


--
-- Name: ix_knowledge_grants_created_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_created_by_user_id ON public.knowledge_grants USING btree (created_by_user_id);


--
-- Name: ix_knowledge_grants_delegation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_delegation_id ON public.knowledge_grants USING btree (delegation_id);


--
-- Name: ix_knowledge_grants_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_document_id ON public.knowledge_grants USING btree (document_id);


--
-- Name: ix_knowledge_grants_grantee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_grantee_id ON public.knowledge_grants USING btree (grantee_id);


--
-- Name: ix_knowledge_grants_grantee_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_grantee_type ON public.knowledge_grants USING btree (grantee_type);


--
-- Name: ix_knowledge_grants_permission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_permission ON public.knowledge_grants USING btree (permission);


--
-- Name: ix_knowledge_grants_purpose; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_purpose ON public.knowledge_grants USING btree (purpose);


--
-- Name: ix_knowledge_grants_requester_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_requester_user_id ON public.knowledge_grants USING btree (requester_user_id);


--
-- Name: ix_knowledge_grants_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_resource_id ON public.knowledge_grants USING btree (resource_id);


--
-- Name: ix_knowledge_grants_resource_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_resource_type ON public.knowledge_grants USING btree (resource_type);


--
-- Name: ix_knowledge_grants_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_revoked_at ON public.knowledge_grants USING btree (revoked_at);


--
-- Name: ix_knowledge_grants_revoked_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_revoked_by_user_id ON public.knowledge_grants USING btree (revoked_by_user_id);


--
-- Name: ix_knowledge_grants_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_scope_id ON public.knowledge_grants USING btree (scope_id);


--
-- Name: ix_knowledge_grants_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_scope_type ON public.knowledge_grants USING btree (scope_type);


--
-- Name: ix_knowledge_grants_sensitivity_ceiling; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_sensitivity_ceiling ON public.knowledge_grants USING btree (sensitivity_ceiling);


--
-- Name: ix_knowledge_grants_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_session_id ON public.knowledge_grants USING btree (session_id);


--
-- Name: ix_knowledge_grants_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_grants_tenant_id ON public.knowledge_grants USING btree (tenant_id);


--
-- Name: ix_knowledge_index_jobs_artifact_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_artifact_hash ON public.knowledge_index_jobs USING btree (artifact_hash);


--
-- Name: ix_knowledge_index_jobs_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_document_id ON public.knowledge_index_jobs USING btree (document_id);


--
-- Name: ix_knowledge_index_jobs_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_scope_id ON public.knowledge_index_jobs USING btree (scope_id);


--
-- Name: ix_knowledge_index_jobs_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_scope_type ON public.knowledge_index_jobs USING btree (scope_type);


--
-- Name: ix_knowledge_index_jobs_stage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_stage ON public.knowledge_index_jobs USING btree (stage);


--
-- Name: ix_knowledge_index_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_status ON public.knowledge_index_jobs USING btree (status);


--
-- Name: ix_knowledge_index_jobs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_index_jobs_tenant_id ON public.knowledge_index_jobs USING btree (tenant_id);


--
-- Name: ix_knowledge_links_from_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_from_id ON public.knowledge_links USING btree (from_id);


--
-- Name: ix_knowledge_links_relation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_relation ON public.knowledge_links USING btree (relation);


--
-- Name: ix_knowledge_links_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_scope_id ON public.knowledge_links USING btree (scope_id);


--
-- Name: ix_knowledge_links_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_scope_type ON public.knowledge_links USING btree (scope_type);


--
-- Name: ix_knowledge_links_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_tenant_id ON public.knowledge_links USING btree (tenant_id);


--
-- Name: ix_knowledge_links_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_links_to_id ON public.knowledge_links USING btree (to_id);


--
-- Name: ix_knowledge_segments_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_segments_document_id ON public.knowledge_segments USING btree (document_id);


--
-- Name: ix_knowledge_segments_scope_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_segments_scope_id ON public.knowledge_segments USING btree (scope_id);


--
-- Name: ix_knowledge_segments_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_segments_scope_type ON public.knowledge_segments USING btree (scope_type);


--
-- Name: ix_knowledge_segments_segment_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_segments_segment_hash ON public.knowledge_segments USING btree (segment_hash);


--
-- Name: ix_knowledge_segments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_segments_tenant_id ON public.knowledge_segments USING btree (tenant_id);


--
-- Name: ix_llm_models_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_models_tenant_id ON public.llm_models USING btree (tenant_id);


--
-- Name: ix_local_agent_bridge_connections_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_connections_agent_id ON public.local_agent_bridge_connections USING btree (agent_id);


--
-- Name: ix_local_agent_bridge_connections_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_connections_tenant_id ON public.local_agent_bridge_connections USING btree (tenant_id);


--
-- Name: ix_local_agent_bridge_connections_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_connections_user_id ON public.local_agent_bridge_connections USING btree (user_id);


--
-- Name: ix_local_agent_bridge_pairing_sessions_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_pairing_sessions_agent_id ON public.local_agent_bridge_pairing_sessions USING btree (agent_id);


--
-- Name: ix_local_agent_bridge_pairing_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_pairing_sessions_tenant_id ON public.local_agent_bridge_pairing_sessions USING btree (tenant_id);


--
-- Name: ix_local_agent_bridge_pairing_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_bridge_pairing_sessions_user_id ON public.local_agent_bridge_pairing_sessions USING btree (user_id);


--
-- Name: ix_local_agent_capability_snapshot_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshot_active ON public.local_agent_capability_snapshots USING btree (channel_id, expires_at, revoked_at);


--
-- Name: ix_local_agent_capability_snapshots_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshots_channel_id ON public.local_agent_capability_snapshots USING btree (channel_id);


--
-- Name: ix_local_agent_capability_snapshots_connection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshots_connection_id ON public.local_agent_capability_snapshots USING btree (connection_id);


--
-- Name: ix_local_agent_capability_snapshots_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshots_expires_at ON public.local_agent_capability_snapshots USING btree (expires_at);


--
-- Name: ix_local_agent_capability_snapshots_subject_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshots_subject_agent_id ON public.local_agent_capability_snapshots USING btree (subject_agent_id);


--
-- Name: ix_local_agent_capability_snapshots_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_capability_snapshots_tenant_id ON public.local_agent_capability_snapshots USING btree (tenant_id);


--
-- Name: ix_local_agent_channel_events_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_events_message ON public.local_agent_channel_events USING btree (message_id);


--
-- Name: ix_local_agent_channel_events_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_events_session_created ON public.local_agent_channel_events USING btree (session_id, created_at);


--
-- Name: ix_local_agent_channel_events_session_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_events_session_sequence ON public.local_agent_channel_events USING btree (session_id, sequence);


--
-- Name: ix_local_agent_channel_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_events_tenant_id ON public.local_agent_channel_events USING btree (tenant_id);


--
-- Name: ix_local_agent_channel_messages_approval_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_approval_id ON public.local_agent_channel_messages USING btree (approval_id);


--
-- Name: ix_local_agent_channel_messages_capability_snapshot_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_capability_snapshot_hash ON public.local_agent_channel_messages USING btree (capability_snapshot_hash);


--
-- Name: ix_local_agent_channel_messages_replay_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_replay_key ON public.local_agent_channel_messages USING btree (replay_key);


--
-- Name: ix_local_agent_channel_messages_request_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_request_hash ON public.local_agent_channel_messages USING btree (request_hash);


--
-- Name: ix_local_agent_channel_messages_session_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_session_status ON public.local_agent_channel_messages USING btree (session_id, status);


--
-- Name: ix_local_agent_channel_messages_source_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_source_agent ON public.local_agent_channel_messages USING btree (source_agent_id);


--
-- Name: ix_local_agent_channel_messages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_tenant_id ON public.local_agent_channel_messages USING btree (tenant_id);


--
-- Name: ix_local_agent_channel_messages_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_messages_user_status ON public.local_agent_channel_messages USING btree (owner_user_id, status);


--
-- Name: ix_local_agent_channel_sessions_chat_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_sessions_chat_session ON public.local_agent_channel_sessions USING btree (chat_session_id);


--
-- Name: ix_local_agent_channel_sessions_source_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_sessions_source_agent ON public.local_agent_channel_sessions USING btree (source_agent_id);


--
-- Name: ix_local_agent_channel_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_sessions_tenant_id ON public.local_agent_channel_sessions USING btree (tenant_id);


--
-- Name: ix_local_agent_channel_sessions_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_sessions_user_status ON public.local_agent_channel_sessions USING btree (owner_user_id, status);


--
-- Name: ix_local_agent_channel_ws_tickets_connection; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_ws_tickets_connection ON public.local_agent_channel_ws_tickets USING btree (connection_id);


--
-- Name: ix_local_agent_channel_ws_tickets_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_ws_tickets_expires ON public.local_agent_channel_ws_tickets USING btree (expires_at);


--
-- Name: ix_local_agent_channel_ws_tickets_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channel_ws_tickets_tenant_id ON public.local_agent_channel_ws_tickets USING btree (tenant_id);


--
-- Name: ix_local_agent_channels_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channels_tenant_id ON public.local_agent_channels USING btree (tenant_id);


--
-- Name: ix_local_agent_channels_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_agent_channels_user_status ON public.local_agent_channels USING btree (owner_user_id, status);


--
-- Name: ix_local_bridge_connections_agent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_connections_agent_status ON public.local_agent_bridge_connections USING btree (agent_id, status);


--
-- Name: ix_local_bridge_connections_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_connections_tenant_id ON public.local_agent_bridge_connections USING btree (tenant_id);


--
-- Name: ix_local_bridge_connections_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_connections_user_id ON public.local_agent_bridge_connections USING btree (user_id);


--
-- Name: ix_local_bridge_connections_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_connections_user_status ON public.local_agent_bridge_connections USING btree (user_id, status);


--
-- Name: ix_local_bridge_pairing_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_pairing_agent_id ON public.local_agent_bridge_pairing_sessions USING btree (agent_id);


--
-- Name: ix_local_bridge_pairing_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_pairing_status ON public.local_agent_bridge_pairing_sessions USING btree (status);


--
-- Name: ix_local_bridge_pairing_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_local_bridge_pairing_tenant_id ON public.local_agent_bridge_pairing_sessions USING btree (tenant_id);


--
-- Name: ix_mcp_server_tools_mcp_server_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mcp_server_tools_mcp_server_id ON public.mcp_server_tools USING btree (mcp_server_id);


--
-- Name: ix_mcp_server_tools_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mcp_server_tools_tenant_id ON public.mcp_server_tools USING btree (tenant_id);


--
-- Name: ix_mcp_server_tools_tool_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mcp_server_tools_tool_id ON public.mcp_server_tools USING btree (tool_id);


--
-- Name: ix_mcp_servers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mcp_servers_tenant_id ON public.mcp_servers USING btree (tenant_id);


--
-- Name: ix_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_org_departments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_org_departments_tenant_id ON public.org_departments USING btree (tenant_id);


--
-- Name: ix_org_members_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_org_members_external_id ON public.org_members USING btree (external_id);


--
-- Name: ix_org_members_open_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_org_members_open_id ON public.org_members USING btree (open_id);


--
-- Name: ix_org_members_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_org_members_tenant_id ON public.org_members USING btree (tenant_id);


--
-- Name: ix_org_members_unionid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_org_members_unionid ON public.org_members USING btree (unionid);


--
-- Name: ix_participants_ref_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_participants_ref_id ON public.participants USING btree (ref_id);


--
-- Name: ix_pending_reply_contexts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pending_reply_contexts_tenant_id ON public.pending_reply_contexts USING btree (tenant_id);


--
-- Name: ix_pending_reply_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pending_reply_expires ON public.pending_reply_contexts USING btree (expires_at);


--
-- Name: ix_pending_reply_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pending_reply_lookup ON public.pending_reply_contexts USING btree (agent_id, recipient_identity, status);


--
-- Name: ix_personal_kb_proposals_agent_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_kb_proposals_agent_created ON public.personal_knowledge_proposals USING btree (proposed_by_agent_id, created_at);


--
-- Name: ix_personal_kb_proposals_owner_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_kb_proposals_owner_status ON public.personal_knowledge_proposals USING btree (owner_user_id, status);


--
-- Name: ix_personal_knowledge_proposals_baseline_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_baseline_document_id ON public.personal_knowledge_proposals USING btree (baseline_document_id);


--
-- Name: ix_personal_knowledge_proposals_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_content_hash ON public.personal_knowledge_proposals USING btree (content_hash);


--
-- Name: ix_personal_knowledge_proposals_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_dedupe_key ON public.personal_knowledge_proposals USING btree (dedupe_key);


--
-- Name: ix_personal_knowledge_proposals_delegated_by_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_delegated_by_agent_id ON public.personal_knowledge_proposals USING btree (delegated_by_agent_id);


--
-- Name: ix_personal_knowledge_proposals_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_document_id ON public.personal_knowledge_proposals USING btree (document_id);


--
-- Name: ix_personal_knowledge_proposals_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_owner_user_id ON public.personal_knowledge_proposals USING btree (owner_user_id);


--
-- Name: ix_personal_knowledge_proposals_proposed_by_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_proposed_by_agent_id ON public.personal_knowledge_proposals USING btree (proposed_by_agent_id);


--
-- Name: ix_personal_knowledge_proposals_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_revision_id ON public.personal_knowledge_proposals USING btree (revision_id);


--
-- Name: ix_personal_knowledge_proposals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_status ON public.personal_knowledge_proposals USING btree (status);


--
-- Name: ix_personal_knowledge_proposals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_personal_knowledge_proposals_tenant_id ON public.personal_knowledge_proposals USING btree (tenant_id);


--
-- Name: ix_plaza_comments_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plaza_comments_post_id ON public.plaza_comments USING btree (post_id);


--
-- Name: ix_plaza_likes_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plaza_likes_post_id ON public.plaza_likes USING btree (post_id);


--
-- Name: ix_plaza_posts_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plaza_posts_author_id ON public.plaza_posts USING btree (author_id);


--
-- Name: ix_plaza_posts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plaza_posts_created_at ON public.plaza_posts USING btree (created_at);


--
-- Name: ix_plugin_dependency_edges_dependency_plugin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plugin_dependency_edges_dependency_plugin_id ON public.plugin_dependency_edges USING btree (dependency_plugin_id);


--
-- Name: ix_plugin_dependency_edges_installed_plugin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plugin_dependency_edges_installed_plugin_id ON public.plugin_dependency_edges USING btree (installed_plugin_id);


--
-- Name: ix_plugin_dependency_edges_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plugin_dependency_edges_tenant_id ON public.plugin_dependency_edges USING btree (tenant_id);


--
-- Name: ix_plugin_hook_registrations_installed_plugin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plugin_hook_registrations_installed_plugin_id ON public.plugin_hook_registrations USING btree (installed_plugin_id);


--
-- Name: ix_plugin_hook_registrations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plugin_hook_registrations_tenant_id ON public.plugin_hook_registrations USING btree (tenant_id);


--
-- Name: ix_refresh_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_refresh_tokens_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_resource_permissions_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_permissions_expires_at ON public.resource_permissions USING btree (expires_at);


--
-- Name: ix_resource_permissions_principal_key_resource_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_permissions_principal_key_resource_key ON public.resource_permissions USING btree (tenant_id, principal_type, principal_key, resource_type, resource_key);


--
-- Name: ix_resource_permissions_principal_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_permissions_principal_resource ON public.resource_permissions USING btree (tenant_id, principal_type, principal_id, resource_type, resource_id);


--
-- Name: ix_resource_permissions_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_resource_permissions_revoked_at ON public.resource_permissions USING btree (revoked_at);


--
-- Name: ix_runtime_budget_events_budget_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_events_budget_run_id ON public.runtime_budget_events USING btree (budget_run_id);


--
-- Name: ix_runtime_budget_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_events_event_type ON public.runtime_budget_events USING btree (event_type);


--
-- Name: ix_runtime_budget_events_reservation_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_events_reservation_key ON public.runtime_budget_events USING btree (reservation_key);


--
-- Name: ix_runtime_budget_events_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_events_runtime_task_id ON public.runtime_budget_events USING btree (runtime_task_id);


--
-- Name: ix_runtime_budget_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_events_tenant_id ON public.runtime_budget_events USING btree (tenant_id);


--
-- Name: ix_runtime_budget_policies_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_agent_id ON public.runtime_budget_policies USING btree (agent_id);


--
-- Name: ix_runtime_budget_policies_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_enabled ON public.runtime_budget_policies USING btree (enabled);


--
-- Name: ix_runtime_budget_policies_profile; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_profile ON public.runtime_budget_policies USING btree (profile);


--
-- Name: ix_runtime_budget_policies_scope_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_scope_type ON public.runtime_budget_policies USING btree (scope_type);


--
-- Name: ix_runtime_budget_policies_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_source ON public.runtime_budget_policies USING btree (source);


--
-- Name: ix_runtime_budget_policies_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_tenant_id ON public.runtime_budget_policies USING btree (tenant_id);


--
-- Name: ix_runtime_budget_policies_trigger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_policies_trigger_id ON public.runtime_budget_policies USING btree (trigger_id);


--
-- Name: ix_runtime_budget_runs_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_expires_at ON public.runtime_budget_runs USING btree (expires_at);


--
-- Name: ix_runtime_budget_runs_policy_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_policy_id ON public.runtime_budget_runs USING btree (policy_id);


--
-- Name: ix_runtime_budget_runs_profile; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_profile ON public.runtime_budget_runs USING btree (profile);


--
-- Name: ix_runtime_budget_runs_root_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_agent_id ON public.runtime_budget_runs USING btree (root_agent_id);


--
-- Name: ix_runtime_budget_runs_root_external_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_external_principal_id ON public.runtime_budget_runs USING btree (root_external_principal_id);


--
-- Name: ix_runtime_budget_runs_root_run_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_run_key ON public.runtime_budget_runs USING btree (root_run_key);


--
-- Name: ix_runtime_budget_runs_root_run_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_run_kind ON public.runtime_budget_runs USING btree (root_run_kind);


--
-- Name: ix_runtime_budget_runs_root_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_runtime_task_id ON public.runtime_budget_runs USING btree (root_runtime_task_id);


--
-- Name: ix_runtime_budget_runs_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_session_id ON public.runtime_budget_runs USING btree (root_session_id);


--
-- Name: ix_runtime_budget_runs_root_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_root_user_id ON public.runtime_budget_runs USING btree (root_user_id);


--
-- Name: ix_runtime_budget_runs_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_source ON public.runtime_budget_runs USING btree (source);


--
-- Name: ix_runtime_budget_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_status ON public.runtime_budget_runs USING btree (status);


--
-- Name: ix_runtime_budget_runs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_budget_runs_tenant_id ON public.runtime_budget_runs USING btree (tenant_id);


--
-- Name: ix_runtime_notification_outbox_available_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_available_at ON public.runtime_notification_outbox USING btree (available_at);


--
-- Name: ix_runtime_notification_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_claim ON public.runtime_notification_outbox USING btree (status, available_at, locked_at);


--
-- Name: ix_runtime_notification_outbox_claim_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_claim_token ON public.runtime_notification_outbox USING btree (claim_token);


--
-- Name: ix_runtime_notification_outbox_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_locked_by ON public.runtime_notification_outbox USING btree (locked_by);


--
-- Name: ix_runtime_notification_outbox_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_page ON public.runtime_notification_outbox USING btree (integration_page_id, mailbox_sequence);


--
-- Name: ix_runtime_notification_outbox_parent_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_parent_agent_id ON public.runtime_notification_outbox USING btree (parent_agent_id);


--
-- Name: ix_runtime_notification_outbox_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_parent_session_id ON public.runtime_notification_outbox USING btree (parent_session_id);


--
-- Name: ix_runtime_notification_outbox_parent_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_parent_user_id ON public.runtime_notification_outbox USING btree (parent_user_id);


--
-- Name: ix_runtime_notification_outbox_result_object_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_result_object_id ON public.runtime_notification_outbox USING btree (result_object_id);


--
-- Name: ix_runtime_notification_outbox_root_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_root_runtime_task_id ON public.runtime_notification_outbox USING btree (root_runtime_task_id);


--
-- Name: ix_runtime_notification_outbox_source_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_source_lookup ON public.runtime_notification_outbox USING btree (tenant_id, source_run_id);


--
-- Name: ix_runtime_notification_outbox_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_status ON public.runtime_notification_outbox USING btree (status);


--
-- Name: ix_runtime_notification_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_notification_outbox_tenant_id ON public.runtime_notification_outbox USING btree (tenant_id);


--
-- Name: ix_runtime_result_integration_pages_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_claim ON public.runtime_result_integration_pages USING btree (status, lease_expires_at, created_at);


--
-- Name: ix_runtime_result_integration_pages_claim_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_claim_token ON public.runtime_result_integration_pages USING btree (claim_token);


--
-- Name: ix_runtime_result_integration_pages_parent_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_parent_agent_id ON public.runtime_result_integration_pages USING btree (parent_agent_id);


--
-- Name: ix_runtime_result_integration_pages_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_parent_session_id ON public.runtime_result_integration_pages USING btree (parent_session_id);


--
-- Name: ix_runtime_result_integration_pages_parent_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_parent_user_id ON public.runtime_result_integration_pages USING btree (parent_user_id);


--
-- Name: ix_runtime_result_integration_pages_root; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_root ON public.runtime_result_integration_pages USING btree (tenant_id, root_scope_key, integration_epoch);


--
-- Name: ix_runtime_result_integration_pages_root_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_root_runtime_task_id ON public.runtime_result_integration_pages USING btree (root_runtime_task_id);


--
-- Name: ix_runtime_result_integration_pages_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_status ON public.runtime_result_integration_pages USING btree (status);


--
-- Name: ix_runtime_result_integration_pages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_integration_pages_tenant_id ON public.runtime_result_integration_pages USING btree (tenant_id);


--
-- Name: ix_runtime_result_mailbox_cursors_parent_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_mailbox_cursors_parent_session_id ON public.runtime_result_mailbox_cursors USING btree (parent_session_id);


--
-- Name: ix_runtime_result_mailbox_cursors_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_mailbox_cursors_tenant_id ON public.runtime_result_mailbox_cursors USING btree (tenant_id);


--
-- Name: ix_runtime_result_objects_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_objects_sha256 ON public.runtime_result_objects USING btree (sha256);


--
-- Name: ix_runtime_result_objects_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_objects_source ON public.runtime_result_objects USING btree (tenant_id, source_kind, source_run_id);


--
-- Name: ix_runtime_result_objects_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_result_objects_tenant_id ON public.runtime_result_objects USING btree (tenant_id);


--
-- Name: ix_runtime_root_items_admission_disposition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_admission_disposition ON public.runtime_root_items USING btree (admission_disposition);


--
-- Name: ix_runtime_root_items_approval_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_approval_ref ON public.runtime_root_items USING btree (approval_ref);


--
-- Name: ix_runtime_root_items_budget_reservation_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_budget_reservation_key ON public.runtime_root_items USING btree (budget_reservation_key);


--
-- Name: ix_runtime_root_items_child_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_child_session_id ON public.runtime_root_items USING btree (child_session_id);


--
-- Name: ix_runtime_root_items_parent_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_parent_runtime_task_id ON public.runtime_root_items USING btree (parent_runtime_task_id);


--
-- Name: ix_runtime_root_items_reason_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_reason_code ON public.runtime_root_items USING btree (reason_code);


--
-- Name: ix_runtime_root_items_root_coverage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_root_coverage ON public.runtime_root_items USING btree (tenant_id, root_runtime_task_id, admission_disposition, state);


--
-- Name: ix_runtime_root_items_root_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_root_runtime_task_id ON public.runtime_root_items USING btree (root_runtime_task_id);


--
-- Name: ix_runtime_root_items_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_root_session_id ON public.runtime_root_items USING btree (root_session_id);


--
-- Name: ix_runtime_root_items_root_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_root_user_id ON public.runtime_root_items USING btree (root_user_id);


--
-- Name: ix_runtime_root_items_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_runtime_task_id ON public.runtime_root_items USING btree (runtime_task_id);


--
-- Name: ix_runtime_root_items_source_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_source_agent_id ON public.runtime_root_items USING btree (source_agent_id);


--
-- Name: ix_runtime_root_items_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_state ON public.runtime_root_items USING btree (state);


--
-- Name: ix_runtime_root_items_team_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_team_recovery ON public.runtime_root_items USING btree (work_type, state, runtime_task_id, next_recovery_at, recovery_claim_expires_at);


--
-- Name: ix_runtime_root_items_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_tenant_id ON public.runtime_root_items USING btree (tenant_id);


--
-- Name: ix_runtime_root_items_work_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_root_items_work_type ON public.runtime_root_items USING btree (work_type);


--
-- Name: ix_runtime_tasks_budget_admission_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_budget_admission_status ON public.runtime_tasks USING btree (budget_admission_status);


--
-- Name: ix_runtime_tasks_budget_reservation_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_budget_reservation_key ON public.runtime_tasks USING btree (budget_reservation_key);


--
-- Name: ix_runtime_tasks_budget_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_budget_run_id ON public.runtime_tasks USING btree (budget_run_id);


--
-- Name: ix_runtime_tasks_child_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_child_agent_id ON public.runtime_tasks USING btree (child_agent_id);


--
-- Name: ix_runtime_tasks_claim_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_claim_expires_at ON public.runtime_tasks USING btree (claim_expires_at);


--
-- Name: ix_runtime_tasks_claimed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_claimed_by ON public.runtime_tasks USING btree (claimed_by);


--
-- Name: ix_runtime_tasks_completion_outbox_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_completion_outbox_pending ON public.runtime_tasks USING btree (((completion_outbox_attempted_at IS NOT NULL)), completion_outbox_attempted_at, created_at) WHERE ((completion_outbox_generation IS NOT NULL) AND (completion_outbox_settled_at IS NULL) AND ((task_type)::text = ANY ((ARRAY['subagent'::character varying, 'team_member'::character varying, 'workflow'::character varying, 'delegation'::character varying, 'a2a_delegation'::character varying, 'a2a_continuation'::character varying, 'trigger'::character varying, 'approval_execution'::character varying])::text[])) AND ((status)::text = ANY ((ARRAY['completed'::character varying, 'failed'::character varying, 'killed'::character varying, 'skipped'::character varying, 'needs_reconciliation'::character varying])::text[])) AND (NOT (((task_type)::text = 'trigger'::text) AND ((status)::text = 'skipped'::text))) AND (parent_agent_id IS NOT NULL));


--
-- Name: ix_runtime_tasks_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_created_at ON public.runtime_tasks USING btree (created_at);


--
-- Name: ix_runtime_tasks_parent_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_parent_agent_id ON public.runtime_tasks USING btree (parent_agent_id);


--
-- Name: ix_runtime_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_priority ON public.runtime_tasks USING btree (priority);


--
-- Name: ix_runtime_tasks_root_authority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_root_authority ON public.runtime_tasks USING btree (tenant_id, parent_agent_id, root_user_id, root_session_id);


--
-- Name: ix_runtime_tasks_root_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_root_runtime_task_id ON public.runtime_tasks USING btree (root_runtime_task_id);


--
-- Name: ix_runtime_tasks_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_root_session_id ON public.runtime_tasks USING btree (root_session_id);


--
-- Name: ix_runtime_tasks_root_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_root_user_id ON public.runtime_tasks USING btree (root_user_id);


--
-- Name: ix_runtime_tasks_scheduled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_scheduled_at ON public.runtime_tasks USING btree (scheduled_at);


--
-- Name: ix_runtime_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_status ON public.runtime_tasks USING btree (status);


--
-- Name: ix_runtime_tasks_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_tenant_id ON public.runtime_tasks USING btree (tenant_id);


--
-- Name: ix_runtime_tasks_terminal_boundary_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_terminal_boundary_pending ON public.runtime_tasks USING btree (((terminal_boundary_reconcile_attempted_at IS NOT NULL)), terminal_boundary_reconcile_attempted_at, created_at) WHERE ((terminal_boundary_generation IS NOT NULL) AND (terminal_boundary_enqueued_at IS NULL) AND ((task_type)::text = ANY ((ARRAY['web_chat_turn'::character varying, 'goal_continuation'::character varying, 'team_member'::character varying, 'advanced_plan'::character varying, 'a2a_continuation'::character varying, 'business_task'::character varying, 'trigger'::character varying, 'delegation'::character varying])::text[])) AND ((status)::text = ANY ((ARRAY['completed'::character varying, 'failed'::character varying, 'killed'::character varying, 'skipped'::character varying, 'needs_reconciliation'::character varying])::text[])) AND (tenant_id IS NOT NULL));


--
-- Name: ix_runtime_tasks_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_tasks_trace_id ON public.runtime_tasks USING btree (trace_id);


--
-- Name: ix_runtime_terminal_boundary_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_terminal_boundary_claim ON public.runtime_terminal_boundary_outbox USING btree (tenant_id, status, available_at, lease_expires_at);


--
-- Name: ix_runtime_terminal_boundary_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_terminal_boundary_outbox_tenant_id ON public.runtime_terminal_boundary_outbox USING btree (tenant_id);


--
-- Name: ix_runtime_terminal_boundary_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_runtime_terminal_boundary_task ON public.runtime_terminal_boundary_outbox USING btree (tenant_id, runtime_task_id);


--
-- Name: ix_security_audit_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_security_audit_events_event_type ON public.security_audit_events USING btree (event_type);


--
-- Name: ix_security_audit_events_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_security_audit_events_request_id ON public.security_audit_events USING btree (request_id);


--
-- Name: ix_session_carry_forwards_consumed_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_carry_forwards_consumed_event_id ON public.session_carry_forwards USING btree (consumed_event_id);


--
-- Name: ix_session_carry_forwards_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_carry_forwards_session_id ON public.session_carry_forwards USING btree (session_id);


--
-- Name: ix_session_carry_forwards_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_carry_forwards_tenant_id ON public.session_carry_forwards USING btree (tenant_id);


--
-- Name: ix_session_commands_principal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_commands_principal_id ON public.session_commands USING btree (principal_id);


--
-- Name: ix_session_commands_principal_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_commands_principal_type_id ON public.session_commands USING btree (principal_type, principal_id);


--
-- Name: ix_session_commands_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_commands_session_id ON public.session_commands USING btree (session_id);


--
-- Name: ix_session_commands_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_commands_tenant_id ON public.session_commands USING btree (tenant_id);


--
-- Name: ix_session_control_inputs_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_control_inputs_session_id ON public.session_control_inputs USING btree (session_id);


--
-- Name: ix_session_control_inputs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_control_inputs_tenant_id ON public.session_control_inputs USING btree (tenant_id);


--
-- Name: ix_session_event_cursors_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_event_cursors_tenant_id ON public.session_event_cursors USING btree (tenant_id);


--
-- Name: ix_session_event_outbox_available_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_event_outbox_available_at ON public.session_event_outbox USING btree (available_at);


--
-- Name: ix_session_event_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_event_outbox_claim ON public.session_event_outbox USING btree (status, available_at, claim_expires_at);


--
-- Name: ix_session_event_outbox_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_event_outbox_session_id ON public.session_event_outbox USING btree (session_id);


--
-- Name: ix_session_event_outbox_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_event_outbox_tenant_id ON public.session_event_outbox USING btree (tenant_id);


--
-- Name: ix_session_feedback_aggregates_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_aggregates_session_id ON public.session_feedback_aggregates USING btree (session_id);


--
-- Name: ix_session_feedback_aggregates_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_aggregates_tenant_id ON public.session_feedback_aggregates USING btree (tenant_id);


--
-- Name: ix_session_feedback_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_agent_id ON public.session_feedback_events USING btree (agent_id);


--
-- Name: ix_session_feedback_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_created_at ON public.session_feedback_events USING btree (created_at);


--
-- Name: ix_session_feedback_events_decision_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_decision_trace_id ON public.session_feedback_events USING btree (decision_trace_id);


--
-- Name: ix_session_feedback_events_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_session_id ON public.session_feedback_events USING btree (session_id);


--
-- Name: ix_session_feedback_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_tenant_id ON public.session_feedback_events USING btree (tenant_id);


--
-- Name: ix_session_feedback_events_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_feedback_events_user_id ON public.session_feedback_events USING btree (user_id);


--
-- Name: ix_session_input_admissions_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_input_admissions_session_id ON public.session_input_admissions USING btree (session_id);


--
-- Name: ix_session_input_admissions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_input_admissions_tenant_id ON public.session_input_admissions USING btree (tenant_id);


--
-- Name: ix_session_model_results_round_committed_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_model_results_round_committed_event_id ON public.session_model_results USING btree (round_committed_event_id);


--
-- Name: ix_session_model_results_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_model_results_run_id ON public.session_model_results USING btree (run_id);


--
-- Name: ix_session_model_results_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_model_results_session_id ON public.session_model_results USING btree (session_id);


--
-- Name: ix_session_model_results_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_model_results_tenant_id ON public.session_model_results USING btree (tenant_id);


--
-- Name: ix_session_model_results_turn_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_model_results_turn_id ON public.session_model_results USING btree (turn_id);


--
-- Name: ix_session_next_round_plans_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_next_round_plans_session_id ON public.session_next_round_plans USING btree (session_id);


--
-- Name: ix_session_next_round_plans_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_next_round_plans_tenant_id ON public.session_next_round_plans USING btree (tenant_id);


--
-- Name: ix_session_round_obligations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_round_obligations_session_id ON public.session_round_obligations USING btree (session_id);


--
-- Name: ix_session_round_obligations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_round_obligations_tenant_id ON public.session_round_obligations USING btree (tenant_id);


--
-- Name: ix_session_run_outcomes_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_run_outcomes_session_id ON public.session_run_outcomes USING btree (session_id);


--
-- Name: ix_session_run_outcomes_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_run_outcomes_tenant_id ON public.session_run_outcomes USING btree (tenant_id);


--
-- Name: ix_session_run_outcomes_terminal_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_run_outcomes_terminal_event_id ON public.session_run_outcomes USING btree (terminal_event_id);


--
-- Name: ix_session_run_outcomes_turn_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_run_outcomes_turn_id ON public.session_run_outcomes USING btree (turn_id);


--
-- Name: ix_session_tool_invocations_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_tool_invocations_run_id ON public.session_tool_invocations USING btree (run_id);


--
-- Name: ix_session_tool_invocations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_tool_invocations_session_id ON public.session_tool_invocations USING btree (session_id);


--
-- Name: ix_session_tool_invocations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_tool_invocations_tenant_id ON public.session_tool_invocations USING btree (tenant_id);


--
-- Name: ix_session_turn_inputs_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_turn_inputs_session_id ON public.session_turn_inputs USING btree (session_id);


--
-- Name: ix_session_turn_inputs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_turn_inputs_tenant_id ON public.session_turn_inputs USING btree (tenant_id);


--
-- Name: ix_session_turn_replacements_last_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_turn_replacements_last_event_id ON public.session_turn_replacements USING btree (last_event_id);


--
-- Name: ix_session_turn_replacements_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_turn_replacements_session_id ON public.session_turn_replacements USING btree (session_id);


--
-- Name: ix_session_turn_replacements_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_turn_replacements_tenant_id ON public.session_turn_replacements USING btree (tenant_id);


--
-- Name: ix_session_writer_heartbeats_last_seen_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_session_writer_heartbeats_last_seen_at ON public.session_writer_heartbeats USING btree (last_seen_at);


--
-- Name: ix_skills_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_skills_tenant_id ON public.skills USING btree (tenant_id);


--
-- Name: ix_sso_scan_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sso_scan_sessions_tenant_id ON public.sso_scan_sessions USING btree (tenant_id);


--
-- Name: ix_sso_scan_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sso_scan_sessions_user_id ON public.sso_scan_sessions USING btree (user_id);


--
-- Name: ix_storage_blob_refs_blob_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blob_refs_blob_id ON public.storage_blob_refs USING btree (blob_id);


--
-- Name: ix_storage_blob_refs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blob_refs_tenant_id ON public.storage_blob_refs USING btree (tenant_id);


--
-- Name: ix_storage_blob_refs_tenant_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blob_refs_tenant_owner ON public.storage_blob_refs USING btree (tenant_id, owner_type, owner_id);


--
-- Name: ix_storage_blobs_content_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_content_sha256 ON public.storage_blobs USING btree (content_sha256);


--
-- Name: ix_storage_blobs_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_kind ON public.storage_blobs USING btree (kind);


--
-- Name: ix_storage_blobs_retention_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_retention_class ON public.storage_blobs USING btree (retention_class);


--
-- Name: ix_storage_blobs_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_state ON public.storage_blobs USING btree (state);


--
-- Name: ix_storage_blobs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_tenant_id ON public.storage_blobs USING btree (tenant_id);


--
-- Name: ix_storage_blobs_tenant_state_delete_after; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_blobs_tenant_state_delete_after ON public.storage_blobs USING btree (tenant_id, state, delete_after);


--
-- Name: ix_storage_gc_runs_manifest_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_gc_runs_manifest_sha256 ON public.storage_gc_runs USING btree (manifest_sha256);


--
-- Name: ix_storage_gc_runs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_gc_runs_tenant_id ON public.storage_gc_runs USING btree (tenant_id);


--
-- Name: ix_storage_gc_runs_tenant_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_storage_gc_runs_tenant_started ON public.storage_gc_runs USING btree (tenant_id, started_at);


--
-- Name: ix_task_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_logs_tenant_id ON public.task_logs USING btree (tenant_id);


--
-- Name: ix_tasks_active_runtime_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_active_runtime_task_id ON public.tasks USING btree (active_runtime_task_id);


--
-- Name: ix_tasks_authority_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_authority_state ON public.tasks USING btree (authority_state);


--
-- Name: ix_tasks_last_execution_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_last_execution_status ON public.tasks USING btree (last_execution_status);


--
-- Name: ix_tasks_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_root_session_id ON public.tasks USING btree (root_session_id);


--
-- Name: ix_tasks_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_tenant_id ON public.tasks USING btree (tenant_id);


--
-- Name: ix_tenant_channel_configs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tenant_channel_configs_tenant_id ON public.tenant_channel_configs USING btree (tenant_id);


--
-- Name: ix_tenant_installed_plugins_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tenant_installed_plugins_tenant_id ON public.tenant_installed_plugins USING btree (tenant_id);


--
-- Name: ix_tenant_scope_quarantine_records_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tenant_scope_quarantine_records_tenant_id ON public.tenant_scope_quarantine_records USING btree (tenant_id);


--
-- Name: ix_tenant_tool_configs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tenant_tool_configs_tenant_id ON public.tenant_tool_configs USING btree (tenant_id);


--
-- Name: ix_tenants_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: ix_token_usage_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_token_usage_events_agent_id ON public.token_usage_events USING btree (agent_id);


--
-- Name: ix_token_usage_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_token_usage_events_created_at ON public.token_usage_events USING btree (created_at);


--
-- Name: ix_token_usage_events_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_token_usage_events_source ON public.token_usage_events USING btree (source);


--
-- Name: ix_token_usage_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_token_usage_events_tenant_id ON public.token_usage_events USING btree (tenant_id);


--
-- Name: ix_token_usage_events_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_token_usage_events_user_id ON public.token_usage_events USING btree (user_id);


--
-- Name: ix_tools_mcp_metadata_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tools_mcp_metadata_fingerprint ON public.tools USING btree (mcp_metadata_fingerprint);


--
-- Name: ix_tools_mcp_trust_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tools_mcp_trust_status ON public.tools USING btree (mcp_trust_status);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_feishu_open_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_feishu_open_id ON public.users USING btree (feishu_open_id);


--
-- Name: ix_users_oidc_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_oidc_sub ON public.users USING btree (oidc_sub);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_workflow_definitions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_definitions_name ON public.workflow_definitions USING btree (name);


--
-- Name: ix_workflow_definitions_promotion_proposal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_definitions_promotion_proposal_id ON public.workflow_definitions USING btree (promotion_proposal_id);


--
-- Name: ix_workflow_definitions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_definitions_status ON public.workflow_definitions USING btree (status);


--
-- Name: ix_workflow_definitions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_definitions_tenant_id ON public.workflow_definitions USING btree (tenant_id);


--
-- Name: ix_workflow_leaf_calls_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_leaf_calls_run_id ON public.workflow_leaf_calls USING btree (run_id);


--
-- Name: ix_workflow_leaf_calls_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_leaf_calls_status ON public.workflow_leaf_calls USING btree (status);


--
-- Name: ix_workflow_leaf_calls_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_leaf_calls_tenant_id ON public.workflow_leaf_calls USING btree (tenant_id);


--
-- Name: ix_workflow_preview_artifacts_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_agent_id ON public.workflow_preview_artifacts USING btree (agent_id);


--
-- Name: ix_workflow_preview_artifacts_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_expires_at ON public.workflow_preview_artifacts USING btree (expires_at);


--
-- Name: ix_workflow_preview_artifacts_proposal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_proposal_id ON public.workflow_preview_artifacts USING btree (proposal_id);


--
-- Name: ix_workflow_preview_artifacts_requested_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_requested_by_user_id ON public.workflow_preview_artifacts USING btree (requested_by_user_id);


--
-- Name: ix_workflow_preview_artifacts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_session_id ON public.workflow_preview_artifacts USING btree (session_id);


--
-- Name: ix_workflow_preview_artifacts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_artifacts_tenant_id ON public.workflow_preview_artifacts USING btree (tenant_id);


--
-- Name: ix_workflow_preview_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_identity ON public.workflow_preview_artifacts USING btree (tenant_id, agent_id, session_id, requested_by_user_id);


--
-- Name: ix_workflow_preview_start_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_preview_start_claim ON public.workflow_preview_artifacts USING btree (status, claim_expires_at);


--
-- Name: ix_workflow_promotion_proposals_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_agent_id ON public.workflow_promotion_proposals USING btree (agent_id);


--
-- Name: ix_workflow_promotion_proposals_requester_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_requester_user_id ON public.workflow_promotion_proposals USING btree (requester_user_id);


--
-- Name: ix_workflow_promotion_proposals_reviewer_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_reviewer_user_id ON public.workflow_promotion_proposals USING btree (reviewer_user_id);


--
-- Name: ix_workflow_promotion_proposals_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_root_session_id ON public.workflow_promotion_proposals USING btree (root_session_id);


--
-- Name: ix_workflow_promotion_proposals_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_run_id ON public.workflow_promotion_proposals USING btree (run_id);


--
-- Name: ix_workflow_promotion_proposals_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_promotion_proposals_tenant_id ON public.workflow_promotion_proposals USING btree (tenant_id);


--
-- Name: ix_workflow_proposal_artifacts_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_artifacts_agent_id ON public.workflow_proposal_artifacts USING btree (agent_id);


--
-- Name: ix_workflow_proposal_artifacts_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_artifacts_expires_at ON public.workflow_proposal_artifacts USING btree (expires_at);


--
-- Name: ix_workflow_proposal_artifacts_requested_by_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_artifacts_requested_by_user_id ON public.workflow_proposal_artifacts USING btree (requested_by_user_id);


--
-- Name: ix_workflow_proposal_artifacts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_artifacts_session_id ON public.workflow_proposal_artifacts USING btree (session_id);


--
-- Name: ix_workflow_proposal_artifacts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_artifacts_tenant_id ON public.workflow_proposal_artifacts USING btree (tenant_id);


--
-- Name: ix_workflow_proposal_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_proposal_identity ON public.workflow_proposal_artifacts USING btree (tenant_id, agent_id, session_id, requested_by_user_id);


--
-- Name: ix_workflow_quotas_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_quotas_run_id ON public.workflow_quotas USING btree (run_id);


--
-- Name: ix_workflow_quotas_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_quotas_tenant_id ON public.workflow_quotas USING btree (tenant_id);


--
-- Name: ix_workflow_steps_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_steps_run_id ON public.workflow_steps USING btree (run_id);


--
-- Name: ix_workflow_steps_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_steps_status ON public.workflow_steps USING btree (status);


--
-- Name: ix_workflow_steps_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_steps_tenant_id ON public.workflow_steps USING btree (tenant_id);


--
-- Name: ix_workspace_resource_manifests_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_resource_manifests_agent_id ON public.workspace_resource_manifests USING btree (agent_id);


--
-- Name: ix_workspace_resource_manifests_authority_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_resource_manifests_authority_state ON public.workspace_resource_manifests USING btree (authority_state);


--
-- Name: ix_workspace_resource_manifests_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_resource_manifests_owner_user_id ON public.workspace_resource_manifests USING btree (owner_user_id);


--
-- Name: ix_workspace_resource_manifests_root_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_resource_manifests_root_session_id ON public.workspace_resource_manifests USING btree (root_session_id);


--
-- Name: ix_workspace_resource_manifests_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_resource_manifests_tenant_id ON public.workspace_resource_manifests USING btree (tenant_id);


--
-- Name: uq_chat_messages_ingress_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_chat_messages_ingress_user ON public.chat_messages USING btree (source_ingress_event_id) WHERE (source_ingress_event_id IS NOT NULL);


--
-- Name: uq_chat_transcript_budget_transition_causation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_chat_transcript_budget_transition_causation ON public.chat_transcript_events USING btree (session_id, causation_id, event_type) WHERE ((causation_id IS NOT NULL) AND ((event_type)::text = 'runtime_budget_transition'::text) AND (metadata_json ? 'budget_transition_outbox_id'::text));


--
-- Name: uq_chat_transcript_completion_causation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_chat_transcript_completion_causation ON public.chat_transcript_events USING btree (session_id, causation_id, event_type) WHERE ((causation_id IS NOT NULL) AND ((event_type)::text = 'agent_task_notification'::text) AND (metadata_json ? 'completion_outbox_id'::text));


--
-- Name: uq_chat_transcript_tool_result_invocation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_chat_transcript_tool_result_invocation ON public.chat_transcript_events USING btree (session_id, invocation_id) WHERE ((schema_version = 2) AND ((item_kind)::text = 'tool_result'::text) AND ((lifecycle)::text = 'completed'::text));


--
-- Name: uq_runtime_tasks_active_web_chat_session; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_runtime_tasks_active_web_chat_session ON public.runtime_tasks USING btree (parent_agent_id, parent_session_id) WHERE (((task_type)::text = ANY ((ARRAY['web_chat_turn'::character varying, 'goal_continuation'::character varying, 'team_member'::character varying, 'advanced_plan'::character varying, 'a2a_continuation'::character varying])::text[])) AND ((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'suspended'::character varying, 'resumable'::character varying])::text[])) AND (parent_agent_id IS NOT NULL) AND (parent_session_id IS NOT NULL));


--
-- Name: uq_session_next_round_plan_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_session_next_round_plan_current ON public.session_next_round_plans USING btree (run_id, next_round_id) WHERE ((state)::text = ANY ((ARRAY['committed'::character varying, 'dispatched'::character varying, 'needs_reconciliation'::character varying])::text[]));


--
-- Name: audit_logs trg_audit_logs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_logs_immutable BEFORE DELETE OR UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.reject_audit_evidence_mutation();


--
-- Name: audit_logs trg_audit_logs_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_logs_no_truncate BEFORE TRUNCATE ON public.audit_logs FOR EACH STATEMENT EXECUTE FUNCTION public.reject_audit_evidence_mutation();


--
-- Name: config_revisions trg_config_revision_immutability; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_config_revision_immutability BEFORE DELETE OR UPDATE ON public.config_revisions FOR EACH ROW EXECUTE FUNCTION public.enforce_config_revision_immutability();


--
-- Name: hr_creation_drafts trg_hr_creation_blueprint_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_hr_creation_blueprint_immutable BEFORE UPDATE OF blueprint_version, blueprint_hash, blueprint_json, status ON public.hr_creation_drafts FOR EACH ROW EXECUTE FUNCTION public.enforce_hr_creation_blueprint_immutability();


--
-- Name: runtime_tasks trg_runtime_task_terminal_boundary_generation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_runtime_task_terminal_boundary_generation BEFORE INSERT OR UPDATE OF task_type, terminal_boundary_generation ON public.runtime_tasks FOR EACH ROW EXECUTE FUNCTION public.set_runtime_task_terminal_boundary_generation();


--
-- Name: security_audit_events trg_security_audit_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_security_audit_events_immutable BEFORE DELETE OR UPDATE ON public.security_audit_events FOR EACH ROW EXECUTE FUNCTION public.reject_audit_evidence_mutation();


--
-- Name: security_audit_events trg_security_audit_events_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_security_audit_events_no_truncate BEFORE TRUNCATE ON public.security_audit_events FOR EACH STATEMENT EXECUTE FUNCTION public.reject_audit_evidence_mutation();


--
-- Name: session_carry_forwards trg_session_carry_forwards_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_carry_forwards_tenant_binding BEFORE INSERT OR UPDATE ON public.session_carry_forwards FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_commands trg_session_commands_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_commands_tenant_binding BEFORE INSERT OR UPDATE ON public.session_commands FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_control_inputs trg_session_control_inputs_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_control_inputs_tenant_binding BEFORE INSERT OR UPDATE ON public.session_control_inputs FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_event_cursors trg_session_event_cursors_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_event_cursors_tenant_binding BEFORE INSERT OR UPDATE ON public.session_event_cursors FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_event_outbox trg_session_event_outbox_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_event_outbox_tenant_binding BEFORE INSERT OR UPDATE ON public.session_event_outbox FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: chat_transcript_events trg_session_event_v2_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_event_v2_contract BEFORE INSERT OR UPDATE ON public.chat_transcript_events FOR EACH ROW EXECUTE FUNCTION public.enforce_session_event_v2_contract();


--
-- Name: session_feedback_aggregates trg_session_feedback_aggregates_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_feedback_aggregates_tenant_binding BEFORE INSERT OR UPDATE ON public.session_feedback_aggregates FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_input_admissions trg_session_input_admissions_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_input_admissions_tenant_binding BEFORE INSERT OR UPDATE ON public.session_input_admissions FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_model_results trg_session_model_results_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_model_results_tenant_binding BEFORE INSERT OR UPDATE ON public.session_model_results FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_next_round_plans trg_session_next_round_plans_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_next_round_plans_tenant_binding BEFORE INSERT OR UPDATE ON public.session_next_round_plans FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_round_obligations trg_session_round_obligations_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_round_obligations_tenant_binding BEFORE INSERT OR UPDATE ON public.session_round_obligations FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_run_outcomes trg_session_run_outcomes_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_run_outcomes_tenant_binding BEFORE INSERT OR UPDATE ON public.session_run_outcomes FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_tool_invocations trg_session_tool_invocations_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_tool_invocations_tenant_binding BEFORE INSERT OR UPDATE ON public.session_tool_invocations FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_turn_inputs trg_session_turn_inputs_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_turn_inputs_tenant_binding BEFORE INSERT OR UPDATE ON public.session_turn_inputs FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: session_turn_replacements trg_session_turn_replacements_tenant_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_turn_replacements_tenant_binding BEFORE INSERT OR UPDATE ON public.session_turn_replacements FOR EACH ROW EXECUTE FUNCTION public.enforce_session_v2_tenant_binding();


--
-- Name: runtime_tasks trg_session_writer_epoch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_session_writer_epoch BEFORE INSERT OR UPDATE ON public.runtime_tasks FOR EACH ROW EXECUTE FUNCTION public.enforce_session_writer_epoch();


--
-- Name: workflow_promotion_proposals trg_workflow_promotion_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_workflow_promotion_snapshot_immutable BEFORE DELETE OR UPDATE ON public.workflow_promotion_proposals FOR EACH ROW EXECUTE FUNCTION public.workflow_promotion_snapshot_immutable();


--
-- Name: agent_activity_logs agent_activity_logs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_activity_logs
    ADD CONSTRAINT agent_activity_logs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_activity_logs agent_activity_logs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_activity_logs
    ADD CONSTRAINT agent_activity_logs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agent_activity_logs agent_activity_logs_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_activity_logs
    ADD CONSTRAINT agent_activity_logs_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: agent_activity_logs agent_activity_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_activity_logs
    ADD CONSTRAINT agent_activity_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_capability_installs agent_capability_installs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_capability_installs
    ADD CONSTRAINT agent_capability_installs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_capability_installs agent_capability_installs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_capability_installs
    ADD CONSTRAINT agent_capability_installs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_agent_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_agent_owner_user_id_fkey FOREIGN KEY (agent_owner_user_id) REFERENCES public.users(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.agent_collaboration_groups(id) ON DELETE CASCADE;


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_invited_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_invited_by_agent_id_fkey FOREIGN KEY (invited_by_agent_id) REFERENCES public.agents(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_invited_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_invited_by_user_id_fkey FOREIGN KEY (invited_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_collaboration_group_members agent_collaboration_group_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_group_members
    ADD CONSTRAINT agent_collaboration_group_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_collaboration_groups agent_collaboration_groups_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_groups
    ADD CONSTRAINT agent_collaboration_groups_created_by_agent_id_fkey FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: agent_collaboration_groups agent_collaboration_groups_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_groups
    ADD CONSTRAINT agent_collaboration_groups_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_collaboration_groups agent_collaboration_groups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_collaboration_groups
    ADD CONSTRAINT agent_collaboration_groups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_mcp_server_assignments agent_mcp_server_assignments_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_server_assignments
    ADD CONSTRAINT agent_mcp_server_assignments_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_mcp_server_assignments agent_mcp_server_assignments_mcp_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_server_assignments
    ADD CONSTRAINT agent_mcp_server_assignments_mcp_server_id_fkey FOREIGN KEY (mcp_server_id) REFERENCES public.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: agent_mcp_server_assignments agent_mcp_server_assignments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_server_assignments
    ADD CONSTRAINT agent_mcp_server_assignments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_mcp_tool_overrides agent_mcp_tool_overrides_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_tool_overrides
    ADD CONSTRAINT agent_mcp_tool_overrides_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_mcp_tool_overrides agent_mcp_tool_overrides_mcp_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_tool_overrides
    ADD CONSTRAINT agent_mcp_tool_overrides_mcp_server_id_fkey FOREIGN KEY (mcp_server_id) REFERENCES public.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: agent_mcp_tool_overrides agent_mcp_tool_overrides_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_mcp_tool_overrides
    ADD CONSTRAINT agent_mcp_tool_overrides_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_permissions agent_permissions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_permissions
    ADD CONSTRAINT agent_permissions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_permissions agent_permissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_permissions
    ADD CONSTRAINT agent_permissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_plan_recommendations agent_plan_recommendations_accepted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_accepted_by_user_id_fkey FOREIGN KEY (accepted_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_recommendations agent_plan_recommendations_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_plan_recommendations agent_plan_recommendations_declined_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_declined_by_user_id_fkey FOREIGN KEY (declined_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_recommendations agent_plan_recommendations_recommended_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_recommended_to_user_id_fkey FOREIGN KEY (recommended_to_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_recommendations agent_plan_recommendations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_recommendations
    ADD CONSTRAINT agent_plan_recommendations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_plan_requests agent_plan_requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_plan_requests agent_plan_requests_confirmed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_confirmed_by_user_id_fkey FOREIGN KEY (confirmed_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_requests agent_plan_requests_rejected_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_rejected_by_user_id_fkey FOREIGN KEY (rejected_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_requests agent_plan_requests_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_plan_requests agent_plan_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plan_requests
    ADD CONSTRAINT agent_plan_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_plugin_assignments agent_plugin_assignments_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plugin_assignments
    ADD CONSTRAINT agent_plugin_assignments_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_plugin_assignments agent_plugin_assignments_installed_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plugin_assignments
    ADD CONSTRAINT agent_plugin_assignments_installed_plugin_id_fkey FOREIGN KEY (installed_plugin_id) REFERENCES public.tenant_installed_plugins(id) ON DELETE CASCADE;


--
-- Name: agent_plugin_assignments agent_plugin_assignments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_plugin_assignments
    ADD CONSTRAINT agent_plugin_assignments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_relationships agent_relationships_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_relationships
    ADD CONSTRAINT agent_relationships_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_relationships agent_relationships_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_relationships
    ADD CONSTRAINT agent_relationships_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.org_members(id);


--
-- Name: agent_relationships agent_relationships_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_relationships
    ADD CONSTRAINT agent_relationships_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_schedules agent_schedules_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_schedules agent_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: agent_schedules agent_schedules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_session_goals agent_session_goals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_session_goals
    ADD CONSTRAINT agent_session_goals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_session_goals agent_session_goals_chat_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_session_goals
    ADD CONSTRAINT agent_session_goals_chat_session_id_fkey FOREIGN KEY (chat_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: agent_session_goals agent_session_goals_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_session_goals
    ADD CONSTRAINT agent_session_goals_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_session_goals agent_session_goals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_session_goals
    ADD CONSTRAINT agent_session_goals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_team_events agent_team_events_receiver_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_events
    ADD CONSTRAINT agent_team_events_receiver_member_id_fkey FOREIGN KEY (receiver_member_id) REFERENCES public.agent_team_members(id);


--
-- Name: agent_team_events agent_team_events_sender_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_events
    ADD CONSTRAINT agent_team_events_sender_member_id_fkey FOREIGN KEY (sender_member_id) REFERENCES public.agent_team_members(id);


--
-- Name: agent_team_events agent_team_events_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_events
    ADD CONSTRAINT agent_team_events_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.agent_teams(id);


--
-- Name: agent_team_members agent_team_members_chat_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_members
    ADD CONSTRAINT agent_team_members_chat_session_id_fkey FOREIGN KEY (chat_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: agent_team_members agent_team_members_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_members
    ADD CONSTRAINT agent_team_members_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.llm_models(id);


--
-- Name: agent_team_members agent_team_members_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_members
    ADD CONSTRAINT agent_team_members_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id);


--
-- Name: agent_team_members agent_team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_team_members
    ADD CONSTRAINT agent_team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.agent_teams(id);


--
-- Name: agent_teams agent_teams_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_teams
    ADD CONSTRAINT agent_teams_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_teams agent_teams_lead_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_teams
    ADD CONSTRAINT agent_teams_lead_agent_id_fkey FOREIGN KEY (lead_agent_id) REFERENCES public.agents(id);


--
-- Name: agent_teams agent_teams_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_teams
    ADD CONSTRAINT agent_teams_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: agent_teams agent_teams_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_teams
    ADD CONSTRAINT agent_teams_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_templates agent_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: agent_templates agent_templates_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: agent_templates agent_templates_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.llm_models(id);


--
-- Name: agent_templates agent_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_tools agent_tools_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_tools agent_tools_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agent_tools agent_tools_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.tools(id) ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: agents agents_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: agents agents_fallback_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_fallback_model_id_fkey FOREIGN KEY (fallback_model_id) REFERENCES public.llm_models(id);


--
-- Name: agents agents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: agents agents_parent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_parent_agent_id_fkey FOREIGN KEY (parent_agent_id) REFERENCES public.agents(id);


--
-- Name: agents agents_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: agents agents_primary_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_primary_model_id_fkey FOREIGN KEY (primary_model_id) REFERENCES public.llm_models(id);


--
-- Name: agents agents_sponsor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_sponsor_user_id_fkey FOREIGN KEY (sponsor_user_id) REFERENCES public.users(id);


--
-- Name: agents agents_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.agent_templates(id);


--
-- Name: agents agents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: ai_asset_records ai_asset_records_active_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_active_revision_id_fkey FOREIGN KEY (active_revision_id) REFERENCES public.config_revisions(id) ON DELETE SET NULL;


--
-- Name: ai_asset_records ai_asset_records_created_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_created_by_agent_id_fkey FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ai_asset_records ai_asset_records_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_asset_records ai_asset_records_published_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_published_by_user_id_fkey FOREIGN KEY (published_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_asset_records ai_asset_records_revoked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_asset_records ai_asset_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_records
    ADD CONSTRAINT ai_asset_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: ai_asset_usage_events ai_asset_usage_events_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_usage_events
    ADD CONSTRAINT ai_asset_usage_events_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.ai_asset_records(id) ON DELETE CASCADE;


--
-- Name: ai_asset_usage_events ai_asset_usage_events_asset_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_usage_events
    ADD CONSTRAINT ai_asset_usage_events_asset_revision_id_fkey FOREIGN KEY (asset_revision_id) REFERENCES public.config_revisions(id) ON DELETE RESTRICT;


--
-- Name: ai_asset_usage_events ai_asset_usage_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_asset_usage_events
    ADD CONSTRAINT ai_asset_usage_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: approval_requests approval_requests_requested_by_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_requested_by_external_principal_id_fkey FOREIGN KEY (requested_by_external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: approval_requests approval_requests_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: approval_requests approval_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_logs audit_logs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: budget_transition_outbox budget_transition_outbox_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: budget_transition_outbox budget_transition_outbox_budget_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_budget_event_id_fkey FOREIGN KEY (budget_event_id) REFERENCES public.runtime_budget_events(id) ON DELETE CASCADE;


--
-- Name: budget_transition_outbox budget_transition_outbox_budget_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_budget_run_id_fkey FOREIGN KEY (budget_run_id) REFERENCES public.runtime_budget_runs(id) ON DELETE CASCADE;


--
-- Name: budget_transition_outbox budget_transition_outbox_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: budget_transition_outbox budget_transition_outbox_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: budget_transition_outbox budget_transition_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: budget_transition_outbox budget_transition_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_transition_outbox
    ADD CONSTRAINT budget_transition_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: capability_factor_reviews capability_factor_reviews_factor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factor_reviews
    ADD CONSTRAINT capability_factor_reviews_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES public.capability_factors(id) ON DELETE CASCADE;


--
-- Name: capability_factor_reviews capability_factor_reviews_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factor_reviews
    ADD CONSTRAINT capability_factor_reviews_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: capability_factors capability_factors_originating_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factors
    ADD CONSTRAINT capability_factors_originating_agent_id_fkey FOREIGN KEY (originating_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: capability_factors capability_factors_originating_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factors
    ADD CONSTRAINT capability_factors_originating_user_id_fkey FOREIGN KEY (originating_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: capability_factors capability_factors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_factors
    ADD CONSTRAINT capability_factors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: capability_policies capability_policies_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_policies
    ADD CONSTRAINT capability_policies_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: capability_policies capability_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_policies
    ADD CONSTRAINT capability_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: capability_promotion_proposals capability_promotion_proposals_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: capability_promotion_proposals capability_promotion_proposals_factor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES public.capability_factors(id) ON DELETE CASCADE;


--
-- Name: capability_promotion_proposals capability_promotion_proposals_resulting_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_resulting_snapshot_id_fkey FOREIGN KEY (resulting_snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE SET NULL;


--
-- Name: capability_promotion_proposals capability_promotion_proposals_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.capability_factor_reviews(id) ON DELETE SET NULL;


--
-- Name: capability_promotion_proposals capability_promotion_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_promotion_proposals
    ADD CONSTRAINT capability_promotion_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: channel_configs channel_configs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: channel_configs channel_configs_self_identity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_self_identity_user_id_fkey FOREIGN KEY (self_identity_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: channel_configs channel_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: channel_delivery_outbox channel_delivery_outbox_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: channel_delivery_outbox channel_delivery_outbox_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: channel_delivery_outbox channel_delivery_outbox_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: channel_delivery_outbox channel_delivery_outbox_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: channel_delivery_outbox channel_delivery_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: channel_delivery_outbox channel_delivery_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_delivery_outbox
    ADD CONSTRAINT channel_delivery_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: channel_ingress_events channel_ingress_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: channel_ingress_events channel_ingress_events_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: channel_ingress_events channel_ingress_events_result_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_result_runtime_task_id_fkey FOREIGN KEY (result_runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: channel_ingress_events channel_ingress_events_result_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_result_session_id_fkey FOREIGN KEY (result_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: channel_ingress_events channel_ingress_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_ingress_events
    ADD CONSTRAINT channel_ingress_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: charter_proposals charter_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charter_proposals
    ADD CONSTRAINT charter_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: chat_artifacts chat_artifacts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: chat_artifacts chat_artifacts_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id);


--
-- Name: chat_artifacts chat_artifacts_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chat_artifacts chat_artifacts_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: chat_artifacts chat_artifacts_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id);


--
-- Name: chat_artifacts chat_artifacts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_artifacts chat_artifacts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_artifacts
    ADD CONSTRAINT chat_artifacts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: chat_messages chat_messages_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: chat_messages chat_messages_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: chat_messages chat_messages_source_ingress_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_source_ingress_event_id_fkey FOREIGN KEY (source_ingress_event_id) REFERENCES public.channel_ingress_events(id) ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: chat_messages chat_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_sessions chat_sessions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: chat_sessions chat_sessions_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: chat_sessions chat_sessions_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_sessions chat_sessions_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id);


--
-- Name: chat_sessions chat_sessions_peer_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_peer_agent_id_fkey FOREIGN KEY (peer_agent_id) REFERENCES public.agents(id);


--
-- Name: chat_sessions chat_sessions_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_sessions chat_sessions_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id);


--
-- Name: chat_sessions chat_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: chat_sessions chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_transcript_events chat_transcript_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: chat_transcript_events chat_transcript_events_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.session_commands(id);


--
-- Name: chat_transcript_events chat_transcript_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id);


--
-- Name: chat_transcript_events chat_transcript_events_parent_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_parent_event_id_fkey FOREIGN KEY (parent_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: chat_transcript_events chat_transcript_events_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_transcript_events chat_transcript_events_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_transcript_events chat_transcript_events_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id);


--
-- Name: chat_transcript_events chat_transcript_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- Name: chat_transcript_events chat_transcript_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_transcript_events
    ADD CONSTRAINT chat_transcript_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: company_knowledge_events company_knowledge_events_accountable_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_events
    ADD CONSTRAINT company_knowledge_events_accountable_user_id_fkey FOREIGN KEY (accountable_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_events company_knowledge_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_events
    ADD CONSTRAINT company_knowledge_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_evidence company_knowledge_evidence_source_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_evidence
    ADD CONSTRAINT company_knowledge_evidence_source_contract_id_fkey FOREIGN KEY (source_contract_id) REFERENCES public.company_knowledge_source_contracts(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_evidence company_knowledge_evidence_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_evidence
    ADD CONSTRAINT company_knowledge_evidence_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.company_knowledge_sources(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_evidence company_knowledge_evidence_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_evidence
    ADD CONSTRAINT company_knowledge_evidence_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_accountable_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_accountable_user_id_fkey FOREIGN KEY (accountable_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.company_knowledge_evidence(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_source_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_source_contract_id_fkey FOREIGN KEY (source_contract_id) REFERENCES public.company_knowledge_source_contracts(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.company_knowledge_sources(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs company_knowledge_import_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT company_knowledge_import_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_outbox company_knowledge_outbox_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_outbox
    ADD CONSTRAINT company_knowledge_outbox_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.company_knowledge_events(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_outbox company_knowledge_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_outbox
    ADD CONSTRAINT company_knowledge_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_proposals company_knowledge_proposals_accountable_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT company_knowledge_proposals_accountable_user_id_fkey FOREIGN KEY (accountable_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_proposals company_knowledge_proposals_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT company_knowledge_proposals_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.knowledge_documents(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_proposals company_knowledge_proposals_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT company_knowledge_proposals_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.company_knowledge_sources(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_proposals company_knowledge_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT company_knowledge_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_publications company_knowledge_publication_restored_from_publication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publication_restored_from_publication_id_fkey FOREIGN KEY (restored_from_publication_id) REFERENCES public.company_knowledge_publications(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_publications company_knowledge_publications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_publications company_knowledge_publications_proposal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_proposal_id_fkey FOREIGN KEY (proposal_id) REFERENCES public.company_knowledge_proposals(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_publications company_knowledge_publications_published_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_published_by_user_id_fkey FOREIGN KEY (published_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_publications company_knowledge_publications_supersedes_publication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_supersedes_publication_id_fkey FOREIGN KEY (supersedes_publication_id) REFERENCES public.company_knowledge_publications(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_publications company_knowledge_publications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_publications
    ADD CONSTRAINT company_knowledge_publications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_reviews company_knowledge_reviews_proposal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_reviews
    ADD CONSTRAINT company_knowledge_reviews_proposal_id_fkey FOREIGN KEY (proposal_id) REFERENCES public.company_knowledge_proposals(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_reviews company_knowledge_reviews_reviewer_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_reviews
    ADD CONSTRAINT company_knowledge_reviews_reviewer_user_id_fkey FOREIGN KEY (reviewer_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_reviews company_knowledge_reviews_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_reviews
    ADD CONSTRAINT company_knowledge_reviews_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_source_contracts company_knowledge_source_contracts_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_source_contracts
    ADD CONSTRAINT company_knowledge_source_contracts_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_source_contracts company_knowledge_source_contracts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_source_contracts
    ADD CONSTRAINT company_knowledge_source_contracts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_knowledge_sources company_knowledge_sources_source_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_sources
    ADD CONSTRAINT company_knowledge_sources_source_contract_id_fkey FOREIGN KEY (source_contract_id) REFERENCES public.company_knowledge_source_contracts(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_sources company_knowledge_sources_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_sources
    ADD CONSTRAINT company_knowledge_sources_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_action_types company_ontology_action_types_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_action_types
    ADD CONSTRAINT company_ontology_action_types_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_action_types company_ontology_action_types_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_action_types
    ADD CONSTRAINT company_ontology_action_types_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_activations company_ontology_activations_activated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT company_ontology_activations_activated_by_user_id_fkey FOREIGN KEY (activated_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_activations company_ontology_activations_installation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT company_ontology_activations_installation_id_fkey FOREIGN KEY (installation_id) REFERENCES public.company_ontology_package_installations(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_activations company_ontology_activations_supersedes_activation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT company_ontology_activations_supersedes_activation_id_fkey FOREIGN KEY (supersedes_activation_id) REFERENCES public.company_ontology_activations(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_activations company_ontology_activations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_activations
    ADD CONSTRAINT company_ontology_activations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_assertions company_ontology_assertions_curation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_curation_run_id_fkey FOREIGN KEY (curation_run_id) REFERENCES public.company_ontology_curation_runs(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_assertions company_ontology_assertions_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_assertions company_ontology_assertions_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_assertions company_ontology_assertions_subject_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_subject_object_id_fkey FOREIGN KEY (subject_object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_assertions company_ontology_assertions_supersedes_assertion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_supersedes_assertion_id_fkey FOREIGN KEY (supersedes_assertion_id) REFERENCES public.company_ontology_assertions(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_assertions company_ontology_assertions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_assertions
    ADD CONSTRAINT company_ontology_assertions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_curation_runs company_ontology_curation_runs_accountable_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT company_ontology_curation_runs_accountable_user_id_fkey FOREIGN KEY (accountable_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_curation_runs company_ontology_curation_runs_activation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT company_ontology_curation_runs_activation_id_fkey FOREIGN KEY (activation_id) REFERENCES public.company_ontology_activations(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_curation_runs company_ontology_curation_runs_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT company_ontology_curation_runs_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: company_ontology_curation_runs company_ontology_curation_runs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT company_ontology_curation_runs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_event_types company_ontology_event_types_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_event_types
    ADD CONSTRAINT company_ontology_event_types_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_event_types company_ontology_event_types_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_event_types
    ADD CONSTRAINT company_ontology_event_types_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_events company_ontology_events_curation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT company_ontology_events_curation_run_id_fkey FOREIGN KEY (curation_run_id) REFERENCES public.company_ontology_curation_runs(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_events company_ontology_events_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT company_ontology_events_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_events company_ontology_events_subject_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT company_ontology_events_subject_object_id_fkey FOREIGN KEY (subject_object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_events company_ontology_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_events
    ADD CONSTRAINT company_ontology_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_evidence_bindings company_ontology_evidence_bindings_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_evidence_bindings
    ADD CONSTRAINT company_ontology_evidence_bindings_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.company_knowledge_evidence(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_evidence_bindings company_ontology_evidence_bindings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_evidence_bindings
    ADD CONSTRAINT company_ontology_evidence_bindings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_link_types company_ontology_link_types_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_link_types
    ADD CONSTRAINT company_ontology_link_types_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_link_types company_ontology_link_types_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_link_types
    ADD CONSTRAINT company_ontology_link_types_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_links company_ontology_links_curation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_curation_run_id_fkey FOREIGN KEY (curation_run_id) REFERENCES public.company_ontology_curation_runs(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_links company_ontology_links_from_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_from_object_id_fkey FOREIGN KEY (from_object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_links company_ontology_links_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_links company_ontology_links_supersedes_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_supersedes_link_id_fkey FOREIGN KEY (supersedes_link_id) REFERENCES public.company_ontology_links(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_links company_ontology_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_links company_ontology_links_to_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_links
    ADD CONSTRAINT company_ontology_links_to_object_id_fkey FOREIGN KEY (to_object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_object_identities company_ontology_object_identities_curation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT company_ontology_object_identities_curation_run_id_fkey FOREIGN KEY (curation_run_id) REFERENCES public.company_ontology_curation_runs(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_object_identities company_ontology_object_identities_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT company_ontology_object_identities_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_object_identities company_ontology_object_identities_source_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT company_ontology_object_identities_source_contract_id_fkey FOREIGN KEY (source_contract_id) REFERENCES public.company_knowledge_source_contracts(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_object_identities company_ontology_object_identities_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_identities
    ADD CONSTRAINT company_ontology_object_identities_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_object_types company_ontology_object_types_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_types
    ADD CONSTRAINT company_ontology_object_types_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_object_types company_ontology_object_types_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_object_types
    ADD CONSTRAINT company_ontology_object_types_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_objects company_ontology_objects_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_objects
    ADD CONSTRAINT company_ontology_objects_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_objects company_ontology_objects_supersedes_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_objects
    ADD CONSTRAINT company_ontology_objects_supersedes_object_id_fkey FOREIGN KEY (supersedes_object_id) REFERENCES public.company_ontology_objects(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_objects company_ontology_objects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_objects
    ADD CONSTRAINT company_ontology_objects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_package_installations company_ontology_package_installation_installed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_installations
    ADD CONSTRAINT company_ontology_package_installation_installed_by_user_id_fkey FOREIGN KEY (installed_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_package_installations company_ontology_package_installations_package_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_installations
    ADD CONSTRAINT company_ontology_package_installations_package_version_id_fkey FOREIGN KEY (package_version_id) REFERENCES public.company_ontology_package_versions(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_package_installations company_ontology_package_installations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_installations
    ADD CONSTRAINT company_ontology_package_installations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_package_versions company_ontology_package_versions_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_versions
    ADD CONSTRAINT company_ontology_package_versions_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.company_ontology_packages(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_package_versions company_ontology_package_versions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_package_versions
    ADD CONSTRAINT company_ontology_package_versions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_packages company_ontology_packages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_packages
    ADD CONSTRAINT company_ontology_packages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_property_types company_ontology_property_types_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_property_types
    ADD CONSTRAINT company_ontology_property_types_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_property_types company_ontology_property_types_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_property_types
    ADD CONSTRAINT company_ontology_property_types_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_release_items company_ontology_release_items_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_release_items
    ADD CONSTRAINT company_ontology_release_items_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_release_items company_ontology_release_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_release_items
    ADD CONSTRAINT company_ontology_release_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_releases company_ontology_releases_activation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_activation_id_fkey FOREIGN KEY (activation_id) REFERENCES public.company_ontology_activations(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_curation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_curation_run_id_fkey FOREIGN KEY (curation_run_id) REFERENCES public.company_ontology_curation_runs(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_package_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_package_version_id_fkey FOREIGN KEY (package_version_id) REFERENCES public.company_ontology_package_versions(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_proposal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_proposal_id_fkey FOREIGN KEY (proposal_id) REFERENCES public.company_knowledge_proposals(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_published_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_published_by_user_id_fkey FOREIGN KEY (published_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_restored_from_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_restored_from_release_id_fkey FOREIGN KEY (restored_from_release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_supersedes_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_supersedes_release_id_fkey FOREIGN KEY (supersedes_release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_releases company_ontology_releases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_releases
    ADD CONSTRAINT company_ontology_releases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_ontology_rule_definitions company_ontology_rule_definitions_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_rule_definitions
    ADD CONSTRAINT company_ontology_rule_definitions_release_id_fkey FOREIGN KEY (release_id) REFERENCES public.company_ontology_releases(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_rule_definitions company_ontology_rule_definitions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_rule_definitions
    ADD CONSTRAINT company_ontology_rule_definitions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: config_revisions config_revisions_changed_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_changed_by_agent_id_fkey FOREIGN KEY (changed_by_agent_id) REFERENCES public.agents(id);


--
-- Name: config_revisions config_revisions_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(id);


--
-- Name: config_revisions config_revisions_parent_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_parent_revision_id_fkey FOREIGN KEY (parent_revision_id) REFERENCES public.config_revisions(id) ON DELETE SET NULL;


--
-- Name: config_revisions config_revisions_rollback_of_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_rollback_of_revision_id_fkey FOREIGN KEY (rollback_of_revision_id) REFERENCES public.config_revisions(id) ON DELETE SET NULL;


--
-- Name: config_revisions config_revisions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_revisions
    ADD CONSTRAINT config_revisions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: coordination_checkpoints coordination_checkpoints_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_checkpoints
    ADD CONSTRAINT coordination_checkpoints_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: coordination_leases coordination_leases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_leases
    ADD CONSTRAINT coordination_leases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: coordination_signals coordination_signals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coordination_signals
    ADD CONSTRAINT coordination_signals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: decision_trace_feedback decision_trace_feedback_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_trace_feedback
    ADD CONSTRAINT decision_trace_feedback_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: decision_traces decision_traces_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_traces
    ADD CONSTRAINT decision_traces_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: decision_traces decision_traces_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_traces
    ADD CONSTRAINT decision_traces_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: decision_traces decision_traces_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decision_traces
    ADD CONSTRAINT decision_traces_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: departments departments_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id);


--
-- Name: departments departments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: enterprise_info enterprise_info_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_info
    ADD CONSTRAINT enterprise_info_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: enterprise_info enterprise_info_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_info
    ADD CONSTRAINT enterprise_info_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: external_capability_reviews external_capability_reviews_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_reviews
    ADD CONSTRAINT external_capability_reviews_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_capability_reviews external_capability_reviews_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_reviews
    ADD CONSTRAINT external_capability_reviews_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_capability_snapshots external_capability_snapshots_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT external_capability_snapshots_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_capability_snapshots external_capability_snapshots_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT external_capability_snapshots_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.external_capability_reviews(id) ON DELETE CASCADE;


--
-- Name: external_capability_snapshots external_capability_snapshots_revoked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT external_capability_snapshots_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_capability_snapshots external_capability_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_capability_snapshots
    ADD CONSTRAINT external_capability_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_extension_activations external_extension_activations_activated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_activated_by_user_id_fkey FOREIGN KEY (activated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_extension_activations external_extension_activations_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: external_extension_activations external_extension_activations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: external_extension_activations external_extension_activations_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE CASCADE;


--
-- Name: external_extension_activations external_extension_activations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_activations
    ADD CONSTRAINT external_extension_activations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_extension_catalog_entries external_extension_catalog_entries_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_catalog_entries
    ADD CONSTRAINT external_extension_catalog_entries_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE CASCADE;


--
-- Name: external_extension_catalog_entries external_extension_catalog_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_catalog_entries
    ADD CONSTRAINT external_extension_catalog_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_extension_components external_extension_components_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_components
    ADD CONSTRAINT external_extension_components_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE CASCADE;


--
-- Name: external_extension_components external_extension_components_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_components
    ADD CONSTRAINT external_extension_components_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_extension_hook_registrations external_extension_hook_registrations_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_hook_registrations
    ADD CONSTRAINT external_extension_hook_registrations_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.external_extension_components(id) ON DELETE CASCADE;


--
-- Name: external_extension_hook_registrations external_extension_hook_registrations_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_hook_registrations
    ADD CONSTRAINT external_extension_hook_registrations_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE CASCADE;


--
-- Name: external_extension_hook_registrations external_extension_hook_registrations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_extension_hook_registrations
    ADD CONSTRAINT external_extension_hook_registrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_identities external_identities_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT external_identities_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.identity_providers(id) ON DELETE CASCADE;


--
-- Name: external_identities external_identities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identities
    ADD CONSTRAINT external_identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: external_marketplace_entries external_marketplace_entries_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT external_marketplace_entries_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.external_capability_reviews(id) ON DELETE SET NULL;


--
-- Name: external_marketplace_entries external_marketplace_entries_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT external_marketplace_entries_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.external_capability_snapshots(id) ON DELETE SET NULL;


--
-- Name: external_marketplace_entries external_marketplace_entries_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT external_marketplace_entries_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.external_marketplace_sources(id) ON DELETE CASCADE;


--
-- Name: external_marketplace_entries external_marketplace_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_entries
    ADD CONSTRAINT external_marketplace_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_marketplace_sources external_marketplace_sources_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_sources
    ADD CONSTRAINT external_marketplace_sources_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_marketplace_sources external_marketplace_sources_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_marketplace_sources
    ADD CONSTRAINT external_marketplace_sources_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_principal_binding_events external_principal_binding_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_principal_binding_events external_principal_binding_events_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_external_principal_id_fkey FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE CASCADE;


--
-- Name: external_principal_binding_events external_principal_binding_events_new_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_new_user_id_fkey FOREIGN KEY (new_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_principal_binding_events external_principal_binding_events_previous_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_previous_user_id_fkey FOREIGN KEY (previous_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_principal_binding_events external_principal_binding_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principal_binding_events
    ADD CONSTRAINT external_principal_binding_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_principals external_principals_channel_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principals
    ADD CONSTRAINT external_principals_channel_config_id_fkey FOREIGN KEY (channel_config_id) REFERENCES public.channel_configs(id) ON DELETE SET NULL;


--
-- Name: external_principals external_principals_linked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principals
    ADD CONSTRAINT external_principals_linked_user_id_fkey FOREIGN KEY (linked_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: external_principals external_principals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_principals
    ADD CONSTRAINT external_principals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: feature_flags feature_flags_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: agent_templates fk_agent_templates_model_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT fk_agent_templates_model_tenant FOREIGN KEY (tenant_id, model_id) REFERENCES public.llm_models(tenant_id, id);


--
-- Name: agents fk_agents_fallback_model_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_fallback_model_tenant FOREIGN KEY (tenant_id, fallback_model_id) REFERENCES public.llm_models(tenant_id, id);


--
-- Name: agents fk_agents_primary_model_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_primary_model_tenant FOREIGN KEY (tenant_id, primary_model_id) REFERENCES public.llm_models(tenant_id, id);


--
-- Name: approval_requests fk_approval_requests_execution_task_id_runtime_tasks; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT fk_approval_requests_execution_task_id_runtime_tasks FOREIGN KEY (execution_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: audit_logs fk_audit_logs_external_principal_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_audit_logs_external_principal_id FOREIGN KEY (external_principal_id) REFERENCES public.external_principals(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_import_jobs fk_company_knowledge_import_job_proposal; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_import_jobs
    ADD CONSTRAINT fk_company_knowledge_import_job_proposal FOREIGN KEY (proposal_id) REFERENCES public.company_knowledge_proposals(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_proposals fk_company_knowledge_proposal_baseline_publication; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT fk_company_knowledge_proposal_baseline_publication FOREIGN KEY (baseline_publication_id) REFERENCES public.company_knowledge_publications(id) ON DELETE SET NULL;


--
-- Name: company_knowledge_proposals fk_company_knowledge_proposal_materialized_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT fk_company_knowledge_proposal_materialized_by FOREIGN KEY (materialized_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: company_knowledge_proposals fk_company_knowledge_proposal_materialized_document; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_knowledge_proposals
    ADD CONSTRAINT fk_company_knowledge_proposal_materialized_document FOREIGN KEY (materialized_document_id) REFERENCES public.knowledge_documents(id) ON DELETE RESTRICT;


--
-- Name: company_ontology_curation_runs fk_company_ontology_curation_baseline_release; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_ontology_curation_runs
    ADD CONSTRAINT fk_company_ontology_curation_baseline_release FOREIGN KEY (baseline_release_id) REFERENCES public.company_ontology_releases(id) ON DELETE SET NULL;


--
-- Name: hr_creation_drafts fk_hr_creation_drafts_provisioning_task_id_runtime_tasks; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT fk_hr_creation_drafts_provisioning_task_id_runtime_tasks FOREIGN KEY (provisioning_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: storage_blob_refs fk_storage_blob_refs_tenant_blob; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blob_refs
    ADD CONSTRAINT fk_storage_blob_refs_tenant_blob FOREIGN KEY (tenant_id, blob_id) REFERENCES public.storage_blobs(tenant_id, id) ON DELETE CASCADE;


--
-- Name: workflow_definitions fk_workflow_definitions_promotion_proposal_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT fk_workflow_definitions_promotion_proposal_id FOREIGN KEY (promotion_proposal_id) REFERENCES public.workflow_promotion_proposals(id) ON DELETE RESTRICT;


--
-- Name: guard_policies guard_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guard_policies
    ADD CONSTRAINT guard_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: hr_creation_drafts hr_creation_drafts_confirmed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_confirmed_by_user_id_fkey FOREIGN KEY (confirmed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hr_creation_drafts hr_creation_drafts_created_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_created_agent_id_fkey FOREIGN KEY (created_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: hr_creation_drafts hr_creation_drafts_hr_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_hr_agent_id_fkey FOREIGN KEY (hr_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: hr_creation_drafts hr_creation_drafts_rejected_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_rejected_by_user_id_fkey FOREIGN KEY (rejected_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hr_creation_drafts hr_creation_drafts_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hr_creation_drafts hr_creation_drafts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: hr_creation_drafts hr_creation_drafts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_creation_drafts
    ADD CONSTRAINT hr_creation_drafts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: hr_provisioning_steps hr_provisioning_steps_draft_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_provisioning_steps
    ADD CONSTRAINT hr_provisioning_steps_draft_id_fkey FOREIGN KEY (draft_id) REFERENCES public.hr_creation_drafts(id) ON DELETE CASCADE;


--
-- Name: hr_provisioning_steps hr_provisioning_steps_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hr_provisioning_steps
    ADD CONSTRAINT hr_provisioning_steps_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: identity_providers identity_providers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_providers
    ADD CONSTRAINT identity_providers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: invitation_codes invitation_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitation_codes
    ADD CONSTRAINT invitation_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invitation_codes invitation_codes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitation_codes
    ADD CONSTRAINT invitation_codes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: invocation_spans invocation_spans_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT invocation_spans_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: invocation_spans invocation_spans_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT invocation_spans_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id);


--
-- Name: invocation_spans invocation_spans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT invocation_spans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: invocation_spans invocation_spans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invocation_spans
    ADD CONSTRAINT invocation_spans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_assertions knowledge_assertions_object_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT knowledge_assertions_object_entity_id_fkey FOREIGN KEY (object_entity_id) REFERENCES public.knowledge_entities(id) ON DELETE SET NULL;


--
-- Name: knowledge_assertions knowledge_assertions_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT knowledge_assertions_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES public.knowledge_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_assertions knowledge_assertions_subject_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT knowledge_assertions_subject_entity_id_fkey FOREIGN KEY (subject_entity_id) REFERENCES public.knowledge_entities(id) ON DELETE SET NULL;


--
-- Name: knowledge_assertions knowledge_assertions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_assertions
    ADD CONSTRAINT knowledge_assertions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_documents knowledge_documents_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: knowledge_documents knowledge_documents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: knowledge_documents knowledge_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_entities knowledge_entities_merged_into_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT knowledge_entities_merged_into_entity_id_fkey FOREIGN KEY (merged_into_entity_id) REFERENCES public.knowledge_entities(id) ON DELETE SET NULL;


--
-- Name: knowledge_entities knowledge_entities_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT knowledge_entities_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_grants knowledge_grants_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: knowledge_grants knowledge_grants_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_grants knowledge_grants_requester_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_requester_user_id_fkey FOREIGN KEY (requester_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: knowledge_grants knowledge_grants_revoked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: knowledge_grants knowledge_grants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_grants
    ADD CONSTRAINT knowledge_grants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_index_jobs knowledge_index_jobs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_index_jobs
    ADD CONSTRAINT knowledge_index_jobs_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_index_jobs knowledge_index_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_index_jobs
    ADD CONSTRAINT knowledge_index_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_links knowledge_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT knowledge_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: knowledge_segments knowledge_segments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_segments
    ADD CONSTRAINT knowledge_segments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_segments knowledge_segments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_segments
    ADD CONSTRAINT knowledge_segments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: llm_models llm_models_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_bridge_connections local_agent_bridge_connections_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_connections
    ADD CONSTRAINT local_agent_bridge_connections_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_bridge_connections local_agent_bridge_connections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_connections
    ADD CONSTRAINT local_agent_bridge_connections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_bridge_connections local_agent_bridge_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_connections
    ADD CONSTRAINT local_agent_bridge_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: local_agent_bridge_pairing_sessions local_agent_bridge_pairing_sessions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT local_agent_bridge_pairing_sessions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_bridge_pairing_sessions local_agent_bridge_pairing_sessions_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT local_agent_bridge_pairing_sessions_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.local_agent_bridge_connections(id);


--
-- Name: local_agent_bridge_pairing_sessions local_agent_bridge_pairing_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT local_agent_bridge_pairing_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_bridge_pairing_sessions local_agent_bridge_pairing_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_bridge_pairing_sessions
    ADD CONSTRAINT local_agent_bridge_pairing_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: local_agent_capability_snapshots local_agent_capability_snapshots_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT local_agent_capability_snapshots_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.local_agent_channels(id) ON DELETE CASCADE;


--
-- Name: local_agent_capability_snapshots local_agent_capability_snapshots_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT local_agent_capability_snapshots_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.local_agent_bridge_connections(id) ON DELETE CASCADE;


--
-- Name: local_agent_capability_snapshots local_agent_capability_snapshots_subject_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT local_agent_capability_snapshots_subject_agent_id_fkey FOREIGN KEY (subject_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: local_agent_capability_snapshots local_agent_capability_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_capability_snapshots
    ADD CONSTRAINT local_agent_capability_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: local_agent_channel_events local_agent_channel_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.local_agent_channel_messages(id);


--
-- Name: local_agent_channel_events local_agent_channel_events_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channel_events local_agent_channel_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.local_agent_channel_sessions(id);


--
-- Name: local_agent_channel_events local_agent_channel_events_source_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_source_agent_id_fkey FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_channel_events local_agent_channel_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_events
    ADD CONSTRAINT local_agent_channel_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON DELETE SET NULL;


--
-- Name: local_agent_channel_messages local_agent_channel_messages_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_sender_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_sender_agent_id_fkey FOREIGN KEY (sender_agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_sender_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_sender_user_id_fkey FOREIGN KEY (sender_user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.local_agent_channel_sessions(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_source_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_source_agent_id_fkey FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_channel_messages local_agent_channel_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_messages
    ADD CONSTRAINT local_agent_channel_messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.local_agent_channels(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_chat_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_chat_session_id_fkey FOREIGN KEY (chat_session_id) REFERENCES public.chat_sessions(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.local_agent_bridge_connections(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_source_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_source_agent_id_fkey FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: local_agent_channel_sessions local_agent_channel_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_sessions
    ADD CONSTRAINT local_agent_channel_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_channel_ws_tickets local_agent_channel_ws_tickets_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_ws_tickets
    ADD CONSTRAINT local_agent_channel_ws_tickets_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.local_agent_bridge_connections(id);


--
-- Name: local_agent_channel_ws_tickets local_agent_channel_ws_tickets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_ws_tickets
    ADD CONSTRAINT local_agent_channel_ws_tickets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: local_agent_channel_ws_tickets local_agent_channel_ws_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channel_ws_tickets
    ADD CONSTRAINT local_agent_channel_ws_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channels local_agent_channels_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channels
    ADD CONSTRAINT local_agent_channels_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.local_agent_bridge_connections(id);


--
-- Name: local_agent_channels local_agent_channels_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channels
    ADD CONSTRAINT local_agent_channels_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: local_agent_channels local_agent_channels_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_agent_channels
    ADD CONSTRAINT local_agent_channels_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: mcp_server_tools mcp_server_tools_mcp_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_tools
    ADD CONSTRAINT mcp_server_tools_mcp_server_id_fkey FOREIGN KEY (mcp_server_id) REFERENCES public.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: mcp_server_tools mcp_server_tools_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_tools
    ADD CONSTRAINT mcp_server_tools_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: mcp_server_tools mcp_server_tools_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_server_tools
    ADD CONSTRAINT mcp_server_tools_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.tools(id) ON DELETE CASCADE;


--
-- Name: mcp_servers mcp_servers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: org_departments org_departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_departments
    ADD CONSTRAINT org_departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.org_departments(id);


--
-- Name: org_departments org_departments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_departments
    ADD CONSTRAINT org_departments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: org_members org_members_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.org_departments(id);


--
-- Name: org_members org_members_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.identity_providers(id);


--
-- Name: org_members org_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: pending_reply_contexts pending_reply_contexts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_reply_contexts
    ADD CONSTRAINT pending_reply_contexts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: pending_reply_contexts pending_reply_contexts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_reply_contexts
    ADD CONSTRAINT pending_reply_contexts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_baseline_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_baseline_document_id_fkey FOREIGN KEY (baseline_document_id) REFERENCES public.knowledge_documents(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_baseline_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_baseline_revision_id_fkey FOREIGN KEY (baseline_revision_id) REFERENCES public.config_revisions(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_delegated_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_delegated_by_agent_id_fkey FOREIGN KEY (delegated_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_documents(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_proposed_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_proposed_by_agent_id_fkey FOREIGN KEY (proposed_by_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_reviewed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_reviewed_by_user_id_fkey FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_revision_id_fkey FOREIGN KEY (revision_id) REFERENCES public.config_revisions(id) ON DELETE SET NULL;


--
-- Name: personal_knowledge_proposals personal_knowledge_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_knowledge_proposals
    ADD CONSTRAINT personal_knowledge_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: plaza_comments plaza_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plaza_comments
    ADD CONSTRAINT plaza_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.plaza_posts(id);


--
-- Name: plaza_likes plaza_likes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plaza_likes
    ADD CONSTRAINT plaza_likes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.plaza_posts(id);


--
-- Name: plugin_dependency_edges plugin_dependency_edges_dependency_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_dependency_edges
    ADD CONSTRAINT plugin_dependency_edges_dependency_plugin_id_fkey FOREIGN KEY (dependency_plugin_id) REFERENCES public.tenant_installed_plugins(id) ON DELETE RESTRICT;


--
-- Name: plugin_dependency_edges plugin_dependency_edges_installed_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_dependency_edges
    ADD CONSTRAINT plugin_dependency_edges_installed_plugin_id_fkey FOREIGN KEY (installed_plugin_id) REFERENCES public.tenant_installed_plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_dependency_edges plugin_dependency_edges_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_dependency_edges
    ADD CONSTRAINT plugin_dependency_edges_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: plugin_hook_registrations plugin_hook_registrations_installed_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_hook_registrations
    ADD CONSTRAINT plugin_hook_registrations_installed_plugin_id_fkey FOREIGN KEY (installed_plugin_id) REFERENCES public.tenant_installed_plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_hook_registrations plugin_hook_registrations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_hook_registrations
    ADD CONSTRAINT plugin_hook_registrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: resource_permissions resource_permissions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_permissions
    ADD CONSTRAINT resource_permissions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: resource_permissions resource_permissions_revoked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_permissions
    ADD CONSTRAINT resource_permissions_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: resource_permissions resource_permissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_permissions
    ADD CONSTRAINT resource_permissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_budget_events runtime_budget_events_budget_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_events
    ADD CONSTRAINT runtime_budget_events_budget_run_id_fkey FOREIGN KEY (budget_run_id) REFERENCES public.runtime_budget_runs(id) ON DELETE CASCADE;


--
-- Name: runtime_budget_events runtime_budget_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_events
    ADD CONSTRAINT runtime_budget_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_budget_policies runtime_budget_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_policies
    ADD CONSTRAINT runtime_budget_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_budget_runs runtime_budget_runs_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_runs
    ADD CONSTRAINT runtime_budget_runs_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.runtime_budget_policies(id);


--
-- Name: runtime_budget_runs runtime_budget_runs_root_external_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_runs
    ADD CONSTRAINT runtime_budget_runs_root_external_principal_id_fkey FOREIGN KEY (root_external_principal_id) REFERENCES public.external_principals(id) ON DELETE SET NULL;


--
-- Name: runtime_budget_runs runtime_budget_runs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_budget_runs
    ADD CONSTRAINT runtime_budget_runs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_notification_outbox runtime_notification_outbox_child_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_child_session_id_fkey FOREIGN KEY (child_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_integration_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_integration_page_id_fkey FOREIGN KEY (integration_page_id) REFERENCES public.runtime_result_integration_pages(id) ON DELETE SET NULL;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_parent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_parent_agent_id_fkey FOREIGN KEY (parent_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_parent_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_parent_user_id_fkey FOREIGN KEY (parent_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_result_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_result_object_id_fkey FOREIGN KEY (result_object_id) REFERENCES public.runtime_result_objects(id) ON DELETE RESTRICT;


--
-- Name: runtime_notification_outbox runtime_notification_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_notification_outbox
    ADD CONSTRAINT runtime_notification_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: runtime_result_integration_pages runtime_result_integration_pages_parent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT runtime_result_integration_pages_parent_agent_id_fkey FOREIGN KEY (parent_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: runtime_result_integration_pages runtime_result_integration_pages_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT runtime_result_integration_pages_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: runtime_result_integration_pages runtime_result_integration_pages_parent_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT runtime_result_integration_pages_parent_user_id_fkey FOREIGN KEY (parent_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: runtime_result_integration_pages runtime_result_integration_pages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_integration_pages
    ADD CONSTRAINT runtime_result_integration_pages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: runtime_result_mailbox_cursors runtime_result_mailbox_cursors_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_mailbox_cursors
    ADD CONSTRAINT runtime_result_mailbox_cursors_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: runtime_result_mailbox_cursors runtime_result_mailbox_cursors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_mailbox_cursors
    ADD CONSTRAINT runtime_result_mailbox_cursors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: runtime_result_objects runtime_result_objects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_result_objects
    ADD CONSTRAINT runtime_result_objects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: runtime_root_items runtime_root_items_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_root_items
    ADD CONSTRAINT runtime_root_items_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: runtime_root_items runtime_root_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_root_items
    ADD CONSTRAINT runtime_root_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_tasks runtime_tasks_budget_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_tasks
    ADD CONSTRAINT runtime_tasks_budget_run_id_fkey FOREIGN KEY (budget_run_id) REFERENCES public.runtime_budget_runs(id);


--
-- Name: runtime_tasks runtime_tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_tasks
    ADD CONSTRAINT runtime_tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: runtime_terminal_boundary_outbox runtime_terminal_boundary_outbox_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT runtime_terminal_boundary_outbox_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: runtime_terminal_boundary_outbox runtime_terminal_boundary_outbox_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT runtime_terminal_boundary_outbox_runtime_task_id_fkey FOREIGN KEY (runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: runtime_terminal_boundary_outbox runtime_terminal_boundary_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.runtime_terminal_boundary_outbox
    ADD CONSTRAINT runtime_terminal_boundary_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: security_audit_events security_audit_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_audit_events
    ADD CONSTRAINT security_audit_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: session_carry_forwards session_carry_forwards_consumed_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_consumed_event_id_fkey FOREIGN KEY (consumed_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: session_carry_forwards session_carry_forwards_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_carry_forwards session_carry_forwards_source_admission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_source_admission_id_fkey FOREIGN KEY (source_admission_id) REFERENCES public.session_input_admissions(id) ON DELETE CASCADE;


--
-- Name: session_carry_forwards session_carry_forwards_source_input_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_source_input_id_fkey FOREIGN KEY (source_input_id) REFERENCES public.session_turn_inputs(id) ON DELETE CASCADE;


--
-- Name: session_carry_forwards session_carry_forwards_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_carry_forwards
    ADD CONSTRAINT session_carry_forwards_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_commands session_commands_causation_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_commands
    ADD CONSTRAINT session_commands_causation_command_id_fkey FOREIGN KEY (causation_command_id) REFERENCES public.session_commands(id);


--
-- Name: session_commands session_commands_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_commands
    ADD CONSTRAINT session_commands_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_commands session_commands_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_commands
    ADD CONSTRAINT session_commands_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_control_inputs session_control_inputs_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT session_control_inputs_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.session_commands(id) ON DELETE CASCADE;


--
-- Name: session_control_inputs session_control_inputs_expected_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT session_control_inputs_expected_run_id_fkey FOREIGN KEY (expected_run_id) REFERENCES public.runtime_tasks(id);


--
-- Name: session_control_inputs session_control_inputs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT session_control_inputs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_control_inputs session_control_inputs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_control_inputs
    ADD CONSTRAINT session_control_inputs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_event_cursors session_event_cursors_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_cursors
    ADD CONSTRAINT session_event_cursors_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_event_cursors session_event_cursors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_cursors
    ADD CONSTRAINT session_event_cursors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_event_outbox session_event_outbox_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT session_event_outbox_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.chat_transcript_events(id) ON DELETE CASCADE;


--
-- Name: session_event_outbox session_event_outbox_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT session_event_outbox_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_event_outbox session_event_outbox_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_event_outbox
    ADD CONSTRAINT session_event_outbox_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_feedback_aggregates session_feedback_aggregates_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_aggregates
    ADD CONSTRAINT session_feedback_aggregates_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_feedback_aggregates session_feedback_aggregates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_aggregates
    ADD CONSTRAINT session_feedback_aggregates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_feedback_events session_feedback_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: session_feedback_events session_feedback_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id);


--
-- Name: session_feedback_events session_feedback_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- Name: session_feedback_events session_feedback_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: session_feedback_events session_feedback_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_feedback_events
    ADD CONSTRAINT session_feedback_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: session_input_admissions session_input_admissions_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT session_input_admissions_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.session_commands(id) ON DELETE CASCADE;


--
-- Name: session_input_admissions session_input_admissions_input_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT session_input_admissions_input_id_fkey FOREIGN KEY (input_id) REFERENCES public.session_turn_inputs(id) ON DELETE CASCADE;


--
-- Name: session_input_admissions session_input_admissions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT session_input_admissions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_input_admissions session_input_admissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_input_admissions
    ADD CONSTRAINT session_input_admissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_model_results session_model_results_round_committed_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT session_model_results_round_committed_event_id_fkey FOREIGN KEY (round_committed_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: session_model_results session_model_results_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT session_model_results_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: session_model_results session_model_results_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT session_model_results_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_model_results session_model_results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_model_results
    ADD CONSTRAINT session_model_results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_next_round_plans session_next_round_plans_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT session_next_round_plans_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: session_next_round_plans session_next_round_plans_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT session_next_round_plans_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_next_round_plans session_next_round_plans_source_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT session_next_round_plans_source_result_id_fkey FOREIGN KEY (source_result_id) REFERENCES public.session_model_results(id) ON DELETE CASCADE;


--
-- Name: session_next_round_plans session_next_round_plans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_next_round_plans
    ADD CONSTRAINT session_next_round_plans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_round_obligations session_round_obligations_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT session_round_obligations_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: session_round_obligations session_round_obligations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT session_round_obligations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_round_obligations session_round_obligations_source_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT session_round_obligations_source_result_id_fkey FOREIGN KEY (source_result_id) REFERENCES public.session_model_results(id) ON DELETE CASCADE;


--
-- Name: session_round_obligations session_round_obligations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_round_obligations
    ADD CONSTRAINT session_round_obligations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_run_outcomes session_run_outcomes_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: session_run_outcomes session_run_outcomes_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_run_outcomes session_run_outcomes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_run_outcomes session_run_outcomes_terminal_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_terminal_event_id_fkey FOREIGN KEY (terminal_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: session_run_outcomes session_run_outcomes_terminal_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_run_outcomes
    ADD CONSTRAINT session_run_outcomes_terminal_result_id_fkey FOREIGN KEY (terminal_result_id) REFERENCES public.session_model_results(id);


--
-- Name: session_tool_invocations session_tool_invocations_result_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_result_event_id_fkey FOREIGN KEY (result_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: session_tool_invocations session_tool_invocations_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: session_tool_invocations session_tool_invocations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_tool_invocations session_tool_invocations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_tool_invocations
    ADD CONSTRAINT session_tool_invocations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_turn_inputs session_turn_inputs_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT session_turn_inputs_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.session_commands(id) ON DELETE CASCADE;


--
-- Name: session_turn_inputs session_turn_inputs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT session_turn_inputs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_turn_inputs session_turn_inputs_target_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT session_turn_inputs_target_run_id_fkey FOREIGN KEY (target_run_id) REFERENCES public.runtime_tasks(id);


--
-- Name: session_turn_inputs session_turn_inputs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_inputs
    ADD CONSTRAINT session_turn_inputs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: session_turn_replacements session_turn_replacements_cancel_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_cancel_command_id_fkey FOREIGN KEY (cancel_command_id) REFERENCES public.session_commands(id);


--
-- Name: session_turn_replacements session_turn_replacements_command_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_command_id_fkey FOREIGN KEY (command_id) REFERENCES public.session_commands(id) ON DELETE CASCADE;


--
-- Name: session_turn_replacements session_turn_replacements_last_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_last_event_id_fkey FOREIGN KEY (last_event_id) REFERENCES public.chat_transcript_events(id);


--
-- Name: session_turn_replacements session_turn_replacements_old_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_old_run_id_fkey FOREIGN KEY (old_run_id) REFERENCES public.runtime_tasks(id);


--
-- Name: session_turn_replacements session_turn_replacements_replacement_input_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_replacement_input_id_fkey FOREIGN KEY (replacement_input_id) REFERENCES public.session_turn_inputs(id);


--
-- Name: session_turn_replacements session_turn_replacements_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: session_turn_replacements session_turn_replacements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session_turn_replacements
    ADD CONSTRAINT session_turn_replacements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: skill_files skill_files_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_files
    ADD CONSTRAINT skill_files_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(id);


--
-- Name: skills skills_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sso_scan_sessions sso_scan_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_scan_sessions
    ADD CONSTRAINT sso_scan_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: sso_scan_sessions sso_scan_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_scan_sessions
    ADD CONSTRAINT sso_scan_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_blob_refs storage_blob_refs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blob_refs
    ADD CONSTRAINT storage_blob_refs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: storage_blobs storage_blobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_blobs
    ADD CONSTRAINT storage_blobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: storage_gc_runs storage_gc_runs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_gc_runs
    ADD CONSTRAINT storage_gc_runs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: task_logs task_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_logs task_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: tasks tasks_active_runtime_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_active_runtime_task_id_fkey FOREIGN KEY (active_runtime_task_id) REFERENCES public.runtime_tasks(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: tenant_channel_configs tenant_channel_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_channel_configs
    ADD CONSTRAINT tenant_channel_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: tenant_installed_plugins tenant_installed_plugins_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_installed_plugins
    ADD CONSTRAINT tenant_installed_plugins_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_scope_quarantine_records tenant_scope_quarantine_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_scope_quarantine_records
    ADD CONSTRAINT tenant_scope_quarantine_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE RESTRICT;


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_tool_configs tenant_tool_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_tool_configs
    ADD CONSTRAINT tenant_tool_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_tool_configs tenant_tool_configs_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_tool_configs
    ADD CONSTRAINT tenant_tool_configs_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.tools(id) ON DELETE CASCADE;


--
-- Name: token_usage_events token_usage_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage_events
    ADD CONSTRAINT token_usage_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: token_usage_events token_usage_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage_events
    ADD CONSTRAINT token_usage_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: token_usage_events token_usage_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage_events
    ADD CONSTRAINT token_usage_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tools tools_mcp_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_mcp_reviewed_by_fkey FOREIGN KEY (mcp_reviewed_by) REFERENCES public.users(id);


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workflow_definitions workflow_definitions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT workflow_definitions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workflow_leaf_calls workflow_leaf_calls_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_leaf_calls
    ADD CONSTRAINT workflow_leaf_calls_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: workflow_leaf_calls workflow_leaf_calls_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_leaf_calls
    ADD CONSTRAINT workflow_leaf_calls_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_confirmed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_confirmed_by_user_id_fkey FOREIGN KEY (confirmed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_proposal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_proposal_id_fkey FOREIGN KEY (proposal_id) REFERENCES public.workflow_proposal_artifacts(id) ON DELETE SET NULL;


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: workflow_preview_artifacts workflow_preview_artifacts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_preview_artifacts
    ADD CONSTRAINT workflow_preview_artifacts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE RESTRICT;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_requester_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_requester_user_id_fkey FOREIGN KEY (requester_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_reviewer_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_reviewer_user_id_fkey FOREIGN KEY (reviewer_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id) ON DELETE RESTRICT;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE RESTRICT;


--
-- Name: workflow_promotion_proposals workflow_promotion_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_promotion_proposals
    ADD CONSTRAINT workflow_promotion_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: workflow_proposal_artifacts workflow_proposal_artifacts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_proposal_artifacts
    ADD CONSTRAINT workflow_proposal_artifacts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: workflow_proposal_artifacts workflow_proposal_artifacts_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_proposal_artifacts
    ADD CONSTRAINT workflow_proposal_artifacts_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workflow_proposal_artifacts workflow_proposal_artifacts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_proposal_artifacts
    ADD CONSTRAINT workflow_proposal_artifacts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- Name: workflow_proposal_artifacts workflow_proposal_artifacts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_proposal_artifacts
    ADD CONSTRAINT workflow_proposal_artifacts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: workflow_quotas workflow_quotas_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_quotas
    ADD CONSTRAINT workflow_quotas_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: workflow_quotas workflow_quotas_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_quotas
    ADD CONSTRAINT workflow_quotas_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workflow_steps workflow_steps_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.runtime_tasks(id) ON DELETE CASCADE;


--
-- Name: workflow_steps workflow_steps_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: workspace_resource_manifests workspace_resource_manifests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT workspace_resource_manifests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: workspace_resource_manifests workspace_resource_manifests_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT workspace_resource_manifests_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: workspace_resource_manifests workspace_resource_manifests_root_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT workspace_resource_manifests_root_session_id_fkey FOREIGN KEY (root_session_id) REFERENCES public.chat_sessions(id) ON DELETE SET NULL;


--
-- Name: workspace_resource_manifests workspace_resource_manifests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_resource_manifests
    ADD CONSTRAINT workspace_resource_manifests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agent_activity_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_capability_installs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_capability_installs ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_collaboration_group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_collaboration_group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_collaboration_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_collaboration_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_mcp_server_assignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_mcp_server_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_mcp_tool_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_mcp_tool_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_plan_recommendations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_plan_recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_plan_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_plan_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_plugin_assignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_plugin_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_relationships; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_relationships ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_session_goals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_session_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_team_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_team_events ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_team_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_teams ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_tools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_tools ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_triggers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_triggers ENABLE ROW LEVEL SECURITY;

--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: ai_asset_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ai_asset_records ENABLE ROW LEVEL SECURITY;

--
-- Name: ai_asset_usage_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ai_asset_usage_events ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: budget_transition_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budget_transition_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: capability_factor_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.capability_factor_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: capability_factors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.capability_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: capability_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.capability_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: capability_promotion_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.capability_promotion_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_delivery_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_delivery_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_ingress_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channel_ingress_events ENABLE ROW LEVEL SECURITY;

--
-- Name: charter_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.charter_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_transcript_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_transcript_events ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_events ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_evidence; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_evidence ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_import_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_import_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_publications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_publications ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_source_contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_source_contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: company_knowledge_sources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_knowledge_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_action_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_action_types ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_activations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_activations ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_assertions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_assertions ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_curation_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_curation_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_event_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_event_types ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_events ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_evidence_bindings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_evidence_bindings ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_link_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_link_types ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_links ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_object_identities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_object_identities ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_object_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_object_types ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_objects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_objects ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_package_installations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_package_installations ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_package_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_package_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_packages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_packages ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_property_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_property_types ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_release_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_release_items ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_releases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_releases ENABLE ROW LEVEL SECURITY;

--
-- Name: company_ontology_rule_definitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_ontology_rule_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: config_revisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.config_revisions ENABLE ROW LEVEL SECURITY;

--
-- Name: coordination_checkpoints; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coordination_checkpoints ENABLE ROW LEVEL SECURITY;

--
-- Name: coordination_leases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coordination_leases ENABLE ROW LEVEL SECURITY;

--
-- Name: coordination_signals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coordination_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_trace_feedback; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_trace_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: decision_traces; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decision_traces ENABLE ROW LEVEL SECURITY;

--
-- Name: departments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

--
-- Name: enterprise_info; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.enterprise_info ENABLE ROW LEVEL SECURITY;

--
-- Name: external_capability_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_capability_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: external_capability_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_capability_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: external_extension_activations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_extension_activations ENABLE ROW LEVEL SECURITY;

--
-- Name: external_extension_catalog_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_extension_catalog_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: external_extension_components; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_extension_components ENABLE ROW LEVEL SECURITY;

--
-- Name: external_extension_hook_registrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_extension_hook_registrations ENABLE ROW LEVEL SECURITY;

--
-- Name: external_identities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_identities ENABLE ROW LEVEL SECURITY;

--
-- Name: external_marketplace_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_marketplace_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: external_marketplace_sources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_marketplace_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: external_principal_binding_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_principal_binding_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_principals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_principals ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: guard_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.guard_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: hr_creation_drafts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hr_creation_drafts ENABLE ROW LEVEL SECURITY;

--
-- Name: hr_provisioning_steps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hr_provisioning_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: identity_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.identity_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: invitation_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invitation_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: invocation_spans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invocation_spans ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_assertions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_assertions ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_entities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_entities ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_index_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_index_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_links ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_segments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.knowledge_segments ENABLE ROW LEVEL SECURITY;

--
-- Name: llm_models; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.llm_models ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_bridge_connections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_bridge_connections ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_bridge_pairing_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_bridge_pairing_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_capability_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_capability_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_channel_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_channel_events ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_channel_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_channel_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_channel_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_channel_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_channel_ws_tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_channel_ws_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: local_agent_channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.local_agent_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_server_tools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_server_tools ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_servers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_servers ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: org_departments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_departments ENABLE ROW LEVEL SECURITY;

--
-- Name: org_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;

--
-- Name: participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

--
-- Name: pending_reply_contexts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pending_reply_contexts ENABLE ROW LEVEL SECURITY;

--
-- Name: personal_knowledge_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.personal_knowledge_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: plaza_comments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plaza_comments ENABLE ROW LEVEL SECURITY;

--
-- Name: plaza_likes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plaza_likes ENABLE ROW LEVEL SECURITY;

--
-- Name: plaza_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plaza_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: plugin_dependency_edges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plugin_dependency_edges ENABLE ROW LEVEL SECURITY;

--
-- Name: plugin_hook_registrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plugin_hook_registrations ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: resource_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.resource_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_budget_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_budget_events ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_budget_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_budget_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_budget_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_budget_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_notification_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_notification_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_result_integration_pages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_result_integration_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_result_mailbox_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_result_mailbox_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_result_objects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_result_objects ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_root_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_root_items ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: runtime_terminal_boundary_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.runtime_terminal_boundary_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: security_audit_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_audit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: session_carry_forwards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_carry_forwards ENABLE ROW LEVEL SECURITY;

--
-- Name: session_commands; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_commands ENABLE ROW LEVEL SECURITY;

--
-- Name: session_control_inputs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_control_inputs ENABLE ROW LEVEL SECURITY;

--
-- Name: session_event_cursors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_event_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: session_event_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_event_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: session_feedback_aggregates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_feedback_aggregates ENABLE ROW LEVEL SECURITY;

--
-- Name: session_feedback_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_feedback_events ENABLE ROW LEVEL SECURITY;

--
-- Name: session_input_admissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_input_admissions ENABLE ROW LEVEL SECURITY;

--
-- Name: session_model_results; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_model_results ENABLE ROW LEVEL SECURITY;

--
-- Name: session_next_round_plans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_next_round_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: session_round_obligations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_round_obligations ENABLE ROW LEVEL SECURITY;

--
-- Name: session_run_outcomes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_run_outcomes ENABLE ROW LEVEL SECURITY;

--
-- Name: session_tool_invocations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_tool_invocations ENABLE ROW LEVEL SECURITY;

--
-- Name: session_turn_inputs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_turn_inputs ENABLE ROW LEVEL SECURITY;

--
-- Name: session_turn_replacements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.session_turn_replacements ENABLE ROW LEVEL SECURITY;

--
-- Name: skill_files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skill_files ENABLE ROW LEVEL SECURITY;

--
-- Name: skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_scan_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sso_scan_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: storage_blob_refs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.storage_blob_refs ENABLE ROW LEVEL SECURITY;

--
-- Name: storage_blobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.storage_blobs ENABLE ROW LEVEL SECURITY;

--
-- Name: storage_gc_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.storage_gc_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: system_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: task_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.task_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_channel_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_channel_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_installed_plugins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_installed_plugins ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_activity_logs tenant_isolation_agent_activity_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_activity_logs ON public.agent_activity_logs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_capability_installs tenant_isolation_agent_capability_installs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_capability_installs ON public.agent_capability_installs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_collaboration_group_members tenant_isolation_agent_collaboration_group_members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_collaboration_group_members ON public.agent_collaboration_group_members USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_collaboration_groups tenant_isolation_agent_collaboration_groups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_collaboration_groups ON public.agent_collaboration_groups USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_mcp_server_assignments tenant_isolation_agent_mcp_server_assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_mcp_server_assignments ON public.agent_mcp_server_assignments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_mcp_tool_overrides tenant_isolation_agent_mcp_tool_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_mcp_tool_overrides ON public.agent_mcp_tool_overrides USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_permissions tenant_isolation_agent_permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_permissions ON public.agent_permissions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_plan_recommendations tenant_isolation_agent_plan_recommendations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_plan_recommendations ON public.agent_plan_recommendations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_plan_requests tenant_isolation_agent_plan_requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_plan_requests ON public.agent_plan_requests USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_plugin_assignments tenant_isolation_agent_plugin_assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_plugin_assignments ON public.agent_plugin_assignments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_relationships tenant_isolation_agent_relationships; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_relationships ON public.agent_relationships USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_schedules tenant_isolation_agent_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_schedules ON public.agent_schedules USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_session_goals tenant_isolation_agent_session_goals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_session_goals ON public.agent_session_goals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_team_events tenant_isolation_agent_team_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_team_events ON public.agent_team_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.agent_teams
  WHERE ((agent_teams.id = agent_team_events.team_id) AND ((agent_teams.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.agent_teams
  WHERE ((agent_teams.id = agent_team_events.team_id) AND ((agent_teams.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: agent_team_members tenant_isolation_agent_team_members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_team_members ON public.agent_team_members USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.agent_teams
  WHERE ((agent_teams.id = agent_team_members.team_id) AND ((agent_teams.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.agent_teams
  WHERE ((agent_teams.id = agent_team_members.team_id) AND ((agent_teams.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: agent_teams tenant_isolation_agent_teams; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_teams ON public.agent_teams USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_templates tenant_isolation_agent_templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_templates ON public.agent_templates USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((tenant_id IS NULL) AND (is_builtin IS TRUE)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_tools tenant_isolation_agent_tools; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_tools ON public.agent_tools USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agent_triggers tenant_isolation_agent_triggers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agent_triggers ON public.agent_triggers USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: agents tenant_isolation_agents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_agents ON public.agents USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: ai_asset_records tenant_isolation_ai_asset_records; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_ai_asset_records ON public.ai_asset_records USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: ai_asset_usage_events tenant_isolation_ai_asset_usage_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_ai_asset_usage_events ON public.ai_asset_usage_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: approval_requests tenant_isolation_approval_requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_approval_requests ON public.approval_requests USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: audit_logs tenant_isolation_audit_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_audit_logs ON public.audit_logs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: budget_transition_outbox tenant_isolation_budget_transition_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_budget_transition_outbox ON public.budget_transition_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: capability_factor_reviews tenant_isolation_capability_factor_reviews; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_capability_factor_reviews ON public.capability_factor_reviews USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: capability_factors tenant_isolation_capability_factors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_capability_factors ON public.capability_factors USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: capability_policies tenant_isolation_capability_policies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_capability_policies ON public.capability_policies USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: capability_promotion_proposals tenant_isolation_capability_promotion_proposals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_capability_promotion_proposals ON public.capability_promotion_proposals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: channel_configs tenant_isolation_channel_configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_channel_configs ON public.channel_configs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: channel_delivery_outbox tenant_isolation_channel_delivery_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_channel_delivery_outbox ON public.channel_delivery_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: channel_ingress_events tenant_isolation_channel_ingress_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_channel_ingress_events ON public.channel_ingress_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: charter_proposals tenant_isolation_charter_proposals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_charter_proposals ON public.charter_proposals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: chat_artifacts tenant_isolation_chat_artifacts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_chat_artifacts ON public.chat_artifacts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: chat_messages tenant_isolation_chat_messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_chat_messages ON public.chat_messages USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: chat_sessions tenant_isolation_chat_sessions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_chat_sessions ON public.chat_sessions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: chat_transcript_events tenant_isolation_chat_transcript_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_chat_transcript_events ON public.chat_transcript_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_events tenant_isolation_company_knowledge_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_events ON public.company_knowledge_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_evidence tenant_isolation_company_knowledge_evidence; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_evidence ON public.company_knowledge_evidence USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_import_jobs tenant_isolation_company_knowledge_import_jobs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_import_jobs ON public.company_knowledge_import_jobs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_outbox tenant_isolation_company_knowledge_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_outbox ON public.company_knowledge_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_proposals tenant_isolation_company_knowledge_proposals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_proposals ON public.company_knowledge_proposals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_publications tenant_isolation_company_knowledge_publications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_publications ON public.company_knowledge_publications USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_reviews tenant_isolation_company_knowledge_reviews; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_reviews ON public.company_knowledge_reviews USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_source_contracts tenant_isolation_company_knowledge_source_contracts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_source_contracts ON public.company_knowledge_source_contracts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_knowledge_sources tenant_isolation_company_knowledge_sources; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_knowledge_sources ON public.company_knowledge_sources USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_action_types tenant_isolation_company_ontology_action_types; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_action_types ON public.company_ontology_action_types USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_activations tenant_isolation_company_ontology_activations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_activations ON public.company_ontology_activations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_assertions tenant_isolation_company_ontology_assertions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_assertions ON public.company_ontology_assertions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_curation_runs tenant_isolation_company_ontology_curation_runs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_curation_runs ON public.company_ontology_curation_runs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_event_types tenant_isolation_company_ontology_event_types; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_event_types ON public.company_ontology_event_types USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_events tenant_isolation_company_ontology_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_events ON public.company_ontology_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_evidence_bindings tenant_isolation_company_ontology_evidence_bindings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_evidence_bindings ON public.company_ontology_evidence_bindings USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_link_types tenant_isolation_company_ontology_link_types; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_link_types ON public.company_ontology_link_types USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_links tenant_isolation_company_ontology_links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_links ON public.company_ontology_links USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_object_identities tenant_isolation_company_ontology_object_identities; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_object_identities ON public.company_ontology_object_identities USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_object_types tenant_isolation_company_ontology_object_types; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_object_types ON public.company_ontology_object_types USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_objects tenant_isolation_company_ontology_objects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_objects ON public.company_ontology_objects USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_package_installations tenant_isolation_company_ontology_package_installations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_package_installations ON public.company_ontology_package_installations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_package_versions tenant_isolation_company_ontology_package_versions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_package_versions ON public.company_ontology_package_versions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_packages tenant_isolation_company_ontology_packages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_packages ON public.company_ontology_packages USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_property_types tenant_isolation_company_ontology_property_types; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_property_types ON public.company_ontology_property_types USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_release_items tenant_isolation_company_ontology_release_items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_release_items ON public.company_ontology_release_items USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_releases tenant_isolation_company_ontology_releases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_releases ON public.company_ontology_releases USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: company_ontology_rule_definitions tenant_isolation_company_ontology_rule_definitions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_company_ontology_rule_definitions ON public.company_ontology_rule_definitions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: config_revisions tenant_isolation_config_revisions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_config_revisions ON public.config_revisions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: coordination_checkpoints tenant_isolation_coordination_checkpoints; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_coordination_checkpoints ON public.coordination_checkpoints USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: coordination_leases tenant_isolation_coordination_leases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_coordination_leases ON public.coordination_leases USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: coordination_signals tenant_isolation_coordination_signals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_coordination_signals ON public.coordination_signals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: decision_trace_feedback tenant_isolation_decision_trace_feedback; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_decision_trace_feedback ON public.decision_trace_feedback USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: decision_traces tenant_isolation_decision_traces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_decision_traces ON public.decision_traces USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: departments tenant_isolation_departments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_departments ON public.departments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: enterprise_info tenant_isolation_enterprise_info; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_enterprise_info ON public.enterprise_info USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_capability_reviews tenant_isolation_external_capability_reviews; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_capability_reviews ON public.external_capability_reviews USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_capability_snapshots tenant_isolation_external_capability_snapshots; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_capability_snapshots ON public.external_capability_snapshots USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_extension_activations tenant_isolation_external_extension_activations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_extension_activations ON public.external_extension_activations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_extension_catalog_entries tenant_isolation_external_extension_catalog_entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_extension_catalog_entries ON public.external_extension_catalog_entries USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_extension_components tenant_isolation_external_extension_components; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_extension_components ON public.external_extension_components USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_extension_hook_registrations tenant_isolation_external_extension_hook_registrations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_extension_hook_registrations ON public.external_extension_hook_registrations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_identities tenant_isolation_external_identities; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_identities ON public.external_identities USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = external_identities.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = external_identities.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: external_marketplace_entries tenant_isolation_external_marketplace_entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_marketplace_entries ON public.external_marketplace_entries USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_marketplace_sources tenant_isolation_external_marketplace_sources; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_marketplace_sources ON public.external_marketplace_sources USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_principal_binding_events tenant_isolation_external_principal_binding_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_principal_binding_events ON public.external_principal_binding_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: external_principals tenant_isolation_external_principals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_external_principals ON public.external_principals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: feature_flags tenant_isolation_feature_flags; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_feature_flags ON public.feature_flags USING (true) WITH CHECK (true);


--
-- Name: guard_policies tenant_isolation_guard_policies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_guard_policies ON public.guard_policies USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: hr_creation_drafts tenant_isolation_hr_creation_drafts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_hr_creation_drafts ON public.hr_creation_drafts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: hr_provisioning_steps tenant_isolation_hr_provisioning_steps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_hr_provisioning_steps ON public.hr_provisioning_steps USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: identity_providers tenant_isolation_identity_providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_identity_providers ON public.identity_providers USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR (tenant_id IS NULL))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: invitation_codes tenant_isolation_invitation_codes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_invitation_codes ON public.invitation_codes USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: invocation_spans tenant_isolation_invocation_spans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_invocation_spans ON public.invocation_spans USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_assertions tenant_isolation_knowledge_assertions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_assertions ON public.knowledge_assertions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_documents tenant_isolation_knowledge_documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_documents ON public.knowledge_documents USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_entities tenant_isolation_knowledge_entities; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_entities ON public.knowledge_entities USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_grants tenant_isolation_knowledge_grants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_grants ON public.knowledge_grants USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_index_jobs tenant_isolation_knowledge_index_jobs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_index_jobs ON public.knowledge_index_jobs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_links tenant_isolation_knowledge_links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_links ON public.knowledge_links USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: knowledge_segments tenant_isolation_knowledge_segments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_knowledge_segments ON public.knowledge_segments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: llm_models tenant_isolation_llm_models; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_llm_models ON public.llm_models USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR (tenant_id IS NULL))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_bridge_connections tenant_isolation_local_agent_bridge_connections; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_bridge_connections ON public.local_agent_bridge_connections USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_bridge_pairing_sessions tenant_isolation_local_agent_bridge_pairing_sessions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_bridge_pairing_sessions ON public.local_agent_bridge_pairing_sessions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_capability_snapshots tenant_isolation_local_agent_capability_snapshots; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_capability_snapshots ON public.local_agent_capability_snapshots USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_channel_events tenant_isolation_local_agent_channel_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_channel_events ON public.local_agent_channel_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_channel_messages tenant_isolation_local_agent_channel_messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_channel_messages ON public.local_agent_channel_messages USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_channel_sessions tenant_isolation_local_agent_channel_sessions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_channel_sessions ON public.local_agent_channel_sessions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_channel_ws_tickets tenant_isolation_local_agent_channel_ws_tickets; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_channel_ws_tickets ON public.local_agent_channel_ws_tickets USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: local_agent_channels tenant_isolation_local_agent_channels; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_local_agent_channels ON public.local_agent_channels USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: mcp_server_tools tenant_isolation_mcp_server_tools; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_mcp_server_tools ON public.mcp_server_tools USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: mcp_servers tenant_isolation_mcp_servers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_mcp_servers ON public.mcp_servers USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: notifications tenant_isolation_notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_notifications ON public.notifications USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = notifications.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = notifications.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: org_departments tenant_isolation_org_departments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_org_departments ON public.org_departments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: org_members tenant_isolation_org_members; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_org_members ON public.org_members USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: participants tenant_isolation_participants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_participants ON public.participants USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (((type)::text = 'user'::text) AND (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = participants.ref_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))) OR (((type)::text = 'agent'::text) AND (EXISTS ( SELECT 1
   FROM public.agents
  WHERE ((agents.id = participants.ref_id) AND ((agents.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (((type)::text = 'user'::text) AND (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = participants.ref_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))) OR (((type)::text = 'agent'::text) AND (EXISTS ( SELECT 1
   FROM public.agents
  WHERE ((agents.id = participants.ref_id) AND ((agents.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))));


--
-- Name: pending_reply_contexts tenant_isolation_pending_reply_contexts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_pending_reply_contexts ON public.pending_reply_contexts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: personal_knowledge_proposals tenant_isolation_personal_knowledge_proposals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_personal_knowledge_proposals ON public.personal_knowledge_proposals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: plaza_comments tenant_isolation_plaza_comments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_plaza_comments ON public.plaza_comments USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.plaza_posts
  WHERE ((plaza_posts.id = plaza_comments.post_id) AND ((plaza_posts.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.plaza_posts
  WHERE ((plaza_posts.id = plaza_comments.post_id) AND ((plaza_posts.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: plaza_likes tenant_isolation_plaza_likes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_plaza_likes ON public.plaza_likes USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.plaza_posts
  WHERE ((plaza_posts.id = plaza_likes.post_id) AND ((plaza_posts.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.plaza_posts
  WHERE ((plaza_posts.id = plaza_likes.post_id) AND ((plaza_posts.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: plaza_posts tenant_isolation_plaza_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_plaza_posts ON public.plaza_posts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: plugin_dependency_edges tenant_isolation_plugin_dependency_edges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_plugin_dependency_edges ON public.plugin_dependency_edges USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: plugin_hook_registrations tenant_isolation_plugin_hook_registrations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_plugin_hook_registrations ON public.plugin_hook_registrations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: refresh_tokens tenant_isolation_refresh_tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_refresh_tokens ON public.refresh_tokens USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = refresh_tokens.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = refresh_tokens.user_id) AND ((users.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: resource_permissions tenant_isolation_resource_permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_resource_permissions ON public.resource_permissions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_budget_events tenant_isolation_runtime_budget_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_budget_events ON public.runtime_budget_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_budget_policies tenant_isolation_runtime_budget_policies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_budget_policies ON public.runtime_budget_policies USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((tenant_id IS NULL) AND ((scope_type)::text = 'platform_default'::text)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_budget_runs tenant_isolation_runtime_budget_runs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_budget_runs ON public.runtime_budget_runs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_notification_outbox tenant_isolation_runtime_notification_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_notification_outbox ON public.runtime_notification_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_result_integration_pages tenant_isolation_runtime_result_integration_pages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_result_integration_pages ON public.runtime_result_integration_pages USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_result_mailbox_cursors tenant_isolation_runtime_result_mailbox_cursors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_result_mailbox_cursors ON public.runtime_result_mailbox_cursors USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_result_objects tenant_isolation_runtime_result_objects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_result_objects ON public.runtime_result_objects USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_root_items tenant_isolation_runtime_root_items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_root_items ON public.runtime_root_items USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_tasks tenant_isolation_runtime_tasks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_tasks ON public.runtime_tasks USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: runtime_terminal_boundary_outbox tenant_isolation_runtime_terminal_boundary_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_runtime_terminal_boundary_outbox ON public.runtime_terminal_boundary_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: security_audit_events tenant_isolation_security_audit_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_security_audit_events ON public.security_audit_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_carry_forwards tenant_isolation_session_carry_forwards; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_carry_forwards ON public.session_carry_forwards USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_commands tenant_isolation_session_commands; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_commands ON public.session_commands USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_control_inputs tenant_isolation_session_control_inputs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_control_inputs ON public.session_control_inputs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_event_cursors tenant_isolation_session_event_cursors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_event_cursors ON public.session_event_cursors USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_event_outbox tenant_isolation_session_event_outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_event_outbox ON public.session_event_outbox USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_feedback_aggregates tenant_isolation_session_feedback_aggregates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_feedback_aggregates ON public.session_feedback_aggregates USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_feedback_events tenant_isolation_session_feedback_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_feedback_events ON public.session_feedback_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_input_admissions tenant_isolation_session_input_admissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_input_admissions ON public.session_input_admissions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_model_results tenant_isolation_session_model_results; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_model_results ON public.session_model_results USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_next_round_plans tenant_isolation_session_next_round_plans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_next_round_plans ON public.session_next_round_plans USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_round_obligations tenant_isolation_session_round_obligations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_round_obligations ON public.session_round_obligations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_run_outcomes tenant_isolation_session_run_outcomes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_run_outcomes ON public.session_run_outcomes USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_tool_invocations tenant_isolation_session_tool_invocations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_tool_invocations ON public.session_tool_invocations USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_turn_inputs tenant_isolation_session_turn_inputs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_turn_inputs ON public.session_turn_inputs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: session_turn_replacements tenant_isolation_session_turn_replacements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_session_turn_replacements ON public.session_turn_replacements USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: skill_files tenant_isolation_skill_files; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_skill_files ON public.skill_files USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.skills
  WHERE ((skills.id = skill_files.skill_id) AND (((skills.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((skills.tenant_id IS NULL) AND (skills.is_builtin IS TRUE)))))))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR (EXISTS ( SELECT 1
   FROM public.skills
  WHERE ((skills.id = skill_files.skill_id) AND ((skills.tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))))));


--
-- Name: skills tenant_isolation_skills; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_skills ON public.skills USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((tenant_id IS NULL) AND (is_builtin IS TRUE)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: sso_scan_sessions tenant_isolation_sso_scan_sessions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_sso_scan_sessions ON public.sso_scan_sessions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: storage_blob_refs tenant_isolation_storage_blob_refs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_storage_blob_refs ON public.storage_blob_refs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: storage_blobs tenant_isolation_storage_blobs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_storage_blobs ON public.storage_blobs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: storage_gc_runs tenant_isolation_storage_gc_runs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_storage_gc_runs ON public.storage_gc_runs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: system_settings tenant_isolation_system_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_system_settings ON public.system_settings USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((key)::text <> ALL (ARRAY['jina_api_key'::text, 'tavily_api_key'::text, 'exa_api_key'::text, 'firecrawl_api_key'::text])))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((key)::text <> ALL (ARRAY['jina_api_key'::text, 'tavily_api_key'::text, 'exa_api_key'::text, 'firecrawl_api_key'::text]))));


--
-- Name: task_logs tenant_isolation_task_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_task_logs ON public.task_logs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tasks tenant_isolation_tasks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tasks ON public.tasks USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_channel_configs tenant_isolation_tenant_channel_configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenant_channel_configs ON public.tenant_channel_configs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_installed_plugins tenant_isolation_tenant_installed_plugins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenant_installed_plugins ON public.tenant_installed_plugins USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_scope_quarantine_records tenant_isolation_tenant_scope_quarantine_records; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenant_scope_quarantine_records ON public.tenant_scope_quarantine_records USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_settings tenant_isolation_tenant_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenant_settings ON public.tenant_settings USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_tool_configs tenant_isolation_tenant_tool_configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenant_tool_configs ON public.tenant_tool_configs USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenants tenant_isolation_tenants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenants ON public.tenants USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: token_usage_events tenant_isolation_token_usage_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_token_usage_events ON public.token_usage_events USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tools tenant_isolation_tools; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tools ON public.tools USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((tenant_id IS NULL) AND ((type)::text = 'builtin'::text)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: users tenant_isolation_users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_users ON public.users USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_definitions tenant_isolation_workflow_definitions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_definitions ON public.workflow_definitions USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)) OR ((tenant_id IS NULL) AND ((visibility_scope)::text = 'platform'::text) AND ((owner_type)::text = 'platform'::text)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_leaf_calls tenant_isolation_workflow_leaf_calls; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_leaf_calls ON public.workflow_leaf_calls USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_preview_artifacts tenant_isolation_workflow_preview_artifacts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_preview_artifacts ON public.workflow_preview_artifacts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_promotion_proposals tenant_isolation_workflow_promotion_proposals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_promotion_proposals ON public.workflow_promotion_proposals USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_proposal_artifacts tenant_isolation_workflow_proposal_artifacts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_proposal_artifacts ON public.workflow_proposal_artifacts USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_quotas tenant_isolation_workflow_quotas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_quotas ON public.workflow_quotas USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workflow_steps tenant_isolation_workflow_steps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workflow_steps ON public.workflow_steps USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: workspace_resource_manifests tenant_isolation_workspace_resource_manifests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_workspace_resource_manifests ON public.workspace_resource_manifests USING (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)))) WITH CHECK (((current_setting('app.current_tenant_id'::text, true) = 'BYPASS'::text) OR ((tenant_id)::text = current_setting('app.current_tenant_id'::text, true))));


--
-- Name: tenant_scope_quarantine_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_scope_quarantine_records ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_tool_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenant_tool_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: token_usage_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.token_usage_events ENABLE ROW LEVEL SECURITY;

--
-- Name: tools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tools ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_definitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_leaf_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_leaf_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_preview_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_preview_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_promotion_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_promotion_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_proposal_artifacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_proposal_artifacts ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_quotas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_quotas ENABLE ROW LEVEL SECURITY;

--
-- Name: workflow_steps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workflow_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: workspace_resource_manifests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workspace_resource_manifests ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


INSERT INTO public.alembic_version (version_num) VALUES ('session_v2_delete_fk_indexes_0907');
